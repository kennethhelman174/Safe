import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { 
  ArrowLeftRight, 
  Check, 
  Clock, 
  Database, 
  Download, 
  FileWarning, 
  Loader2,
  Link as LinkIcon,
  Link2Off,
  RefreshCw, 
  Settings, 
  Shield, 
  Truck, 
  Upload, 
  Warehouse
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';

// Fetch available integration systems
const useSystems = () => {
  return useQuery({ 
    queryKey: ['/api/integration/systems'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/integration/systems', null);
      return response.json();
    }
  });
};

// Fetch a specific system details
const useSystemDetails = (systemId: string | null) => {
  return useQuery({
    queryKey: ['/api/integration/systems', systemId],
    queryFn: async () => {
      if (!systemId) return null;
      const response = await apiRequest('GET', `/api/integration/systems/${systemId}`, null);
      return response.json();
    },
    enabled: !!systemId
  });
};

// Fetch endpoints for a system
const useSystemEndpoints = (systemId: string | null) => {
  return useQuery({
    queryKey: ['/api/integration/systems', systemId, 'endpoints'],
    queryFn: async () => {
      if (!systemId) return [];
      const response = await apiRequest('GET', `/api/integration/systems/${systemId}/endpoints`, null);
      return response.json();
    },
    enabled: !!systemId
  });
};

// Fetch mappings for a system
const useSystemMappings = (systemId: string | null) => {
  return useQuery({
    queryKey: ['/api/integration/systems', systemId, 'mappings'],
    queryFn: async () => {
      if (!systemId) return [];
      const response = await apiRequest('GET', `/api/integration/systems/${systemId}/mappings`, null);
      return response.json();
    },
    enabled: !!systemId
  });
};

// Fetch sync history for a system
const useSyncHistory = (systemId: string | null) => {
  return useQuery({
    queryKey: ['/api/integration/systems', systemId, 'history'],
    queryFn: async () => {
      if (!systemId) return [];
      const response = await apiRequest('GET', `/api/integration/systems/${systemId}/history`, null);
      return response.json();
    },
    enabled: !!systemId,
    refetchInterval: 30000 // Refresh every 30 seconds
  });
};

// Format date for display
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
};

const AdvancedIntegrationPanel = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State variables
  const [selectedSystem, setSelectedSystem] = useState<string | null>(null);
  const [connectionDetails, setConnectionDetails] = useState({
    url: '',
    apiKey: '',
    syncInterval: '15',
    authType: 'api_key'
  });
  const [activeTab, setActiveTab] = useState('data_mapping');
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [isSyncing, setIsSyncing] = useState<Record<string, boolean>>({});
  
  // Queries
  const { data: systems = [], isLoading: isLoadingSystems } = useSystems();
  const { data: systemDetails, isLoading: isLoadingDetails } = useSystemDetails(selectedSystem);
  const { data: endpoints = [], isLoading: isLoadingEndpoints } = useSystemEndpoints(selectedSystem);
  const { data: mappings = [], isLoading: isLoadingMappings } = useSystemMappings(selectedSystem);
  const { data: syncHistory = [], isLoading: isLoadingSyncHistory } = useSyncHistory(selectedSystem);
  
  // Update connection details when system changes
  useEffect(() => {
    if (systemDetails?.connectionDetails) {
      setConnectionDetails({
        url: systemDetails.connectionDetails.url || '',
        apiKey: systemDetails.connectionDetails.apiKey || '',
        syncInterval: systemDetails.connectionDetails.syncInterval?.toString() || '15',
        authType: systemDetails.connectionDetails.authType || 'api_key'
      });
    } else {
      // Default values for new connections
      setConnectionDetails({
        url: '',
        apiKey: '',
        syncInterval: '15',
        authType: 'api_key'
      });
    }
  }, [systemDetails]);
  
  // Mutation for connecting to a system
  const connectMutation = useMutation({
    mutationFn: async ({ systemId, connectionData }: { systemId: string, connectionData: any }) => {
      const response = await apiRequest('POST', `/api/integration/systems/${systemId}/connect`, connectionData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/integration/systems'] });
      if (selectedSystem) {
        queryClient.invalidateQueries({ queryKey: ['/api/integration/systems', selectedSystem] });
      }
      
      toast({
        title: "Connection Successful",
        description: `Successfully connected to ${systemDetails?.name}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Connection Failed",
        description: `Failed to connect: ${error.message || 'Unknown error'}`,
        variant: "destructive"
      });
    }
  });
  
  // Mutation for disconnecting from a system
  const disconnectMutation = useMutation({
    mutationFn: async (systemId: string) => {
      const response = await apiRequest('POST', `/api/integration/systems/${systemId}/disconnect`, null);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/integration/systems'] });
      if (selectedSystem) {
        queryClient.invalidateQueries({ queryKey: ['/api/integration/systems', selectedSystem] });
      }
      
      toast({
        title: "Disconnected",
        description: data.message || "Successfully disconnected from the system",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Disconnection Failed",
        description: `Failed to disconnect: ${error.message || 'Unknown error'}`,
        variant: "destructive"
      });
    }
  });
  
  // Mutation for updating endpoint settings
  const updateEndpointMutation = useMutation({
    mutationFn: async ({ systemId, endpointId, endpointData }: { systemId: string, endpointId: string, endpointData: any }) => {
      const response = await apiRequest('PUT', `/api/integration/systems/${systemId}/endpoints/${endpointId}`, endpointData);
      return response.json();
    },
    onSuccess: () => {
      if (selectedSystem) {
        queryClient.invalidateQueries({ queryKey: ['/api/integration/systems', selectedSystem, 'endpoints'] });
      }
      
      toast({
        title: "Endpoint Updated",
        description: "Endpoint settings have been updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: `Failed to update endpoint: ${error.message || 'Unknown error'}`,
        variant: "destructive"
      });
    }
  });
  
  // Mutation for updating data mappings
  const updateMappingMutation = useMutation({
    mutationFn: async ({ systemId, mappingId, mappingData }: { systemId: string, mappingId: string, mappingData: any }) => {
      const response = await apiRequest('PUT', `/api/integration/systems/${systemId}/mappings/${mappingId}`, mappingData);
      return response.json();
    },
    onSuccess: () => {
      if (selectedSystem) {
        queryClient.invalidateQueries({ queryKey: ['/api/integration/systems', selectedSystem, 'mappings'] });
      }
      
      toast({
        title: "Mapping Updated",
        description: "Data mapping has been updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: `Failed to update mapping: ${error.message || 'Unknown error'}`,
        variant: "destructive"
      });
    }
  });
  
  // Mutation for triggering a manual sync
  const triggerSyncMutation = useMutation({
    mutationFn: async ({ systemId, endpointId }: { systemId: string, endpointId: string }) => {
      const response = await apiRequest('POST', `/api/integration/systems/${systemId}/sync/${endpointId}`, null);
      return response.json();
    },
    onSuccess: (data, variables) => {
      // After a few seconds, refresh the sync history
      setTimeout(() => {
        if (selectedSystem) {
          queryClient.invalidateQueries({ queryKey: ['/api/integration/systems', selectedSystem, 'history'] });
        }
        // Clear the syncing state
        setIsSyncing(prev => ({ ...prev, [variables.endpointId]: false }));
      }, 2000);
      
      toast({
        title: "Sync Started",
        description: `Data synchronization has been initiated for ${
          endpoints.find(e => e.id === variables.endpointId)?.name || 'the endpoint'
        }`,
      });
    },
    onError: (error: any, variables) => {
      // Clear the syncing state
      setIsSyncing(prev => ({ ...prev, [variables.endpointId]: false }));
      
      toast({
        title: "Sync Failed",
        description: `Failed to trigger sync: ${error.message || 'Unknown error'}`,
        variant: "destructive"
      });
    }
  });
  
  // Function to test connection
  const testConnection = async () => {
    if (!selectedSystem) return;
    
    setIsTestingConnection(true);
    
    try {
      const response = await apiRequest('POST', `/api/integration/systems/${selectedSystem}/test-connection`, connectionDetails);
      const result = await response.json();
      
      if (result.success) {
        toast({
          title: "Connection Test Successful",
          description: result.message || "Successfully connected to the WMS system",
        });
      } else {
        toast({
          title: "Connection Test Failed",
          description: result.message || "Failed to connect to the WMS system",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Connection Test Failed",
        description: `An error occurred: ${(error as Error).message || 'Unknown error'}`,
        variant: "destructive"
      });
    } finally {
      setIsTestingConnection(false);
    }
  };
  
  // Handle connection to a system
  const handleConnect = () => {
    if (!selectedSystem) return;
    
    connectMutation.mutate({
      systemId: selectedSystem,
      connectionData: connectionDetails
    });
  };
  
  // Handle disconnection from a system
  const handleDisconnect = () => {
    if (!selectedSystem) return;
    
    disconnectMutation.mutate(selectedSystem);
  };
  
  // Handle toggling an endpoint
  const handleEndpointToggle = (endpointId: string, enabled: boolean) => {
    if (!selectedSystem) return;
    
    updateEndpointMutation.mutate({
      systemId: selectedSystem,
      endpointId,
      endpointData: { enabled }
    });
  };
  
  // Handle updating a data mapping
  const handleUpdateMapping = (mappingId: string) => {
    if (!selectedSystem) return;
    
    updateMappingMutation.mutate({
      systemId: selectedSystem,
      mappingId,
      mappingData: { status: 'mapped' }
    });
  };
  
  // Handle triggering a sync for an endpoint
  const handleTriggerSync = (endpointId: string) => {
    if (!selectedSystem) return;
    
    // Set syncing state for this endpoint
    setIsSyncing(prev => ({ ...prev, [endpointId]: true }));
    
    triggerSyncMutation.mutate({
      systemId: selectedSystem,
      endpointId
    });
  };
  
  // Render loading state
  if (isLoadingSystems) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Skeleton className="h-64" />
          <Skeleton className="h-64 md:col-span-2" />
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center">
          <Warehouse className="mr-2 h-6 w-6 text-primary" />
          Warehouse Management System Integration
        </h2>
        
        {systemDetails?.status === 'connected' && (
          <Button 
            variant="default"
            onClick={() => {
              if (selectedSystem) {
                const endpoint = endpoints.find(e => e.id === 'inbound_shipments');
                if (endpoint && endpoint.enabled) {
                  handleTriggerSync('inbound_shipments');
                } else {
                  toast({
                    title: "Sync Not Available",
                    description: "Please enable the inbound shipments endpoint to sync data",
                    variant: "destructive"
                  });
                }
              } else {
                toast({
                  title: "No System Selected",
                  description: "Please select a system to sync data",
                  variant: "destructive"
                });
              }
            }}
            disabled={!selectedSystem || isSyncing['inbound_shipments']}
            className="flex items-center"
          >
            {isSyncing['inbound_shipments'] ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Syncing...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Sync Shipments
              </>
            )}
          </Button>
        )}
      </div>
      
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Available Systems */}
        <Card className="xl:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <Database className="mr-2 h-5 w-5" />
              Available Systems
            </CardTitle>
            <CardDescription>
              Connect to your warehouse management systems
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {systems.map((system: any) => (
                <div 
                  key={system.id}
                  className={`p-4 rounded-lg border flex justify-between items-center ${
                    system.status === 'connected' 
                      ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' 
                      : 'bg-gray-50 dark:bg-gray-800/50'
                  } ${selectedSystem === system.id ? 'ring-2 ring-primary' : ''}`}
                  onClick={() => setSelectedSystem(system.id)}
                  style={{ cursor: 'pointer' }}
                >
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold">
                      {system.provider?.substring(0, 2) || system.name.substring(0, 2)}
                    </div>
                    <div className="ml-3">
                      <h4 className="font-medium text-sm">{system.name}</h4>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {system.status === 'connected' ? 'Connected' : 'Not connected'}
                      </p>
                    </div>
                  </div>
                  
                  {system.status === 'connected' ? (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedSystem(system.id);
                        handleDisconnect();
                      }}
                      disabled={disconnectMutation.isPending}
                    >
                      {disconnectMutation.isPending && selectedSystem === system.id ? (
                        <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                      ) : (
                        <Link2Off className="h-4 w-4 mr-1" />
                      )}
                      Disconnect
                    </Button>
                  ) : (
                    <Button 
                      size="sm"
                      variant="outline"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedSystem(system.id);
                        setActiveTab('settings');
                      }}
                    >
                      <LinkIcon className="h-4 w-4 mr-1" />
                      Configure
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        {/* Configuration Tabs */}
        <Card className="xl:col-span-2">
          <Tabs defaultValue="data_mapping" value={activeTab} onValueChange={setActiveTab}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center text-lg">
                  <Settings className="mr-2 h-5 w-5" />
                  System Configuration
                </CardTitle>
                <TabsList>
                  <TabsTrigger value="data_mapping" className="text-xs">Data Mapping</TabsTrigger>
                  <TabsTrigger value="endpoints" className="text-xs">Endpoints</TabsTrigger>
                  <TabsTrigger value="settings" className="text-xs">API Settings</TabsTrigger>
                  <TabsTrigger value="history" className="text-xs">Sync History</TabsTrigger>
                </TabsList>
              </div>
              <CardDescription>
                {selectedSystem ? (
                  <>Configure integration with {systemDetails?.name || 'selected system'}</>
                ) : (
                  <>Select a system to configure</>
                )}
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              {!selectedSystem ? (
                <div className="bg-muted p-8 rounded-lg text-center">
                  <Warehouse className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-medium mb-2">No System Selected</h3>
                  <p className="text-muted-foreground mb-4">
                    Please select a warehouse management system from the list to configure integration.
                  </p>
                </div>
              ) : isLoadingDetails || isLoadingEndpoints || isLoadingMappings ? (
                <div className="space-y-4">
                  <Skeleton className="h-8 w-full" />
                  <Skeleton className="h-8 w-full" />
                  <Skeleton className="h-8 w-full" />
                  <Skeleton className="h-8 w-full" />
                </div>
              ) : (
                <>
                  {/* Data Mapping Tab */}
                  <TabsContent value="data_mapping" className="space-y-4">
                    {mappings.length === 0 ? (
                      <div className="bg-muted p-8 rounded-lg text-center">
                        <FileWarning className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                        <h3 className="text-lg font-medium mb-2">No Data Mappings Available</h3>
                        <p className="text-muted-foreground mb-4">
                          This system does not have any data mappings defined yet.
                        </p>
                        {systemDetails?.status !== 'connected' && (
                          <Button 
                            variant="default" 
                            onClick={() => setActiveTab('settings')}
                          >
                            Connect System First
                          </Button>
                        )}
                      </div>
                    ) : (
                      <>
                        <div className="rounded-md border">
                          <div className="bg-muted/50 p-3 flex font-medium text-sm">
                            <div className="w-5/12">Source Field</div>
                            <div className="w-5/12">Target Field</div>
                            <div className="w-2/12 text-right">Status</div>
                          </div>
                          <div className="divide-y">
                            {mappings.map((mapping: any) => (
                              <div key={mapping.id} className="p-3 flex items-center text-sm">
                                <div className="w-5/12 flex items-center">
                                  <Badge variant="outline" className="mr-2 font-mono text-xs">
                                    {mapping.sourceField.split('.')[0]}
                                  </Badge>
                                  <span className="text-sm">{mapping.sourceField.split('.').slice(1).join('.')}</span>
                                </div>
                                <div className="w-5/12 flex items-center">
                                  <Badge variant="outline" className="mr-2 font-mono text-xs">
                                    {mapping.targetField.split('.')[0]}
                                  </Badge>
                                  <span className="text-sm">{mapping.targetField.split('.').slice(1).join('.')}</span>
                                </div>
                                <div className="w-2/12 text-right">
                                  {mapping.status === 'mapped' ? (
                                    <Badge className="bg-green-500">
                                      <Check className="h-3 w-3 mr-1" />
                                      Mapped
                                    </Badge>
                                  ) : (
                                    <Button 
                                      size="sm" 
                                      variant="outline"
                                      className="text-xs h-7 px-2"
                                      onClick={() => handleUpdateMapping(mapping.id)}
                                      disabled={updateMappingMutation.isPending}
                                    >
                                      {updateMappingMutation.isPending ? (
                                        <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                                      ) : (
                                        'Map Field'
                                      )}
                                    </Button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                        
                        {mappings.some((m: any) => m.status === 'unmapped') && (
                          <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 p-3 rounded-md">
                            <div className="flex items-start">
                              <FileWarning className="h-5 w-5 text-yellow-500 mt-0.5 mr-2 flex-shrink-0" />
                              <div>
                                <h4 className="font-medium text-sm">Mapping Validation</h4>
                                <p className="text-sm mt-1 text-gray-600 dark:text-gray-300">
                                  Some fields remain unmapped. Missing mappings may cause partial data synchronization
                                  between DockSafe and {systemDetails?.name}.
                                </p>
                              </div>
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </TabsContent>
                  
                  {/* Endpoints Tab */}
                  <TabsContent value="endpoints" className="space-y-4">
                    {endpoints.length === 0 ? (
                      <div className="bg-muted p-8 rounded-lg text-center">
                        <FileWarning className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                        <h3 className="text-lg font-medium mb-2">No Endpoints Available</h3>
                        <p className="text-muted-foreground mb-4">
                          This system does not have any data endpoints defined yet.
                        </p>
                        {systemDetails?.status !== 'connected' && (
                          <Button 
                            variant="default" 
                            onClick={() => setActiveTab('settings')}
                          >
                            Connect System First
                          </Button>
                        )}
                      </div>
                    ) : (
                      <div className="rounded-md border">
                        <div className="bg-muted/50 p-3 flex font-medium text-sm">
                          <div className="w-5/12">Data Endpoint</div>
                          <div className="w-3/12">Direction</div>
                          <div className="w-2/12">Status</div>
                          <div className="w-2/12 text-right">Actions</div>
                        </div>
                        <div className="divide-y">
                          {endpoints.map((endpoint: any) => (
                            <div key={endpoint.id} className="p-3 flex items-center text-sm">
                              <div className="w-5/12">
                                <div className="font-medium">{endpoint.name}</div>
                                <div className="text-xs text-gray-500 mt-1">{endpoint.description}</div>
                              </div>
                              <div className="w-3/12 flex items-center">
                                {endpoint.direction === 'inbound' ? (
                                  <Badge variant="outline" className="flex items-center">
                                    <Download className="h-3 w-3 mr-1" />
                                    Import
                                  </Badge>
                                ) : endpoint.direction === 'outbound' ? (
                                  <Badge variant="outline" className="flex items-center">
                                    <Upload className="h-3 w-3 mr-1" />
                                    Export
                                  </Badge>
                                ) : (
                                  <Badge variant="outline" className="flex items-center">
                                    <ArrowLeftRight className="h-3 w-3 mr-1" />
                                    Bidirectional
                                  </Badge>
                                )}
                              </div>
                              <div className="w-2/12">
                                <Switch
                                  checked={endpoint.enabled}
                                  onCheckedChange={(checked) => handleEndpointToggle(endpoint.id, checked)}
                                  disabled={systemDetails?.status !== 'connected' || updateEndpointMutation.isPending}
                                />
                              </div>
                              <div className="w-2/12 text-right">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  disabled={
                                    !endpoint.enabled || 
                                    systemDetails?.status !== 'connected' || 
                                    isSyncing[endpoint.id] ||
                                    triggerSyncMutation.isPending
                                  }
                                  onClick={() => handleTriggerSync(endpoint.id)}
                                >
                                  {isSyncing[endpoint.id] ? (
                                    <>
                                      <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                                      Syncing...
                                    </>
                                  ) : (
                                    <>
                                      <RefreshCw className="h-3 w-3 mr-1" />
                                      Sync
                                    </>
                                  )}
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {systemDetails?.status === 'connected' && (
                      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 p-3 rounded-md">
                        <div className="flex items-start">
                          <Shield className="h-5 w-5 text-blue-500 mt-0.5 mr-2 flex-shrink-0" />
                          <div>
                            <h4 className="font-medium text-sm">Data Integration Notes</h4>
                            <p className="text-sm mt-1 text-gray-600 dark:text-gray-300">
                              Enabled endpoints will automatically synchronize data between DockSafe and {systemDetails?.name} 
                              according to the configured schedule. You can also trigger a manual sync using the Sync button.
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </TabsContent>
                  
                  {/* API Settings Tab */}
                  <TabsContent value="settings" className="space-y-4">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="url">API Endpoint URL</Label>
                        <Input 
                          id="url" 
                          placeholder="https://api.example.com/v2" 
                          value={connectionDetails.url}
                          onChange={(e) => setConnectionDetails({ ...connectionDetails, url: e.target.value })}
                          disabled={
                            systemDetails?.status === 'connected' || 
                            connectMutation.isPending ||
                            isTestingConnection
                          }
                        />
                        <p className="text-sm text-gray-500">The base URL for the WMS API</p>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="api-key">API Key or Token</Label>
                        <Input 
                          id="api-key" 
                          type="password"
                          placeholder="Enter your API key" 
                          value={connectionDetails.apiKey}
                          onChange={(e) => setConnectionDetails({ ...connectionDetails, apiKey: e.target.value })}
                          disabled={
                            systemDetails?.status === 'connected' || 
                            connectMutation.isPending ||
                            isTestingConnection
                          }
                        />
                        <p className="text-sm text-gray-500">Authenticate requests to the WMS API</p>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="auth-type">Authentication Type</Label>
                          <Select 
                            value={connectionDetails.authType}
                            onValueChange={(value) => setConnectionDetails({ ...connectionDetails, authType: value })}
                            disabled={
                              systemDetails?.status === 'connected' || 
                              connectMutation.isPending ||
                              isTestingConnection
                            }
                          >
                            <SelectTrigger id="auth-type">
                              <SelectValue placeholder="Select auth type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="api_key">API Key</SelectItem>
                              <SelectItem value="oauth">OAuth 2.0</SelectItem>
                              <SelectItem value="basic">Basic Auth</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="sync-interval">Sync Interval (minutes)</Label>
                          <Select 
                            value={connectionDetails.syncInterval}
                            onValueChange={(value) => setConnectionDetails({ ...connectionDetails, syncInterval: value })}
                            disabled={
                              systemDetails?.status === 'connected' || 
                              connectMutation.isPending ||
                              isTestingConnection
                            }
                          >
                            <SelectTrigger id="sync-interval">
                              <SelectValue placeholder="Select interval" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="5">5 minutes</SelectItem>
                              <SelectItem value="15">15 minutes</SelectItem>
                              <SelectItem value="30">30 minutes</SelectItem>
                              <SelectItem value="60">1 hour</SelectItem>
                              <SelectItem value="360">6 hours</SelectItem>
                              <SelectItem value="720">12 hours</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex justify-between mt-4 pt-4 border-t">
                      {systemDetails?.status === 'connected' ? (
                        <>
                          <Button
                            variant="outline"
                            className="flex items-center"
                            onClick={testConnection}
                            disabled={isTestingConnection}
                          >
                            {isTestingConnection ? (
                              <>
                                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                Testing...
                              </>
                            ) : (
                              <>
                                <Shield className="h-4 w-4 mr-2" />
                                Test Connection
                              </>
                            )}
                          </Button>
                          
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="destructive" className="flex items-center">
                                <Link2Off className="h-4 w-4 mr-2" />
                                Disconnect System
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Disconnect WMS System?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will terminate the integration with {systemDetails?.name}. 
                                  Data will no longer be synchronized between the systems.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={handleDisconnect}
                                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                >
                                  Disconnect
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </>
                      ) : (
                        <>
                          <Button
                            variant="outline"
                            className="flex items-center"
                            onClick={testConnection}
                            disabled={
                              !connectionDetails.url || 
                              isTestingConnection ||
                              connectMutation.isPending
                            }
                          >
                            {isTestingConnection ? (
                              <>
                                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                Testing...
                              </>
                            ) : (
                              <>
                                <Shield className="h-4 w-4 mr-2" />
                                Test Connection
                              </>
                            )}
                          </Button>
                          
                          <Button
                            className="flex items-center"
                            onClick={handleConnect}
                            disabled={
                              !connectionDetails.url || 
                              connectMutation.isPending ||
                              isTestingConnection
                            }
                          >
                            {connectMutation.isPending ? (
                              <>
                                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                Connecting...
                              </>
                            ) : (
                              <>
                                <LinkIcon className="h-4 w-4 mr-2" />
                                Connect System
                              </>
                            )}
                          </Button>
                        </>
                      )}
                    </div>
                  </TabsContent>
                  
                  {/* Sync History Tab */}
                  <TabsContent value="history" className="space-y-4">
                    {isLoadingSyncHistory ? (
                      <div className="space-y-4">
                        <Skeleton className="h-12 w-full" />
                        <Skeleton className="h-12 w-full" />
                        <Skeleton className="h-12 w-full" />
                      </div>
                    ) : syncHistory.length === 0 ? (
                      <div className="bg-muted p-8 rounded-lg text-center">
                        <Clock className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                        <h3 className="text-lg font-medium mb-2">No Sync History</h3>
                        <p className="text-muted-foreground mb-4">
                          No synchronization has been performed yet with {systemDetails?.name}.
                        </p>
                        {endpoints.some((e: any) => e.enabled) ? (
                          <Button 
                            variant="default" 
                            onClick={() => {
                              const enabledEndpoint = endpoints.find((e: any) => e.enabled);
                              if (enabledEndpoint) {
                                handleTriggerSync(enabledEndpoint.id);
                              }
                            }}
                            disabled={!endpoints.some((e: any) => e.enabled)}
                          >
                            Trigger First Sync
                          </Button>
                        ) : (
                          <Button 
                            variant="default" 
                            onClick={() => setActiveTab('endpoints')}
                          >
                            Enable Endpoints First
                          </Button>
                        )}
                      </div>
                    ) : (
                      <>
                        <Accordion type="single" collapsible className="w-full">
                          {syncHistory.map((record: any) => (
                            <AccordionItem key={record.id} value={record.id}>
                              <AccordionTrigger className="py-4">
                                <div className="flex items-center justify-between w-full pr-4">
                                  <div className="flex items-center">
                                    {record.status === 'success' ? (
                                      <Badge className="mr-3 bg-green-500">Success</Badge>
                                    ) : record.status === 'error' ? (
                                      <Badge className="mr-3 bg-destructive">Error</Badge>
                                    ) : (
                                      <Badge className="mr-3 bg-yellow-500">Warning</Badge>
                                    )}
                                    <div className="text-left">
                                      <div className="font-medium">
                                        {record.event || endpoints.find((e: any) => e.id === record.endpointId)?.name || record.endpointId}
                                      </div>
                                      <div className="text-xs text-gray-500">{formatDate(record.timestamp)}</div>
                                    </div>
                                  </div>
                                  <div className="text-sm text-right">
                                    {record.recordsProcessed} records
                                  </div>
                                </div>
                              </AccordionTrigger>
                              <AccordionContent className="px-4 pb-4">
                                <div className="space-y-2">
                                  <div className="text-sm">{record.message}</div>
                                  {record.status === 'success' && (
                                    <div className="flex items-center mt-2">
                                      <div className="text-xs text-gray-500 mr-2">Sync Progress:</div>
                                      <Progress value={100} className="h-2" />
                                    </div>
                                  )}
                                  {record.status === 'warning' && record.details && (
                                    <div className="text-xs text-yellow-600 bg-yellow-50 p-2 rounded mt-2">
                                      Warning details: {record.details}
                                    </div>
                                  )}
                                  {record.status === 'error' && record.details && (
                                    <div className="text-xs text-red-600 bg-red-50 p-2 rounded mt-2">
                                      Error details: {record.details}
                                    </div>
                                  )}
                                </div>
                              </AccordionContent>
                            </AccordionItem>
                          ))}
                        </Accordion>
                        
                        <div className="flex justify-end pt-2">
                          <Button
                            variant="outline"
                            onClick={() => {
                              if (selectedSystem) {
                                queryClient.invalidateQueries({ 
                                  queryKey: ['/api/integration/systems', selectedSystem, 'history'] 
                                });
                              }
                            }}
                            className="text-xs"
                          >
                            <RefreshCw className="h-3 w-3 mr-1" />
                            Refresh History
                          </Button>
                        </div>
                      </>
                    )}
                  </TabsContent>
                </>
              )}
            </CardContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
};

export default AdvancedIntegrationPanel;
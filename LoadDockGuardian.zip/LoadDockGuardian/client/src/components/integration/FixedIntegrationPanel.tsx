import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { 
  ArrowLeftRight, 
  Check, 
  Clock, 
  Database, 
  Download, 
  FileWarning, 
  Loader2,
  Link as LinkIcon,
  Link2Off,
  RefreshCw, 
  Settings, 
  Shield, 
  Truck, 
  Upload, 
  Warehouse
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Skeleton } from '@/components/ui/skeleton';
import { apiRequest } from '@/lib/queryClient';

// Sample integration systems - would normally come from API
const sampleSystems = [
  { 
    id: 'sap', 
    name: 'SAP Warehouse Management', 
    icon: 'SA', 
    status: 'disconnected',
    description: 'Enterprise warehouse management system by SAP'
  },
  { 
    id: 'oracle', 
    name: 'Oracle WMS', 
    icon: 'OR', 
    status: 'connected',
    description: 'Oracle Warehouse Management Cloud',
    lastSync: '2025-05-20T15:32:42Z'
  },
  { 
    id: 'manhattan', 
    name: 'Manhattan SCALE', 
    icon: 'MA', 
    status: 'disconnected',
    description: 'Supply chain execution solution'
  },
  { 
    id: 'infor', 
    name: 'Infor SCM', 
    icon: 'IN', 
    status: 'connected',
    description: 'Supply Chain Management by Infor',
    lastSync: '2025-05-19T12:15:00Z'
  },
];

// Sample endpoints
const sampleEndpoints = [
  {
    id: 'inbound_shipments',
    name: 'Inbound Shipments',
    direction: 'in',
    enabled: true,
    description: 'Import shipment arrivals from WMS',
    frequency: 'Every 15 min'
  },
  {
    id: 'outbound_shipments',
    name: 'Outbound Shipments',
    direction: 'out',
    enabled: true,
    description: 'Export completed shipments to WMS',
    frequency: 'Every 30 min'
  },
  {
    id: 'inventory_levels',
    name: 'Inventory Levels',
    direction: 'in',
    enabled: false,
    description: 'Import current inventory levels from WMS'
  },
  {
    id: 'safety_incidents',
    name: 'Safety Incidents',
    direction: 'out',
    enabled: true,
    description: 'Export safety incidents to WMS',
    lastSync: '2025-05-19T18:42:00Z'
  }
];

// Sample mappings
const sampleMappings = [
  {
    id: '1',
    source: 'DockSafe.vehicle.id',
    target: 'WMS.shipment.external_id',
    status: 'mapped'
  },
  {
    id: '2',
    source: 'DockSafe.dock.id',
    target: 'WMS.location.dock_id',
    status: 'mapped'
  },
  {
    id: '3',
    source: 'DockSafe.incident.description',
    target: 'WMS.event.description',
    status: 'mapped'
  },
  {
    id: '4',
    source: 'WMS.shipment.status',
    target: 'DockSafe.vehicle.wms_status',
    status: 'unmapped'
  },
  {
    id: '5',
    source: 'WMS.schedule.arrival_time',
    target: 'DockSafe.vehicle.scheduled_arrival',
    status: 'unmapped'
  }
];

// Sample sync history
const sampleSyncHistory = [
  {
    id: '1',
    timestamp: '2025-05-21T14:35:12Z',
    event: 'Pull Inbound Shipments',
    status: 'success',
    message: '12 shipments imported successfully'
  },
  {
    id: '2',
    timestamp: '2025-05-21T14:00:00Z',
    event: 'Push Safety Incidents',
    status: 'success',
    message: '2 incidents exported to WMS'
  },
  {
    id: '3',
    timestamp: '2025-05-21T13:30:15Z',
    event: 'Pull Inbound Shipments',
    status: 'warning',
    message: '1 shipment had invalid dock assignment'
  },
  {
    id: '4',
    timestamp: '2025-05-21T13:00:00Z',
    event: 'System Sync',
    status: 'error',
    message: 'API authentication failed'
  }
];

const FixedIntegrationPanel = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('systems');
  const [selectedSystem, setSelectedSystem] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState<Record<string, boolean>>({});
  const [connectionDetails, setConnectionDetails] = useState({
    url: '',
    apiKey: '',
    syncInterval: '15'
  });

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  // Handler for connecting to a system
  const handleConnect = () => {
    if (!selectedSystem) return;
    
    setIsLoading(true);
    setTimeout(() => {
      toast({
        title: "Connection Successful",
        description: `Successfully connected to ${sampleSystems.find(s => s.id === selectedSystem)?.name}`,
      });
      setIsLoading(false);
      setActiveTab('endpoints');
    }, 1500);
  };
  
  // Handler for disconnecting from a system
  const handleDisconnect = () => {
    if (!selectedSystem) return;
    
    setTimeout(() => {
      toast({
        title: "Disconnected",
        description: `Disconnected from ${sampleSystems.find(s => s.id === selectedSystem)?.name}`,
      });
    }, 800);
  };
  
  // Handler for endpoint toggle
  const handleEndpointToggle = (endpointId: string, enabled: boolean) => {
    toast({
      title: enabled ? "Endpoint Enabled" : "Endpoint Disabled",
      description: `${sampleEndpoints.find(e => e.id === endpointId)?.name} is now ${enabled ? 'enabled' : 'disabled'}`,
    });
  };
  
  // Handler for mapping update
  const handleUpdateMapping = (mappingId: string) => {
    toast({
      title: "Field Mapped",
      description: `Successfully mapped ${sampleMappings.find(m => m.id === mappingId)?.source} to ${sampleMappings.find(m => m.id === mappingId)?.target}`,
    });
  };
  
  // Handler for sync
  const handleSync = (endpointId: string) => {
    setIsSyncing(prev => ({ ...prev, [endpointId]: true }));
    
    setTimeout(() => {
      setIsSyncing(prev => ({ ...prev, [endpointId]: false }));
      toast({
        title: "Sync Completed",
        description: `Successfully synchronized ${sampleEndpoints.find(e => e.id === endpointId)?.name}`,
      });
    }, 2000);
  };

  // Get current system details
  const currentSystem = sampleSystems.find(s => s.id === selectedSystem);
  const isConnected = currentSystem?.status === 'connected';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold flex items-center">
          <Warehouse className="mr-2 h-6 w-6 text-primary" />
          WMS Integration
        </h2>
        
        {isConnected && (
          <Button 
            variant="default"
            onClick={() => handleSync('inbound_shipments')}
            disabled={isSyncing['inbound_shipments']}
            className="flex items-center w-full sm:w-auto"
          >
            {isSyncing['inbound_shipments'] ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Syncing...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Sync Shipments
              </>
            )}
          </Button>
        )}
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-3 mb-4">
          <TabsTrigger value="systems">Systems</TabsTrigger>
          <TabsTrigger value="endpoints" disabled={!selectedSystem}>Endpoints</TabsTrigger>
          <TabsTrigger value="mappings" disabled={!selectedSystem}>Mappings</TabsTrigger>
        </TabsList>
        
        {/* Systems Tab */}
        <TabsContent value="systems" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sampleSystems.map((system) => (
              <div 
                key={system.id}
                className={`p-4 rounded-lg border ${
                  system.status === 'connected' 
                    ? 'bg-green-50 dark:bg-green-800/20 border-green-200 dark:border-green-700' 
                    : 'bg-gray-50 dark:bg-gray-800/50'
                } ${selectedSystem === system.id ? 'ring-2 ring-primary' : ''}`}
                onClick={() => setSelectedSystem(system.id)}
                style={{ cursor: 'pointer' }}
              >
                <div className="flex flex-col h-full">
                  <div className="flex items-center mb-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold">
                      {system.icon}
                    </div>
                    <div className="ml-3">
                      <h4 className="font-medium text-foreground">{system.name}</h4>
                      <p className="text-xs text-muted-foreground">
                        {system.status === 'connected' ? 'Connected' : 'Not connected'}
                      </p>
                    </div>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-3">{system.description}</p>
                  
                  <div className="mt-auto pt-3 border-t border-border">
                    {system.status === 'connected' ? (
                      <div className="flex flex-col gap-2">
                        <div className="text-sm text-muted-foreground">
                          {system.lastSync ? (
                            <p>Last sync: {formatDate(system.lastSync)}</p>
                          ) : (
                            <p>No recent synchronization</p>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="flex-1"
                                onClick={(e: React.MouseEvent) => e.stopPropagation()}
                              >
                                <Link2Off className="h-4 w-4 mr-1" />
                                Disconnect
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Disconnecting from {system.name} will stop all data synchronization. You can reconnect at any time.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction 
                                  onClick={() => {
                                    handleDisconnect();
                                  }}
                                >
                                  Disconnect
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                          <Button 
                            size="sm"
                            className="flex-1"
                            onClick={(e: React.MouseEvent) => {
                              e.stopPropagation();
                              setActiveTab('endpoints');
                            }}
                          >
                            Configure
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <Button 
                        size="sm"
                        className="w-full"
                        onClick={(e: React.MouseEvent) => {
                          e.stopPropagation();
                          if (selectedSystem === system.id) {
                            handleConnect();
                          } else {
                            setSelectedSystem(system.id);
                            setActiveTab('settings');
                          }
                        }}
                        disabled={isLoading}
                      >
                        {isLoading && selectedSystem === system.id ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                            Connecting...
                          </>
                        ) : (
                          <>
                            <LinkIcon className="h-4 w-4 mr-1" />
                            Connect
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {selectedSystem && !isConnected && (
            <Card>
              <CardHeader>
                <CardTitle>Connection Settings</CardTitle>
                <CardDescription>
                  Configure connection details for {sampleSystems.find(s => s.id === selectedSystem)?.name}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="url">API Endpoint URL</Label>
                  <Input 
                    id="url" 
                    placeholder="https://api.example.com/v2" 
                    value={connectionDetails.url}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                      setConnectionDetails({...connectionDetails, url: e.target.value})
                    }
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="api-key">API Key</Label>
                  <Input 
                    id="api-key" 
                    type="password"
                    placeholder="Enter your API key" 
                    value={connectionDetails.apiKey}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                      setConnectionDetails({...connectionDetails, apiKey: e.target.value})
                    }
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="sync-interval">Sync Interval</Label>
                  <Select 
                    value={connectionDetails.syncInterval}
                    onValueChange={(value) => 
                      setConnectionDetails({...connectionDetails, syncInterval: value})
                    }
                  >
                    <SelectTrigger id="sync-interval">
                      <SelectValue placeholder="Select interval" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 minutes</SelectItem>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="pt-4 flex space-x-2">
                  <Button 
                    variant="outline"
                    onClick={() => {
                      toast({
                        title: "Connection Test Successful",
                        description: "Successfully connected to the WMS system",
                      });
                    }}
                    className="flex-1"
                  >
                    Test Connection
                  </Button>
                  
                  <Button 
                    onClick={handleConnect}
                    disabled={!connectionDetails.url || !connectionDetails.apiKey || isLoading}
                    className="flex-1"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Connecting...
                      </>
                    ) : (
                      "Connect"
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        {/* Endpoints Tab */}
        <TabsContent value="endpoints" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <ArrowLeftRight className="mr-2 h-5 w-5" />
                Data Endpoints
              </CardTitle>
              <CardDescription>
                Enable or disable data synchronization for specific endpoints
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {sampleEndpoints.map((endpoint) => (
                  <div 
                    key={endpoint.id}
                    className="p-4 border rounded-lg"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center">
                          {endpoint.direction === 'in' && <Download className="h-4 w-4 mr-2 text-blue-500" />}
                          {endpoint.direction === 'out' && <Upload className="h-4 w-4 mr-2 text-green-500" />}
                          <h3 className="font-medium text-foreground">{endpoint.name}</h3>
                        </div>
                        <p className="mt-1 text-sm text-muted-foreground">{endpoint.description}</p>
                        
                        <div className="mt-2 flex flex-wrap gap-2">
                          <Badge variant="outline" className="text-foreground">
                            {endpoint.direction === 'in' ? 'Import' : 'Export'}
                          </Badge>
                          
                          {endpoint.frequency && (
                            <Badge variant="outline" className="text-foreground">
                              {endpoint.frequency}
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex flex-col sm:items-end gap-2">
                        <div className="flex items-center">
                          <span className="text-sm text-muted-foreground mr-2">Enabled</span>
                          <Switch
                            checked={endpoint.enabled}
                            onCheckedChange={(checked) => handleEndpointToggle(endpoint.id, checked)}
                          />
                        </div>
                        
                        {endpoint.enabled && (
                          <Button 
                            size="sm"
                            variant="outline"
                            onClick={() => handleSync(endpoint.id)}
                            disabled={isSyncing[endpoint.id]}
                          >
                            {isSyncing[endpoint.id] ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Syncing...
                              </>
                            ) : (
                              <>
                                <RefreshCw className="mr-2 h-4 w-4" />
                                Sync Now
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Mappings Tab */}
        <TabsContent value="mappings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <LinkIcon className="mr-2 h-5 w-5" />
                Data Mappings
              </CardTitle>
              <CardDescription>
                Configure how data fields map between DockSafe and {sampleSystems.find(s => s.id === selectedSystem)?.name}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-muted/50">
                      <th className="px-3 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Source Field</th>
                      <th className="px-3 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Target Field</th>
                      <th className="px-3 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wider">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {sampleMappings.map((mapping) => (
                      <tr key={mapping.id} className="hover:bg-muted/30">
                        <td className="px-3 py-3 text-sm">
                          <div className="flex items-center">
                            <Badge variant="outline" className="mr-2 font-mono text-xs">
                              {mapping.source.split('.')[0]}
                            </Badge>
                            <span className="text-foreground">{mapping.source.split('.').slice(1).join('.')}</span>
                          </div>
                        </td>
                        <td className="px-3 py-3 text-sm">
                          <div className="flex items-center">
                            <Badge variant="outline" className="mr-2 font-mono text-xs">
                              {mapping.target.split('.')[0]}
                            </Badge>
                            <span className="text-foreground">{mapping.target.split('.').slice(1).join('.')}</span>
                          </div>
                        </td>
                        <td className="px-3 py-3 text-sm text-right">
                          {mapping.status === 'mapped' ? (
                            <Badge variant="success" className="bg-green-500 text-white">
                              <Check className="h-3 w-3 mr-1" />
                              Mapped
                            </Badge>
                          ) : (
                            <Button 
                              size="sm" 
                              variant="outline"
                              className="text-xs h-7"
                              onClick={() => handleUpdateMapping(mapping.id)}
                            >
                              Map Field
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              {sampleMappings.some(m => m.status !== 'mapped') && (
                <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 p-3 rounded-md mt-4">
                  <div className="flex items-start">
                    <FileWarning className="h-5 w-5 text-yellow-500 mt-0.5 mr-2 flex-shrink-0" />
                    <div>
                      <h4 className="font-medium text-sm text-foreground">Mapping Validation</h4>
                      <p className="text-sm mt-1 text-muted-foreground">
                        Some fields remain unmapped. Missing mappings may cause partial data synchronization
                        between DockSafe and {sampleSystems.find(s => s.id === selectedSystem)?.name}.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Recent Sync Activity */}
      {selectedSystem && isConnected && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <Clock className="mr-2 h-5 w-5" />
              Recent Synchronization Activity
            </CardTitle>
            <CardDescription>
              History of data syncs between DockSafe and {sampleSystems.find(s => s.id === selectedSystem)?.name}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-border">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="px-3 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Time</th>
                    <th className="px-3 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Event</th>
                    <th className="px-3 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Status</th>
                    <th className="px-3 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Message</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {sampleSyncHistory.map((log) => (
                    <tr key={log.id} className="hover:bg-muted/30">
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-foreground">
                        {formatDate(log.timestamp)}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-foreground">
                        <div className="flex items-center">
                          {log.event.includes('Pull') && <Download className="h-4 w-4 mr-1 text-blue-500" />}
                          {log.event.includes('Push') && <Upload className="h-4 w-4 mr-1 text-green-500" />}
                          {log.event === 'System Sync' && <RefreshCw className="h-4 w-4 mr-1 text-purple-500" />}
                          {log.event}
                        </div>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm">
                        {log.status === 'success' && (
                          <Badge variant="success" className="bg-green-500 text-white">Success</Badge>
                        )}
                        {log.status === 'error' && (
                          <Badge variant="destructive">Error</Badge>
                        )}
                        {log.status === 'warning' && (
                          <Badge variant="warning" className="bg-yellow-500 text-white">Warning</Badge>
                        )}
                      </td>
                      <td className="px-3 py-3 text-sm text-foreground">
                        {log.message}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" size="sm" className="ml-auto">
              View All Activity
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
};

export default FixedIntegrationPanel;
import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Bell, Calendar, Clock, AlertTriangle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

// Types
interface MaintenanceNotification {
  id: number;
  title: string;
  type: 'overdue' | 'upcoming' | 'urgent' | 'completed';
  dockId: number;
  dockName: string;
  date: string;
  message: string;
  read: boolean;
}

// Sample notification data (would come from API in production)
const sampleNotifications: MaintenanceNotification[] = [
  {
    id: 1,
    title: 'Overdue Maintenance',
    type: 'overdue',
    dockId: 103,
    dockName: 'Dock 103',
    date: new Date(Date.now() - 86400000 * 5).toISOString(), // 5 days ago
    message: 'Vehicle restraint sensor repair is 5 days overdue',
    read: false,
  },
  {
    id: 2,
    title: 'Scheduled Maintenance',
    type: 'upcoming',
    dockId: 100,
    dockName: 'Dock 100',
    date: new Date(Date.now() + 86400000 * 2).toISOString(), // 2 days from now
    message: 'Hydraulic cylinder replacement scheduled',
    read: false,
  },
  {
    id: 3,
    title: 'Urgent Repair Needed',
    type: 'urgent',
    dockId: 212,
    dockName: 'Dock 212',
    date: new Date().toISOString(), // Today
    message: 'Dock leveler failure detected, immediate attention required',
    read: false,
  },
  {
    id: 4,
    title: 'Maintenance Completed',
    type: 'completed',
    dockId: 107,
    dockName: 'Dock 107',
    date: new Date(Date.now() - 86400000 * 1).toISOString(), // 1 day ago
    message: 'Weather seal replacement has been completed',
    read: true,
  },
];

interface MaintenanceNotificationsProps {
  showAll?: boolean;
}

export const MaintenanceNotifications: React.FC<MaintenanceNotificationsProps> = ({ 
  showAll = false 
}) => {
  const [notifications, setNotifications] = useState<MaintenanceNotification[]>(sampleNotifications);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const { toast } = useToast();

  useEffect(() => {
    // Count unread notifications
    const count = notifications.filter(notification => !notification.read).length;
    setUnreadCount(count);
  }, [notifications]);

  const markAsRead = (id: number) => {
    setNotifications(notifications.map(notification => 
      notification.id === id 
        ? { ...notification, read: true } 
        : notification
    ));
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(notification => ({ ...notification, read: true })));
    toast({
      title: 'Notifications Cleared',
      description: 'All maintenance notifications have been marked as read',
    });
  };

  const getNotificationIcon = (type: MaintenanceNotification['type']) => {
    switch (type) {
      case 'overdue':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'upcoming':
        return <Calendar className="h-5 w-5 text-blue-500" />;
      case 'urgent':
        return <AlertTriangle className="h-5 w-5 text-orange-500" />;
      case 'completed':
        return <Clock className="h-5 w-5 text-green-500" />;
      default:
        return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };

  const getNotificationTypeBadge = (type: MaintenanceNotification['type']) => {
    switch (type) {
      case 'overdue':
        return <Badge variant="destructive">Overdue</Badge>;
      case 'upcoming':
        return <Badge variant="secondary">Upcoming</Badge>;
      case 'urgent':
        return <Badge variant="warning">Urgent</Badge>;
      case 'completed':
        return <Badge variant="success">Completed</Badge>;
      default:
        return <Badge>Notification</Badge>;
    }
  };

  const displayedNotifications = showAll 
    ? notifications 
    : notifications.filter(notification => !notification.read).slice(0, 3);

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-medium flex items-center">
          <Bell className="mr-2 h-5 w-5" />
          Maintenance Notifications
          {unreadCount > 0 && (
            <Badge variant="default" className="ml-2 bg-red-500 hover:bg-red-700">
              {unreadCount}
            </Badge>
          )}
        </CardTitle>
        {unreadCount > 0 && (
          <Button variant="ghost" size="sm" onClick={markAllAsRead}>
            Mark All as Read
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {displayedNotifications.length > 0 ? (
          <div className="space-y-4">
            {displayedNotifications.map((notification) => (
              <div 
                key={notification.id}
                className={`p-3 rounded-md flex items-start space-x-3 ${
                  notification.read 
                    ? 'bg-gray-100 dark:bg-gray-800'
                    : 'bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800'
                }`}
              >
                <div className="flex-shrink-0 mt-1">
                  {getNotificationIcon(notification.type)}
                </div>
                <div className="flex-grow">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium text-sm">
                        {notification.title}
                      </h4>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {notification.dockName} • {new Date(notification.date).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      {getNotificationTypeBadge(notification.type)}
                    </div>
                  </div>
                  <p className="mt-1 text-sm">{notification.message}</p>
                  {!notification.read && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => markAsRead(notification.id)}
                      className="mt-2 text-xs h-7 px-2"
                    >
                      Mark as Read
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6 text-gray-500 dark:text-gray-400">
            <Bell className="mx-auto h-8 w-8 mb-2 opacity-30" />
            <p>No unread maintenance notifications</p>
          </div>
        )}
        
        {!showAll && notifications.filter(n => !n.read).length > 3 && (
          <div className="mt-4 text-center">
            <Button variant="outline" size="sm" asChild>
              <a href="/maintenance/notifications">View All ({unreadCount})</a>
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default MaintenanceNotifications;
import React, { useEffect, useState } from 'react';
import { 
  connectWebSocket, 
  disconnectWebSocket, 
  subscribeToNotifications,
  type NotificationMessage,
  type SafetyNotification
} from '@/lib/websocket';
import { AlertCircle, CheckCircle, Info, AlertTriangle, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function NotificationCenter() {
  const [notifications, setNotifications] = useState<SafetyNotification[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    // Connect to WebSocket when component mounts
    connectWebSocket();

    // Subscribe to notifications
    const unsubscribe = subscribeToNotifications((notification: NotificationMessage) => {
      if (notification.type === 'safety_alert') {
        // Add new safety alert to our state
        setNotifications(prev => [notification, ...prev].slice(0, 10)); // Keep only 10 most recent

        // Also show a toast notification
        toast({
          title: notification.title,
          description: notification.message,
          variant: getVariantFromSeverity(notification.severity),
        });
      }
    });

    // Clean up on component unmount
    return () => {
      unsubscribe();
      disconnectWebSocket();
    };
  }, [toast]);

  // Don't render anything visible - this component just handles the WebSocket connection
  // and displays toast notifications
  return null;
}

// Helper function to map severity to toast variant
function getVariantFromSeverity(severity: string): 'default' | 'destructive' {
  switch (severity) {
    case 'error':
      return 'destructive';
    default:
      return 'default';
  }
}

// Notification icon based on severity
export function NotificationIcon({ severity }: { severity: string }) {
  switch (severity) {
    case 'success':
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    case 'warning':
      return <AlertTriangle className="h-4 w-4 text-amber-500" />;
    case 'error':
      return <AlertCircle className="h-4 w-4 text-red-500" />;
    case 'info':
    default:
      return <Info className="h-4 w-4 text-blue-500" />;
  }
}

// Safety notification display component - can be used elsewhere in the app
export function SafetyAlert({ notification }: { notification: SafetyNotification }) {
  return (
    <div className={`rounded-md border p-4 mb-3 ${getSeverityClass(notification.severity)}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <NotificationIcon severity={notification.severity} />
          <span className="ml-2 font-semibold">{notification.title}</span>
        </div>
        <time className="text-xs text-gray-500">
          {new Date(notification.timestamp).toLocaleTimeString()}
        </time>
      </div>
      <div className="mt-2 text-sm">
        {notification.message}
      </div>
      {notification.location && (
        <div className="mt-1 text-xs text-gray-600">
          Location: {notification.location}
        </div>
      )}
    </div>
  );
}

// Helper function to get CSS classes based on severity
function getSeverityClass(severity: string): string {
  switch (severity) {
    case 'success':
      return 'bg-green-50 border-green-200';
    case 'warning':
      return 'bg-amber-50 border-amber-200';
    case 'error':
      return 'bg-red-50 border-red-200';
    case 'info':
    default:
      return 'bg-blue-50 border-blue-200';
  }
}
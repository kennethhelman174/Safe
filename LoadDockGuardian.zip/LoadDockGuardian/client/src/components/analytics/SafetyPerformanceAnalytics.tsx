import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { 
  BarChart, 
  Bar, 
  LineChart,
  Line,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from 'recharts';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  AlertTriangle, 
  BarChart2, 
  CheckCircle, 
  Clock, 
  TrendingUp, 
  XCircle, 
  LineChart as LineChartIcon,
  PieChart as PieChartIcon,
  CalendarDays,
  Users,
  Target
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

// Sample data - in a real application, this would come from the API
const incidentTrendData = [
  { month: 'Jan', count: 3, severity: 2.3 },
  { month: 'Feb', count: 2, severity: 1.5 },
  { month: 'Mar', count: 5, severity: 2.7 },
  { month: 'Apr', count: 1, severity: 1.0 },
  { month: 'May', count: 0, severity: 0 },
  { month: 'Jun', count: 2, severity: 1.8 },
  { month: 'Jul', count: 1, severity: 1.2 },
  { month: 'Aug', count: 0, severity: 0 },
  { month: 'Sep', count: 3, severity: 2.0 },
  { month: 'Oct', count: 1, severity: 1.5 },
  { month: 'Nov', count: 2, severity: 1.9 },
  { month: 'Dec', count: 0, severity: 0 },
];

const safetyComplianceData = [
  { month: 'Jan', rate: 92 },
  { month: 'Feb', rate: 94 },
  { month: 'Mar', rate: 91 },
  { month: 'Apr', rate: 96 },
  { month: 'May', rate: 98 },
  { month: 'Jun', rate: 97 },
  { month: 'Jul', rate: 99 },
  { month: 'Aug', rate: 98 },
  { month: 'Sep', rate: 97 },
  { month: 'Oct', rate: 95 },
  { month: 'Nov', rate: 99 },
  { month: 'Dec', rate: 98 },
];

const incidentByTypeData = [
  { name: 'Equipment Failure', value: 35, color: '#f59e0b' },
  { name: 'Operator Error', value: 25, color: '#ef4444' },
  { name: 'Maintenance Issues', value: 20, color: '#8b5cf6' },
  { name: 'Environmental', value: 15, color: '#10b981' },
  { name: 'Other', value: 5, color: '#6b7280' },
];

const incidentByLocationData = [
  { name: 'Shipping Docks', value: 40, color: '#3b82f6' },
  { name: 'Receiving Docks', value: 30, color: '#8b5cf6' },
  { name: 'Export Shipping', value: 20, color: '#10b981' },
  { name: 'Export Receiving', value: 10, color: '#f59e0b' },
];

const safetyDimensionsData = [
  { subject: 'Training', A: 85, B: 90, fullMark: 100 },
  { subject: 'Equipment', A: 92, B: 95, fullMark: 100 },
  { subject: 'Procedures', A: 78, B: 85, fullMark: 100 },
  { subject: 'Reporting', A: 95, B: 97, fullMark: 100 },
  { subject: 'Maintenance', A: 87, B: 91, fullMark: 100 },
  { subject: 'Response Time', A: 83, B: 89, fullMark: 100 },
];

const checklistCompletionByDockData = [
  { name: 'Dock 100-112', completed: 98, target: 100 },
  { name: 'Dock 113-129', completed: 92, target: 100 },
  { name: 'Dock 200-212', completed: 95, target: 100 },
  { name: 'Dock 213-222', completed: 90, target: 100 },
];

const SafetyPerformanceAnalytics: React.FC = () => {
  const [timeframe, setTimeframe] = useState('year');
  const [benchmarkVisible, setBenchmarkVisible] = useState(true);
  
  // Calculate current safety metrics
  const currentMonth = new Date().getMonth();
  const daysSinceLastIncident = 28; // This would come from the API in a real application
  const currentSafetyScore = safetyComplianceData[currentMonth]?.rate || 95;
  const incidentCountLastYear = incidentTrendData.reduce((sum, item) => sum + item.count, 0);
  const avgSeverity = incidentTrendData.reduce((sum, item) => sum + item.severity, 0) / 
    incidentTrendData.filter(item => item.severity > 0).length;
    
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold flex items-center">
          <Target className="mr-2 h-6 w-6 text-primary" />
          Safety Performance Analytics
        </h2>
        <div className="flex space-x-4">
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-[150px]">
              <CalendarDays className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Select timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="month">Last 30 Days</SelectItem>
              <SelectItem value="quarter">Last Quarter</SelectItem>
              <SelectItem value="year">Last Year</SelectItem>
              <SelectItem value="custom">Custom Range</SelectItem>
            </SelectContent>
          </Select>
          <Button 
            variant={benchmarkVisible ? "default" : "outline"} 
            size="sm"
            onClick={() => setBenchmarkVisible(!benchmarkVisible)}
          >
            <Users className="w-4 h-4 mr-2" />
            Industry Benchmarks
          </Button>
        </div>
      </div>
      
      {/* Summary metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-green-800 dark:text-green-300">
                  Days Since Last Incident
                </p>
                <h3 className="text-3xl font-bold text-green-700 dark:text-green-400 mt-1">
                  {daysSinceLastIncident}
                </h3>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-500" />
            </div>
            <p className="text-xs text-green-700 dark:text-green-300 mt-2">
              Previous record: 42 days
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-blue-800 dark:text-blue-300">
                  Current Safety Score
                </p>
                <h3 className="text-3xl font-bold text-blue-700 dark:text-blue-400 mt-1">
                  {currentSafetyScore}%
                </h3>
              </div>
              <TrendingUp className="h-8 w-8 text-blue-600 dark:text-blue-500" />
            </div>
            <p className="text-xs text-blue-700 dark:text-blue-300 mt-2">
              <span className="text-green-600 dark:text-green-400">↑ 3%</span> from last month
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-amber-800 dark:text-amber-300">
                  Total Incidents (Year)
                </p>
                <h3 className="text-3xl font-bold text-amber-700 dark:text-amber-400 mt-1">
                  {incidentCountLastYear}
                </h3>
              </div>
              <AlertTriangle className="h-8 w-8 text-amber-600 dark:text-amber-500" />
            </div>
            <p className="text-xs text-amber-700 dark:text-amber-300 mt-2">
              <span className="text-green-600 dark:text-green-400">↓ 15%</span> from previous year
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-800">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm font-medium text-purple-800 dark:text-purple-300">
                  Average Incident Severity
                </p>
                <h3 className="text-3xl font-bold text-purple-700 dark:text-purple-400 mt-1">
                  {avgSeverity.toFixed(1)}
                </h3>
              </div>
              <Clock className="h-8 w-8 text-purple-600 dark:text-purple-500" />
            </div>
            <p className="text-xs text-purple-700 dark:text-purple-300 mt-2">
              Scale: 1 (Minor) to 5 (Critical)
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Advanced analytics tabs */}
      <Tabs defaultValue="trends">
        <TabsList className="grid grid-cols-4 mb-6">
          <TabsTrigger value="trends" className="flex items-center">
            <LineChartIcon className="h-4 w-4 mr-2" />
            <span className="hidden md:inline">Incident Trends</span>
            <span className="md:hidden">Trends</span>
          </TabsTrigger>
          <TabsTrigger value="distribution" className="flex items-center">
            <PieChartIcon className="h-4 w-4 mr-2" />
            <span className="hidden md:inline">Distribution</span>
            <span className="md:hidden">Types</span>
          </TabsTrigger>
          <TabsTrigger value="compliance" className="flex items-center">
            <BarChart2 className="h-4 w-4 mr-2" />
            <span className="hidden md:inline">Compliance</span>
            <span className="md:hidden">Comply</span>
          </TabsTrigger>
          <TabsTrigger value="dimensions" className="flex items-center">
            <Target className="h-4 w-4 mr-2" />
            <span className="hidden md:inline">Safety Dimensions</span>
            <span className="md:hidden">Dims</span>
          </TabsTrigger>
        </TabsList>
        
        {/* Incident Trends Tab */}
        <TabsContent value="trends">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="h-5 w-5 mr-2 text-primary" />
                Incident Trends Over Time
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Tracking both incident count and severity over the past 12 months
                </p>
              </div>
              
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={incidentTrendData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 15 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" opacity={0.7} />
                    <XAxis dataKey="month" />
                    <YAxis yAxisId="left" label={{ value: 'Incident Count', angle: -90, position: 'insideLeft' }} />
                    <YAxis yAxisId="right" orientation="right" label={{ value: 'Severity (1-5)', angle: 90, position: 'insideRight' }} />
                    <Tooltip />
                    <Legend verticalAlign="top" wrapperStyle={{ paddingBottom: 10 }} />
                    <Line
                      yAxisId="left"
                      type="monotone"
                      dataKey="count"
                      name="Incidents"
                      stroke="#ef4444"
                      strokeWidth={2}
                      activeDot={{ r: 8 }}
                    />
                    <Line
                      yAxisId="right"
                      type="monotone"
                      dataKey="severity"
                      name="Avg. Severity"
                      stroke="#8b5cf6"
                      strokeWidth={2}
                    />
                    {benchmarkVisible && (
                      <Line
                        yAxisId="left"
                        type="monotone"
                        dataKey={() => 2.4}
                        name="Industry Avg"
                        stroke="#9ca3af"
                        strokeDasharray="5 5"
                      />
                    )}
                  </LineChart>
                </ResponsiveContainer>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div className="p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
                  <h4 className="text-sm font-medium mb-2">Key Finding</h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Incidents have decreased by 32% compared to previous year, with severity dropping 18%.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-red-50 dark:bg-red-900/20">
                  <h4 className="text-sm font-medium mb-2">Action Item</h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Focus improvement efforts on March, which shows consistently higher incident rates.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Distribution Tab */}
        <TabsContent value="distribution">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <XCircle className="h-5 w-5 mr-2 text-primary" />
                  Incidents by Type
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={incidentByTypeData}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {incidentByTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value}%`, 'Percentage']} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4">
                  <Badge className="mr-2 bg-amber-500 hover:bg-amber-600">Priority</Badge>
                  <p className="mt-2 text-sm">
                    Equipment failures account for 35% of all incidents. Recommend increasing preventive maintenance frequency.
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <XCircle className="h-5 w-5 mr-2 text-primary" />
                  Incidents by Location
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={incidentByLocationData}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {incidentByLocationData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value}%`, 'Percentage']} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4">
                  <Badge className="mr-2 bg-blue-500 hover:bg-blue-600">Focus Area</Badge>
                  <p className="mt-2 text-sm">
                    Shipping docks (100-112) have the highest incident rate at 40%. Schedule additional safety training for staff.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* Compliance Tab */}
        <TabsContent value="compliance">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-primary" />
                Safety Compliance Rate
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Checklist completion rates and safety protocol adherence
                </p>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={safetyComplianceData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis domain={[80, 100]} label={{ value: 'Compliance %', angle: -90, position: 'insideLeft' }} />
                      <Tooltip />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="rate"
                        name="Compliance Rate"
                        stroke="#10b981"
                        strokeWidth={2}
                        activeDot={{ r: 8 }}
                      />
                      {benchmarkVisible && (
                        <Line
                          type="monotone"
                          dataKey={() => 90}
                          name="Industry Standard"
                          stroke="#9ca3af"
                          strokeDasharray="5 5"
                        />
                      )}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={checklistCompletionByDockData}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis domain={[80, 100]} label={{ value: 'Completion %', angle: -90, position: 'insideLeft' }} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="completed" name="Completion Rate" fill="#3b82f6" />
                      <Bar dataKey="target" name="Target" fill="#d1d5db" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              <div className="mt-6 p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
                <h4 className="text-sm font-medium mb-2">Safety Observation</h4>
                <p className="text-sm">
                  Overall compliance is excellent at 98%, exceeding industry standards. Areas for improvement:
                </p>
                <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                  <li>Export receiving docks (213-222) have the lowest completion rate (90%)</li>
                  <li>March showed temporary compliance drop after new procedure implementation</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Safety Dimensions Tab */}
        <TabsContent value="dimensions">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="h-5 w-5 mr-2 text-primary" />
                Safety Performance Dimensions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Multi-dimensional analysis of safety performance compared to targets
                </p>
              </div>
              
              <div className="h-96">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart outerRadius={150} data={safetyDimensionsData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" />
                    <PolarRadiusAxis angle={90} domain={[0, 100]} />
                    <Radar
                      name="Current Period"
                      dataKey="A"
                      stroke="#3b82f6"
                      fill="#3b82f6"
                      fillOpacity={0.5}
                    />
                    {benchmarkVisible && (
                      <Radar
                        name="Target"
                        dataKey="B"
                        stroke="#f59e0b"
                        fill="#f59e0b"
                        fillOpacity={0.2}
                      />
                    )}
                    <Legend />
                    <Tooltip />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
              
              <div className="mt-4 grid grid-cols-3 md:grid-cols-6 gap-2">
                {safetyDimensionsData.map((dimension) => (
                  <div 
                    key={dimension.subject} 
                    className={`p-3 rounded-md border text-center ${
                      dimension.A >= 90 
                        ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' 
                        : dimension.A >= 80 
                          ? 'bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800'
                          : 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
                    }`}
                  >
                    <div className="text-xs font-medium">{dimension.subject}</div>
                    <div className={`text-xl font-bold ${
                      dimension.A >= 90 
                        ? 'text-green-600 dark:text-green-400' 
                        : dimension.A >= 80 
                          ? 'text-amber-600 dark:text-amber-400'
                          : 'text-red-600 dark:text-red-400'
                    }`}>
                      {dimension.A}%
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SafetyPerformanceAnalytics;
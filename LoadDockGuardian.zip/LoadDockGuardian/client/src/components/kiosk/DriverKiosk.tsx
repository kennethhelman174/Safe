import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Truck, ClipboardCheck, Globe } from 'lucide-react';
import { t, getLanguage, setLanguage } from '@/lib/i18n';
import LanguageSelector from './LanguageSelector';

interface DriverInfo {
  driverName: string;
  companyName: string;
  truckNumber: string;
  trailerNumber: string;
  phoneNumber: string;
  dockNumber: string;
  trailerType: 'liveLoad' | 'dropTrailer';
}

interface DriverKioskProps {
  onComplete?: (info: DriverInfo) => void;
}

const DriverKiosk: React.FC<DriverKioskProps> = ({ onComplete }) => {
  const [step, setStep] = useState<'driverInfo' | 'dockSelection' | 'safetyCheck'>('driverInfo');
  const [driverInfo, setDriverInfo] = useState<DriverInfo>({
    driverName: '',
    companyName: '',
    truckNumber: '',
    trailerNumber: '',
    phoneNumber: '',
    dockNumber: '',
    trailerType: 'liveLoad'
  });
  const [language, setCurrentLanguage] = useState(getLanguage());
  const { toast } = useToast();
  
  // Force component re-render when language changes
  const handleLanguageChange = (lang: string) => {
    setCurrentLanguage(lang as any);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setDriverInfo(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setDriverInfo(prev => ({ ...prev, [name]: value }));
  };

  const handleRadioChange = (value: 'liveLoad' | 'dropTrailer') => {
    setDriverInfo(prev => ({ ...prev, trailerType: value }));
  };

  const handleNextStep = () => {
    if (step === 'driverInfo') {
      // Validate driver info
      if (!driverInfo.driverName || !driverInfo.companyName || !driverInfo.truckNumber) {
        toast({
          title: t("notify.missingInfo"),
          description: t("notify.requiredFields"),
          variant: "destructive"
        });
        return;
      }
      setStep('dockSelection');
    } else if (step === 'dockSelection') {
      // Validate dock selection
      if (!driverInfo.dockNumber) {
        toast({
          title: t("notify.missingInfo"),
          description: t("notify.selectDock"),
          variant: "destructive"
        });
        return;
      }
      setStep('safetyCheck');
    } else {
      // Safety check completion - submit all data
      if (onComplete) {
        onComplete(driverInfo);
      }
      
      toast({
        title: t("notify.checkInComplete"),
        description: t("notify.successfulCheckIn"),
      });
      
      // Reset form for next driver
      setDriverInfo({
        driverName: '',
        companyName: '',
        truckNumber: '',
        trailerNumber: '',
        phoneNumber: '',
        dockNumber: '',
        trailerType: 'liveLoad'
      });
      setStep('driverInfo');
    }
  };

  const handlePreviousStep = () => {
    if (step === 'dockSelection') {
      setStep('driverInfo');
    } else if (step === 'safetyCheck') {
      setStep('dockSelection');
    }
  };

  const renderDriverInfoStep = () => (
    <>
      <div className="space-y-4">
        <div className="grid grid-cols-1 gap-4">
          <div className="space-y-2">
            <Label htmlFor="driverName">{t("driver.name")} *</Label>
            <Input 
              id="driverName" 
              name="driverName" 
              placeholder={t("driver.name")} 
              value={driverInfo.driverName}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="companyName">{t("driver.company")} *</Label>
            <Input 
              id="companyName" 
              name="companyName" 
              placeholder={t("driver.company")} 
              value={driverInfo.companyName}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="phoneNumber">{t("driver.phone")}</Label>
            <Input 
              id="phoneNumber" 
              name="phoneNumber" 
              placeholder={t("driver.phone")} 
              value={driverInfo.phoneNumber}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="truckNumber">{t("driver.truck")} *</Label>
            <Input 
              id="truckNumber" 
              name="truckNumber" 
              placeholder={t("driver.truck")} 
              value={driverInfo.truckNumber}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="trailerNumber">{t("driver.trailer")}</Label>
            <Input 
              id="trailerNumber" 
              name="trailerNumber" 
              placeholder={t("driver.trailer")} 
              value={driverInfo.trailerNumber}
              onChange={handleInputChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label>{t("driver.type")}</Label>
            <RadioGroup 
              defaultValue="liveLoad" 
              value={driverInfo.trailerType} 
              onValueChange={(value) => handleRadioChange(value as 'liveLoad' | 'dropTrailer')}
              className="flex flex-col space-y-1"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="liveLoad" id="kiosk-live-load" />
                <Label htmlFor="kiosk-live-load" className="font-medium">{t("driver.type.liveLoad")}</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="dropTrailer" id="kiosk-drop-trailer" />
                <Label htmlFor="kiosk-drop-trailer" className="font-medium">{t("driver.type.dropTrailer")}</Label>
              </div>
            </RadioGroup>
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <Button onClick={handleNextStep}>{t("button.next")}</Button>
      </div>
    </>
  );

  const renderDockSelectionStep = () => (
    <>
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="dockNumber">Select Dock Number *</Label>
          <div className="pt-2">
            <Tabs defaultValue="shipping">
              <TabsList className="w-full">
                <TabsTrigger className="flex-1" value="shipping">Shipping (100-112)</TabsTrigger>
                <TabsTrigger className="flex-1" value="export-shipping">Export Shipping (113-129)</TabsTrigger>
                <TabsTrigger className="flex-1" value="receiving">Receiving (200-212)</TabsTrigger>
                <TabsTrigger className="flex-1" value="export-receiving">Export Receiving (213-222)</TabsTrigger>
              </TabsList>
              
              <TabsContent value="shipping" className="pt-4">
                <div className="grid grid-cols-4 gap-2">
                  {Array.from({ length: 13 }, (_, i) => i + 100).map(dock => (
                    <Button 
                      key={dock}
                      variant={driverInfo.dockNumber === dock.toString() ? "default" : "outline"}
                      onClick={() => handleSelectChange('dockNumber', dock.toString())}
                      className="h-16 text-lg"
                    >
                      {dock}
                    </Button>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="export-shipping" className="pt-4">
                <div className="grid grid-cols-4 gap-2">
                  {Array.from({ length: 17 }, (_, i) => i + 113).map(dock => (
                    <Button 
                      key={dock}
                      variant={driverInfo.dockNumber === dock.toString() ? "default" : "outline"}
                      onClick={() => handleSelectChange('dockNumber', dock.toString())}
                      className="h-16 text-lg"
                    >
                      {dock}
                    </Button>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="receiving" className="pt-4">
                <div className="grid grid-cols-4 gap-2">
                  {Array.from({ length: 13 }, (_, i) => i + 200).map(dock => (
                    <Button 
                      key={dock}
                      variant={driverInfo.dockNumber === dock.toString() ? "default" : "outline"}
                      onClick={() => handleSelectChange('dockNumber', dock.toString())}
                      className="h-16 text-lg"
                    >
                      {dock}
                    </Button>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="export-receiving" className="pt-4">
                <div className="grid grid-cols-4 gap-2">
                  {Array.from({ length: 10 }, (_, i) => i + 213).map(dock => (
                    <Button 
                      key={dock}
                      variant={driverInfo.dockNumber === dock.toString() ? "default" : "outline"}
                      onClick={() => handleSelectChange('dockNumber', dock.toString())}
                      className="h-16 text-lg"
                    >
                      {dock}
                    </Button>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
      
      <div className="flex justify-between">
        <Button variant="outline" onClick={handlePreviousStep}>Back</Button>
        <Button onClick={handleNextStep}>Next</Button>
      </div>
    </>
  );

  const renderSafetyCheckStep = () => {
    const safetyItems = driverInfo.trailerType === 'liveLoad' 
      ? [
          { id: 1, text: "Wheel Chocks in Place" },
          { id: 2, text: "Restraint Engaged" },
          { id: 3, text: "Signal Lights Active" },
          { id: 4, text: "Vehicle Turned Off" },
          { id: 5, text: "Glad Hand Lock Placed" }
        ]
      : [
          { id: 1, text: "Wheel Chocks in Place" },
          { id: 2, text: "Glad Hand Lock Placed" },
          { id: 3, text: "Restraint Engaged" },
          { id: 4, text: "Signal Lights Active" },
          { id: 5, text: "Trailer Jack Stand Placed" }
        ];
    
    return (
      <>
        <div className="space-y-4">
          <div className="border p-4 rounded-md bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800">
            <h3 className="text-center text-lg font-medium mb-2">Safety Confirmation</h3>
            <p className="text-center text-sm">
              By completing this check-in, I confirm that all safety protocols for a {" "}
              <span className="font-semibold">{driverInfo.trailerType === 'liveLoad' ? 'Live Load' : 'Drop Trailer'}</span>
              {" "} have been followed, including:
            </p>
            
            <ul className="mt-4 space-y-2">
              {safetyItems.map(item => (
                <li key={item.id} className="flex items-center space-x-2">
                  <ClipboardCheck className="text-green-500 dark:text-green-600 h-5 w-5" />
                  <span>{item.text}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="border p-4 rounded-md">
            <h3 className="text-lg font-medium mb-2">Your Information</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <span className="font-semibold">Driver Name:</span> {driverInfo.driverName}
              </div>
              <div>
                <span className="font-semibold">Company:</span> {driverInfo.companyName}
              </div>
              <div>
                <span className="font-semibold">Truck #:</span> {driverInfo.truckNumber}
              </div>
              <div>
                <span className="font-semibold">Trailer #:</span> {driverInfo.trailerNumber || "N/A"}
              </div>
              <div>
                <span className="font-semibold">Dock Number:</span> {driverInfo.dockNumber}
              </div>
              <div>
                <span className="font-semibold">Trailer Type:</span> {driverInfo.trailerType === 'liveLoad' ? 'Live Load' : 'Drop Trailer'}
              </div>
              <div>
                <span className="font-semibold">Phone:</span> {driverInfo.phoneNumber || "N/A"}
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between">
          <Button variant="outline" onClick={handlePreviousStep}>Back</Button>
          <Button onClick={handleNextStep}>Complete Check-In</Button>
        </div>
      </>
    );
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader className="pb-3 border-b">
        <CardTitle className="flex items-center text-xl font-bold">
          <Truck className="mr-2 h-6 w-6 text-primary" />
          Driver Check-In Kiosk
        </CardTitle>
      </CardHeader>
      
      <CardContent className="pt-6 pb-4">
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center space-x-2">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center text-white ${step === 'driverInfo' ? 'bg-primary' : 'bg-primary/60'}`}>1</div>
              <span className={step === 'driverInfo' ? 'font-medium' : 'text-gray-500 dark:text-gray-400'}>Driver Information</span>
            </div>
            <div className="h-px bg-gray-200 dark:bg-gray-700 w-12 flex-shrink-0"></div>
            <div className="flex items-center space-x-2">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center text-white ${step === 'dockSelection' ? 'bg-primary' : step === 'safetyCheck' ? 'bg-primary/60' : 'bg-gray-300 dark:bg-gray-700'}`}>2</div>
              <span className={step === 'dockSelection' ? 'font-medium' : step === 'safetyCheck' ? 'text-gray-500 dark:text-gray-400' : 'text-gray-400 dark:text-gray-500'}>Dock Selection</span>
            </div>
            <div className="h-px bg-gray-200 dark:bg-gray-700 w-12 flex-shrink-0"></div>
            <div className="flex items-center space-x-2">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center text-white ${step === 'safetyCheck' ? 'bg-primary' : 'bg-gray-300 dark:bg-gray-700'}`}>3</div>
              <span className={step === 'safetyCheck' ? 'font-medium' : 'text-gray-400 dark:text-gray-500'}>Safety Check</span>
            </div>
          </div>
          
          <div className="h-1 bg-gray-100 dark:bg-gray-800 rounded-full w-full mt-2">
            <div 
              className="h-1 bg-primary rounded-full transition-all duration-300"
              style={{ width: step === 'driverInfo' ? '33%' : step === 'dockSelection' ? '66%' : '100%' }}
            ></div>
          </div>
        </div>
        
        {step === 'driverInfo' && renderDriverInfoStep()}
        {step === 'dockSelection' && renderDockSelectionStep()}
        {step === 'safetyCheck' && renderSafetyCheckStep()}
      </CardContent>
    </Card>
  );
};

export default DriverKiosk;
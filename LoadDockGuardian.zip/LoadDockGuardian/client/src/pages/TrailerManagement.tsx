import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import MainLayout from '@/components/layout/MainLayout';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { insertVehicleSchema } from '@shared/schema';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { useToast } from '@/hooks/use-toast';

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { PencilIcon, XCircleIcon, CheckSquare, Truck, CircleDashed, Loader2 } from 'lucide-react';

// Enhanced schema for trailer management
const trailerSchema = z.object({
  trailerNumber: z.string().min(1, "Trailer number is required"),
  driverName: z.string().optional(),
  company: z.string().optional(),
  status: z.string().optional().default("checked_in"),
  notes: z.string().optional(),
});

// Schema for safety checklist
const safetyChecklistSchema = z.object({
  dockId: z.number(),
  vehicleId: z.number(),
  checklistResults: z.array(z.object({
    itemId: z.number(),
    passed: z.boolean(),
    notes: z.string().optional(),
  })),
  notes: z.string().optional(),
});

type TrailerFormValues = z.infer<typeof trailerSchema>;
type ChecklistFormValues = z.infer<typeof safetyChecklistSchema>;

type ChecklistItem = {
  id: number;
  text: string;
  category: string;
  isCritical?: boolean;
  description?: string;
  sortOrder?: number;
};

// Status badge component
const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const getVariant = () => {
    switch(status) {
      case 'checked_in': return 'default';
      case 'assigned': return 'secondary';
      case 'pending_safety_check': return 'warning';
      case 'docked': return 'success';
      case 'loading': return 'destructive';
      case 'ready_to_depart': return 'outline';
      case 'departed': return 'default';
      default: return 'secondary';
    }
  };

  // Format the status text
  const formattedStatus = status
    .split('_')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');

  return <Badge variant={getVariant()}>{formattedStatus}</Badge>;
};

const TrailerManagement: React.FC = () => {
  const { toast } = useToast();
  const [selectedTrailer, setSelectedTrailer] = useState<number | null>(null);
  const [openChecklistDialog, setOpenChecklistDialog] = useState(false);
  const [openAssignDialog, setOpenAssignDialog] = useState(false);
  const [openReleaseDialog, setOpenReleaseDialog] = useState(false);

  // Fetch active trailers
  const { data: trailers = [], isLoading: isLoadingTrailers } = useQuery({
    queryKey: ['/api/vehicles/active'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/vehicles/active', null);
      return response.json();
    },
  });

  // Fetch available docks
  const { data: docks = [], isLoading: isLoadingDocks } = useQuery({
    queryKey: ['/api/docks'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/docks', null);
      const data = await response.json();
      // Filter to only return available docks
      return data.filter((dock: any) => dock.status === 'available');
    },
  });

  // Fetch checklist items
  const { data: checklistItems = [], isLoading: isLoadingChecklist } = useQuery<ChecklistItem[]>({
    queryKey: ['/api/checklist-items'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/checklist-items', null);
      return response.json();
    },
  });

  // Create trailer form
  const trailerForm = useForm<TrailerFormValues>({
    resolver: zodResolver(trailerSchema),
    defaultValues: {
      trailerNumber: '',
      driverName: '',
      company: '',
      status: 'checked_in',
      notes: '',
    },
  });
  
  // Assign dock form
  const assignForm = useForm({
    resolver: zodResolver(z.object({
      dockId: z.number(),
    })),
    defaultValues: {
      dockId: 0,
    },
  });

  // Safety checklist form setup (dynamically created based on checklist items)
  const checklistForm = useForm<ChecklistFormValues>({
    resolver: zodResolver(safetyChecklistSchema),
    defaultValues: {
      dockId: 0,
      vehicleId: 0,
      checklistResults: [],
      notes: '',
    },
  });

  // Create new trailer mutation
  const createTrailerMutation = useMutation({
    mutationFn: async (values: TrailerFormValues) => {
      return await apiRequest('POST', '/api/vehicles', values);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "New trailer has been registered.",
      });
      trailerForm.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles/active'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to register trailer: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Step 1: Preliminary dock assignment mutation (office personnel)
  const preliminaryAssignDockMutation = useMutation({
    mutationFn: async (values: { 
      dockId: number, 
      vehicleId: number
    }) => {
      return await apiRequest('PUT', `/api/vehicles/${values.vehicleId}/preliminary-assign`, { 
        dockId: values.dockId
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/docks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles'] });
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles/active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activity-log'] });
      
      toast({
        title: "Preliminary Assignment Complete",
        description: "Dock personnel must now verify the vehicle and complete safety checks",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to assign dock: ${error}`,
        variant: "destructive",
      });
    },
  });
  
  // Step 2: Final dock assignment with safety checks mutation (dock personnel)
  const assignDockMutation = useMutation({
    mutationFn: async (values: { 
      dockId: number, 
      vehicleId: number,
      checklistResults?: Array<{ itemId: number, passed: boolean, notes?: string }> 
    }) => {
      return await apiRequest('PUT', `/api/vehicles/${values.vehicleId}/assign-dock`, { 
        dockId: values.dockId,
        checklistResults: values.checklistResults 
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/docks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles'] });
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles/active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activity-log'] });
      toast({
        title: "Safety Checks Passed",
        description: "All safety requirements verified. Dock has been successfully assigned.",
        variant: "default"
      });
      setOpenAssignDialog(false);
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles/active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/docks'] });
    },
    onError: (error) => {
      // Check if the error is related to safety requirements
      const errorMessage = String(error);
      const isSafetyError = errorMessage.toLowerCase().includes('safety') || 
                            errorMessage.toLowerCase().includes('critical') || 
                            errorMessage.toLowerCase().includes('checklist');
      
      toast({
        title: isSafetyError ? "Safety Check Failed" : "Error",
        description: isSafetyError 
          ? "Critical safety items must pass before dock assignment can be completed." 
          : `Failed to assign dock: ${errorMessage}`,
        variant: "destructive",
      });
    },
  });

  // Complete checklist mutation
  const completeChecklistMutation = useMutation({
    mutationFn: async (values: ChecklistFormValues) => {
      return await apiRequest('POST', '/api/completed-checklists', values);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Safety checklist has been completed.",
      });
      setOpenChecklistDialog(false);
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles/active'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to complete checklist: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Release trailer mutation
  const releaseTrailerMutation = useMutation({
    mutationFn: async (vehicleId: number) => {
      return await apiRequest('PUT', `/api/vehicles/${vehicleId}/exit`, {});
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Trailer has been released.",
      });
      setOpenReleaseDialog(false);
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles/active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/docks'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to release trailer: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Handle trailer form submission
  const onSubmitTrailer = (values: TrailerFormValues) => {
    createTrailerMutation.mutate(values);
  };

  // Handle dock preliminary assignment (Step 1 - Office Personnel)
  const onAssignDock = (values: { dockId: number }) => {
    if (!selectedTrailer) return;
    
    // First step - Make a preliminary assignment without safety checks
    // This assigns the trailer to the dock but marks it as "pending_safety_check"
    toast({
      title: "Dock Assignment Initiated",
      description: "Trailer has been preliminarily assigned. Dock personnel must complete safety checks.",
    });
    
    // Use the preliminary assignment endpoint
    preliminaryAssignDockMutation.mutate({ 
      dockId: values.dockId, 
      vehicleId: selectedTrailer
    });
    
    setOpenAssignDialog(false);
  };

  // Prepare checklist form when a vehicle is selected for dock assignment
  const prepareChecklistForm = (vehicleId: number, dockId: number) => {
    // Initialize checklist form with vehicle and dock IDs, and empty results
    const results = checklistItems.map(item => ({ 
      itemId: item.id, 
      passed: false,
      notes: '' 
    }));
    checklistForm.reset({
      vehicleId,
      dockId,
      checklistResults: results,
      notes: '',
    });
    setOpenChecklistDialog(true);
  };

  // Handle checklist submission and assign dock
  const onSubmitChecklist = (values: ChecklistFormValues) => {
    // First check if any critical items failed
    const checklist = values.checklistResults || [];
    
    // Check critical items against the original checklist items
    const criticalItemsFailed = checklist.some(result => {
      const originalItem = checklistItems.find(item => item.id === result.itemId);
      return originalItem?.isCritical && !result.passed;
    });
    
    if (criticalItemsFailed) {
      toast({
        title: "Safety Check Failed",
        description: "Critical safety items have failed. Cannot assign dock until resolved.",
        variant: "destructive"
      });
      return;
    }
    
    // Now assign the dock with the safety checklist results
    if (!selectedTrailer) return;
    
    assignDockMutation.mutate({ 
      dockId: values.dockId, 
      vehicleId: selectedTrailer,
      checklistResults: values.checklistResults 
    });
    
    setOpenChecklistDialog(false);
  };

  // Handle trailer release
  const onReleaseTrailer = () => {
    if (!selectedTrailer) return;
    releaseTrailerMutation.mutate(selectedTrailer);
  };

  // Get trailer by ID
  const getTrailerById = (id: number) => {
    return trailers.find((trailer: any) => trailer.id === id);
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <MainLayout title="Trailer Management">
      <Tabs defaultValue="active" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="active">Active Trailers</TabsTrigger>
          <TabsTrigger value="register">Register New</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>
        
        {/* Active Trailers Tab */}
        <TabsContent value="active">
          <Card>
            <CardHeader>
              <CardTitle>Active Trailers</CardTitle>
              <CardDescription>
                Manage trailers currently on site, assign to docks, complete safety checklists, and release.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingTrailers ? (
                <div className="flex items-center justify-center h-64">
                  <p>Loading trailers...</p>
                </div>
              ) : trailers.length === 0 ? (
                <div className="bg-muted p-8 rounded-lg text-center">
                  <Truck className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-medium mb-2">No Active Trailers</h3>
                  <p className="text-muted-foreground">
                    There are no active trailers in the yard. Register a new trailer to get started.
                  </p>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Trailer #</TableHead>
                        <TableHead>Company</TableHead>
                        <TableHead>Driver</TableHead>
                        <TableHead>Dock</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Arrival Time</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {trailers.map((trailer: any) => (
                        <TableRow key={trailer.id}>
                          <TableCell className="font-medium">{trailer.trailerNumber}</TableCell>
                          <TableCell>{trailer.company}</TableCell>
                          <TableCell>{trailer.driverName}</TableCell>
                          <TableCell>
                            {trailer.dockId ? (
                              <Badge variant="outline">{docks.find((d: any) => d.id === trailer.dockId)?.name || `Dock ${trailer.dockId}`}</Badge>
                            ) : (
                              <Badge variant="secondary">Unassigned</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <StatusBadge status={trailer.status} />
                          </TableCell>
                          <TableCell>{formatDate(trailer.arrivalTime)}</TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              {!trailer.dockId && (
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => {
                                    setSelectedTrailer(trailer.id);
                                    setOpenAssignDialog(true);
                                  }}
                                >
                                  Preliminary Assign
                                </Button>
                              )}
                              
                              {trailer.status === 'pending_safety_check' && (
                                <Button 
                                  variant="secondary" 
                                  size="sm"
                                  onClick={() => {
                                    setSelectedTrailer(trailer.id);
                                    prepareChecklistForm(trailer.id, trailer.dockId || 0);
                                  }}
                                >
                                  <CheckSquare className="h-4 w-4 mr-1" />
                                  Complete Safety Check
                                </Button>
                              )}
                              
                              {trailer.dockId && trailer.safetyCheckComplete && (
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => {
                                    setSelectedTrailer(trailer.id);
                                    setOpenReleaseDialog(true);
                                  }}
                                >
                                  <XCircleIcon className="h-4 w-4 mr-1" />
                                  Release
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Register New Tab */}
        <TabsContent value="register">
          <Card>
            <CardHeader>
              <CardTitle>Register New Trailer</CardTitle>
              <CardDescription>
                Enter the details for a new trailer arriving at the facility.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...trailerForm}>
                <form onSubmit={trailerForm.handleSubmit(onSubmitTrailer)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={trailerForm.control}
                      name="trailerNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Trailer Number</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. T12345" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={trailerForm.control}
                      name="driverName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Driver Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Full name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={trailerForm.control}
                      name="company"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company</FormLabel>
                          <FormControl>
                            <Input placeholder="Company name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={trailerForm.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Trailer Status</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select status" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="checked_in">Checked In</SelectItem>
                              <SelectItem value="ready_for_dock">Ready for Dock</SelectItem>
                              <SelectItem value="loading">Loading</SelectItem>
                              <SelectItem value="unloading">Unloading</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={trailerForm.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes</FormLabel>
                        <FormControl>
                          <Input placeholder="Additional information" {...field} />
                        </FormControl>
                        <FormDescription>
                          Add any special instructions or details about this trailer.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={createTrailerMutation.isPending}
                  >
                    {createTrailerMutation.isPending ? 'Registering...' : 'Register Trailer'}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Completed Tab */}
        <TabsContent value="completed">
          <Card>
            <CardHeader>
              <CardTitle>Completed Trailer Visits</CardTitle>
              <CardDescription>
                View history of trailer arrivals and departures.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Trailer #</TableHead>
                      <TableHead>Company</TableHead>
                      <TableHead>Driver</TableHead>
                      <TableHead>Dock</TableHead>
                      <TableHead>Arrival</TableHead>
                      <TableHead>Departure</TableHead>
                      <TableHead>Duration</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {/* Placeholder for completed trailers */}
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8">
                        <CircleDashed className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-muted-foreground">No completed trailer visits to display</p>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Preliminary Dock Assignment Dialog */}
      <Dialog open={openAssignDialog} onOpenChange={setOpenAssignDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Preliminary Dock Assignment</DialogTitle>
            <DialogDescription>
              <p>Step 1: Office personnel select a dock for preliminary assignment.</p>
              <p className="mt-2 text-amber-500">Note: Dock personnel must complete safety checks before the trailer can be fully docked.</p>
            </DialogDescription>
          </DialogHeader>
          
          <Form {...assignForm}>
            <form onSubmit={assignForm.handleSubmit(onAssignDock)}>
              <div className="space-y-4 py-4">
                <FormField
                  control={assignForm.control}
                  name="dockId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Dock</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(parseInt(value))} 
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a dock" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {docks.map((dock: any) => (
                            <SelectItem key={dock.id} value={dock.id.toString()}>
                              {dock.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpenAssignDialog(false)}>
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={assignDockMutation.isPending}
                  variant="secondary"
                >
                  {assignDockMutation.isPending 
                    ? <span className="flex items-center gap-2">
                        <CircleDashed className="h-4 w-4 animate-spin" /> 
                        Processing...
                      </span> 
                    : <span className="flex items-center gap-2">
                        <Truck className="h-4 w-4" />
                        Start Dock Assignment
                      </span>
                  }
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Safety Checklist Dialog */}
      <Dialog open={openChecklistDialog} onOpenChange={setOpenChecklistDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              <div className="flex items-center space-x-2">
                <CheckSquare className="h-5 w-5 text-primary" />
                <span>Step 2: Safety Verification</span>
              </div>
            </DialogTitle>
            <DialogDescription>
              <p>Dock personnel must complete this safety verification to finalize the dock assignment.</p>
              <div className="mt-2 p-2 bg-amber-50 border border-amber-200 rounded-md text-amber-800 text-sm">
                <strong>Important:</strong> Critical items marked with red must pass before the trailer can be docked. This step completes the two-step verification process required for safe dock operations.
              </div>
            </DialogDescription>
          </DialogHeader>
          
          <Form {...checklistForm}>
            <form onSubmit={checklistForm.handleSubmit(onSubmitChecklist)}>
              <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
                {checklistItems.map((item, index) => (
                  <div 
                    key={item.id} 
                    className={`flex items-start space-x-3 p-3 border rounded-md ${item.isCritical ? 'border-destructive/50' : ''}`}
                  >
                    <FormField
                      control={checklistForm.control}
                      name={`checklistResults.${index}.passed`}
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 w-full">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              aria-label={`Safety check: ${item.text}`}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none flex-1">
                            <FormLabel className="text-sm font-medium flex items-center justify-between">
                              <span className={item.isCritical ? 'font-bold' : ''}>{item.text}</span>
                              {item.isCritical && (
                                <Badge variant="destructive" className="ml-2 text-xs">CRITICAL</Badge>
                              )}
                            </FormLabel>
                            <FormDescription className="text-xs flex justify-between">
                              <span>{item.category}</span>
                              {item.description && (
                                <span className="text-muted-foreground">{item.description}</span>
                              )}
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>
                ))}
                
                <FormField
                  control={checklistForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Input placeholder="Any notes about this safety check" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpenChecklistDialog(false)}>
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={assignDockMutation.isPending}
                  className="bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800"
                >
                  {assignDockMutation.isPending 
                    ? <span className="flex items-center gap-2">
                        <CircleDashed className="h-4 w-4 animate-spin" /> 
                        Verifying Safety Checks...
                      </span> 
                    : <span className="flex items-center gap-2">
                        <CheckSquare className="h-4 w-4" />
                        Complete Safety Checks & Assign Dock
                      </span>
                  }
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Release Trailer Dialog */}
      <Dialog open={openReleaseDialog} onOpenChange={setOpenReleaseDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Release Trailer</DialogTitle>
            <DialogDescription>
              Confirm that this trailer is ready to leave the facility.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            {selectedTrailer && (
              <div className="space-y-4">
                <div className="border rounded-md p-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Trailer:</span>
                    <span>{getTrailerById(selectedTrailer)?.trailerNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Company:</span>
                    <span>{getTrailerById(selectedTrailer)?.company}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Driver:</span>
                    <span>{getTrailerById(selectedTrailer)?.driverName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm font-medium">Dock:</span>
                    <span>
                      {docks.find((d: any) => 
                        d.id === getTrailerById(selectedTrailer)?.dockId
                      )?.name || `Dock ${getTrailerById(selectedTrailer)?.dockId}`}
                    </span>
                  </div>
                </div>
                
                <p className="text-sm text-muted-foreground">
                  By releasing this trailer, you confirm that all operations are complete, 
                  the trailer is properly secured, and it is safe to depart from the facility.
                </p>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpenReleaseDialog(false)}>
              Cancel
            </Button>
            <Button 
              variant="default" 
              onClick={onReleaseTrailer}
              disabled={releaseTrailerMutation.isPending}
            >
              {releaseTrailerMutation.isPending ? 'Releasing...' : 'Confirm Release'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default TrailerManagement;
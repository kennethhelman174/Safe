import React from 'react';
import MainLayout from '@/components/layout/MainLayout';
import WarehouseSystemIntegration from '@/components/integration/WarehouseSystemIntegration';

const SystemIntegration: React.FC = () => {
  return (
    <MainLayout title="System Integration">
      <WarehouseSystemIntegration />
    </MainLayout>
  );
};

export default SystemIntegration;
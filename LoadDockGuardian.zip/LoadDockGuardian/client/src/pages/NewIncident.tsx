import React, { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useMutation, useQuery } from '@tanstack/react-query';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { apiRequest, queryClient } from '@/lib/queryClient';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Save, XCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Form schema
const incidentSchema = z.object({
  title: z.string().min(5, {
    message: "Title must be at least 5 characters long.",
  }),
  description: z.string().min(10, {
    message: "Description must be at least 10 characters long.",
  }),
  dockId: z.string().min(1, {
    message: "Please select a dock location.",
  }),
  severity: z.enum(['low', 'medium', 'high', 'critical'], {
    required_error: "Please select severity level.",
  }),
  status: z.enum(['open', 'in_progress', 'resolved'], {
    required_error: "Please select a status.",
  }).default('open'),
  resolutionNotes: z.string().optional(),
});

type IncidentFormValues = z.infer<typeof incidentSchema>;

const NewIncident: React.FC = () => {
  const [location] = useLocation();
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Extract dock ID from URL parameters if it exists
  const params = new URLSearchParams(location.split('?')[1]);
  const urlDockId = params.get('dock');

  // Fetch docks for dropdown
  const { data: docks = [], isLoading: isLoadingDocks } = useQuery({
    queryKey: ['/api/docks'],
  });

  // Form setup
  const form = useForm<IncidentFormValues>({
    resolver: zodResolver(incidentSchema),
    defaultValues: {
      title: '',
      description: '',
      dockId: urlDockId || '',
      severity: 'medium',
      status: 'open',
      resolutionNotes: '',
    },
  });

  // Update dock ID if URL parameter changes
  useEffect(() => {
    if (urlDockId) {
      form.setValue('dockId', urlDockId);
    }
  }, [urlDockId, form]);

  // Submit mutation
  const submitMutation = useMutation({
    mutationFn: async (values: IncidentFormValues) => {
      const formattedValues = {
        ...values,
        reportedBy: 1, // Default user ID for demo
        dockId: parseInt(values.dockId),
      };
      
      await apiRequest('POST', '/api/incidents', formattedValues);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/incidents'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activity-log'] });
      
      toast({
        title: 'Incident Reported',
        description: 'Safety incident has been recorded successfully',
      });
      
      navigate('/incidents');
    },
    onError: (error) => {
      console.error('Error reporting incident:', error);
      toast({
        title: 'Reporting Failed',
        description: 'There was an error reporting the incident. Please try again.',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (values: IncidentFormValues) => {
    submitMutation.mutate(values);
  };

  const getSeverityDescription = (severity: string) => {
    switch (severity) {
      case 'low':
        return "Minor issue with no risk of injury or equipment damage.";
      case 'medium':
        return "Moderate issue with potential for minor injuries or equipment damage.";
      case 'high':
        return "Serious issue with risk of significant injuries or equipment damage.";
      case 'critical':
        return "Severe issue with imminent danger and risk of serious injuries or fatalities.";
      default:
        return "";
    }
  };

  return (
    <MainLayout 
      title="Report Safety Incident" 
      description="Document safety incidents or hazards in the loading dock area"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-heading text-xl font-bold flex items-center">
          <AlertTriangle className="mr-2 h-5 w-5 text-safety-red" />
          Incident Reporting Form
        </h3>
      </div>

      <Card className="mb-6">
        <CardHeader className="bg-safety-red/10 border-b">
          <CardTitle>Safety First</CardTitle>
          <CardDescription>
            If this is an emergency requiring immediate assistance, 
            please contact your supervisor or call emergency services before completing this form.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Incident Title */}
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Incident Title <span className="text-safety-red">*</span></FormLabel>
                    <FormControl>
                      <Input placeholder="Brief description of the incident" {...field} />
                    </FormControl>
                    <FormDescription>
                      Provide a short, descriptive title for the incident
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Dock Location */}
              <FormField
                control={form.control}
                name="dockId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location <span className="text-safety-red">*</span></FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select incident location" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {isLoadingDocks ? (
                          <SelectItem value="loading" disabled>Loading...</SelectItem>
                        ) : (
                          docks.map((dock: any) => (
                            <SelectItem 
                              key={dock.id} 
                              value={dock.id.toString()}
                            >
                              {dock.name}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Select the dock or area where the incident occurred
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Severity */}
              <FormField
                control={form.control}
                name="severity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Severity Level <span className="text-safety-red">*</span></FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select severity level" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      {getSeverityDescription(form.watch('severity'))}
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Detailed Description */}
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Detailed Description <span className="text-safety-red">*</span></FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Provide detailed information about what happened, who was involved, and any immediate actions taken."
                        className="min-h-[120px]"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Include specific details about the incident, factors that contributed to it, and any immediate actions taken
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Resolution Notes (optional) */}
              <FormField
                control={form.control}
                name="resolutionNotes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Resolution Notes</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Add any recommendations or notes for resolution (optional)"
                        className="min-h-[80px]"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Suggest steps to resolve the issue or prevent similar incidents
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Form Actions */}
              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate('/incidents')}
                >
                  <XCircle className="mr-2 h-4 w-4" />
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  className="bg-safety-red hover:bg-red-700 text-white"
                  disabled={submitMutation.isPending}
                >
                  <Save className="mr-2 h-4 w-4" />
                  {submitMutation.isPending ? 'Submitting...' : 'Submit Report'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
      
      <div className="safety-stripes p-5 rounded-lg text-center text-black font-bold">
        <p>Remember: Reporting incidents helps prevent future accidents</p>
      </div>
    </MainLayout>
  );
};

export default NewIncident;

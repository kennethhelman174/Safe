import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Clock, Truck, CheckSquare, AlertCircle, CircleDashed } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';

// Schema for the trailer release form
const trailerReleaseSchema = z.object({
  vehicleId: z.number(),
  dockId: z.number(),
  releaseChecks: z.array(
    z.object({
      itemId: z.number(),
      passed: z.boolean(),
      notes: z.string().optional()
    })
  ),
  notes: z.string().optional()
});

// Status badge component with color coding
const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const getVariant = () => {
    switch(status) {
      case 'checked_in': return 'default';
      case 'assigned': return 'secondary';
      case 'pending_safety_check': return 'warning';
      case 'docked': return 'success';
      case 'loading': return 'destructive';
      case 'ready_to_depart': return 'outline';
      case 'departed': return 'default';
      default: return 'secondary';
    }
  };

  // Format the status text
  const formattedStatus = status
    .split('_')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');

  return <Badge variant={getVariant()}>{formattedStatus}</Badge>;
};

// Format date function
const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleString();
};

// Define safety checklist schema
const safetyChecklistSchema = z.object({
  dockId: z.number(),
  vehicleId: z.number(),
  results: z.array(
    z.object({
      itemId: z.number(),
      passed: z.boolean(),
      notes: z.string().optional()
    })
  ),
  notes: z.string().optional()
});

type ChecklistFormValues = z.infer<typeof safetyChecklistSchema>;

const DockEmployeeDashboard: React.FC = () => {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [selectedTrailer, setSelectedTrailer] = useState<number | null>(null);
  const [selectedDock, setSelectedDock] = useState<number | null>(null);
  const [openChecklistDialog, setOpenChecklistDialog] = useState(false);
  const [openReleaseDialog, setOpenReleaseDialog] = useState(false);
  
  // Form for trailer release checklist
  type ReleaseFormValues = z.infer<typeof trailerReleaseSchema>;
  
  const releaseForm = useForm<ReleaseFormValues>({
    defaultValues: {
      vehicleId: 0,
      dockId: 0,
      releaseChecks: [],
      notes: ''
    }
  });

  // Form for safety checklist
  const checklistForm = useForm<ChecklistFormValues>({
    defaultValues: {
      dockId: 0,
      vehicleId: 0,
      results: [],
      notes: ''
    }
  });

  // Fetch all docks
  const { data: docks = [], isLoading: isLoadingDocks } = useQuery({
    queryKey: ['/api/docks'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/docks', null);
      return response.json();
    },
  });

  // Fetch active trailers
  const { data: trailers = [], isLoading: isLoadingTrailers } = useQuery({
    queryKey: ['/api/vehicles/active'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/vehicles/active', null);
      return response.json();
    },
  });

  // Filter trailers that need safety checks - use any status that indicates pending verification
  const pendingSafetyChecks = trailers.filter((trailer: any) => 
    trailer.status === 'pending_safety_check' || 
    trailer.status === 'pending_verification' ||
    (trailer.dockId && trailer.status === 'assigned' && !trailer.safetyCheckComplete)
  );

  // Find assigned dock for a trailer
  const getAssignedDock = (dockId: number) => {
    return docks.find((dock: any) => dock.id === dockId) || { name: 'Unknown' };
  };

  // Fetch checklist items
  const { data: checklistItems = [], isLoading: isLoadingChecklist } = useQuery<any[]>({
    queryKey: ['/api/checklist-items'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/checklist-items', null);
      return response.json();
    },
  });

  // Mutation for marking trailer exit
  const markTrailerExitMutation = useMutation({
    mutationFn: async (values: any) => {
      return await apiRequest('PUT', `/api/vehicles/${values.vehicleId}/exit`, { 
        releaseChecks: values.releaseChecks,
        notes: values.notes
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/docks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles/active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activity-log'] });
      
      toast({
        title: "Trailer Exit Complete",
        description: "The trailer has been released from the dock successfully.",
      });
      
      setOpenReleaseDialog(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: `Failed to release trailer: ${String(error)}`,
        variant: "destructive",
      });
    },
  });
  
  // Mutation for completing safety checks
  const completeChecklistMutation = useMutation({
    mutationFn: async (values: ChecklistFormValues) => {
      return await apiRequest('PUT', `/api/vehicles/${values.vehicleId}/assign-dock`, { 
        dockId: values.dockId,
        checklistResults: values.results 
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/docks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles/active'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activity-log'] });
      
      toast({
        title: "Safety Verification Complete",
        description: "The dock assignment has been finalized with safety checks.",
      });
      
      setOpenChecklistDialog(false);
    },
    onError: (error: any) => {
      // Check if the error is related to safety requirements
      const errorMessage = String(error);
      const isSafetyError = errorMessage.toLowerCase().includes('safety') || 
                          errorMessage.toLowerCase().includes('critical') || 
                          errorMessage.toLowerCase().includes('checklist');
      
      toast({
        title: isSafetyError ? "Safety Check Failed" : "Error",
        description: isSafetyError 
          ? "Critical safety items must pass before dock assignment can be completed." 
          : `Failed to complete safety checks: ${errorMessage}`,
        variant: "destructive",
      });
    },
  });

  // Show the safety checklist dialog
  const handleStartSafetyCheck = (trailerId: number, dockId: number) => {
    setSelectedTrailer(trailerId);
    setSelectedDock(dockId);
    
    // Initialize checklist form with vehicle and dock IDs, and empty results
    const results = checklistItems.map((item: any) => ({ 
      itemId: item.id, 
      passed: false,
      notes: '' 
    }));
    
    checklistForm.reset({
      vehicleId: trailerId,
      dockId: dockId,
      results: results,
      notes: '',
    });
    
    setOpenChecklistDialog(true);
  };
  
  // Show the trailer release dialog
  const handleStartTrailerRelease = (trailerId: number) => {
    const trailer = trailers.find((t: any) => t.id === trailerId);
    if (!trailer || !trailer.dockId) {
      toast({
        title: "Error",
        description: "Cannot release trailer: No dock assignment found.",
        variant: "destructive"
      });
      return;
    }
    
    setSelectedTrailer(trailerId);
    setSelectedDock(trailer.dockId);
    
    // Initialize release form with trailer and dock IDs, and empty check results
    const releaseChecks = [
      { itemId: 1, passed: false, notes: '' },
      { itemId: 2, passed: false, notes: '' },
      { itemId: 3, passed: false, notes: '' },
      { itemId: 4, passed: false, notes: '' },
      { itemId: 5, passed: false, notes: '' },
      { itemId: 6, passed: false, notes: '' },
      { itemId: 7, passed: false, notes: '' },
      { itemId: 8, passed: false, notes: '' }
    ];
    
    releaseForm.reset({
      vehicleId: trailerId,
      dockId: trailer.dockId,
      releaseChecks: releaseChecks,
      notes: '',
    });
    
    setOpenReleaseDialog(true);
  };
  
  // Handle trailer release submission
  const onSubmitTrailerRelease = (values: any) => {
    // Check if any critical items failed
    const criticalItemsFailed = values.releaseChecks.some((check: any, index: number) => {
      // The first 4 items and the last item (indices 0-3 and 7) are critical
      const isCritical = [0, 1, 2, 3, 7].includes(index);
      return isCritical && !check.passed;
    });
    
    if (criticalItemsFailed) {
      toast({
        title: "Release Check Failed",
        description: "Critical safety items have failed. Cannot release trailer until resolved.",
        variant: "destructive"
      });
      return;
    }
    
    // Submit the release
    markTrailerExitMutation.mutate(values);
  };
  
  // Handle checklist submission
  const onSubmitChecklist = (values: ChecklistFormValues) => {
    // First check if any critical items failed
    const checklist = values.results || [];
    
    // Check critical items against the original checklist items
    const criticalItemsFailed = checklist.some(result => {
      const originalItem = checklistItems.find(item => item.id === result.itemId);
      return originalItem?.isCritical && !result.passed;
    });
    
    if (criticalItemsFailed) {
      toast({
        title: "Safety Check Failed",
        description: "Critical safety items have failed. Cannot assign dock until resolved.",
        variant: "destructive"
      });
      return;
    }
    
    // Submit the checklist
    completeChecklistMutation.mutate(values);
  };

  // Define trailers that need trailer release checks
  const trailersNeedingExit = trailers.filter((t: any) => 
    t.status === 'in_use' && 
    t.dockId && 
    t.safetyCheckComplete === true
  );

  return (
    <MainLayout title="Dock Employee Dashboard">
      <div className="space-y-6">
        <Card className="border-l-4 border-l-amber-500">
          <CardHeader>
            <CardTitle className="flex items-center">
              <CheckSquare className="h-6 w-6 mr-2 text-amber-500" />
              <span>Pending Safety Verifications</span>
            </CardTitle>
            <CardDescription>
              Trailers that have been preliminarily assigned and are waiting for safety verification by dock personnel.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingTrailers ? (
              <div className="flex items-center justify-center h-40">
                <Clock className="h-6 w-6 animate-spin text-muted-foreground mr-2" />
                <p>Loading pending verifications...</p>
              </div>
            ) : pendingSafetyChecks.length === 0 ? (
              <div className="bg-muted p-8 rounded-lg text-center">
                <CheckSquare className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">No Pending Safety Checks</h3>
                <p className="text-muted-foreground">
                  All trailers have completed their safety verifications.
                </p>
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Trailer #</TableHead>
                      <TableHead>Company</TableHead>
                      <TableHead>Driver</TableHead>
                      <TableHead>Assigned Dock</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Arrival Time</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendingSafetyChecks.map((trailer: any) => (
                      <TableRow key={trailer.id} className="bg-yellow-50">
                        <TableCell className="font-medium">{trailer.trailerNumber}</TableCell>
                        <TableCell>{trailer.company}</TableCell>
                        <TableCell>{trailer.driverName}</TableCell>
                        <TableCell>
                          {trailer.dockId ? (
                            <Badge variant="outline">{getAssignedDock(trailer.dockId).name}</Badge>
                          ) : (
                            <Badge variant="secondary">Not Assigned</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={trailer.status} />
                        </TableCell>
                        <TableCell>{formatDate(trailer.arrivalTime)}</TableCell>
                        <TableCell>
                          <Button 
                            variant="default"
                            size="sm"
                            className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700"
                            onClick={() => handleStartSafetyCheck(trailer.id, trailer.dockId)}
                          >
                            <CheckSquare className="h-4 w-4 mr-1" />
                            Start Safety Check
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Trailer Exits Section */}
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Truck className="h-6 w-6 mr-2 text-blue-500" />
              <span>Ready for Trailer Release</span>
            </CardTitle>
            <CardDescription>
              Trailers that are ready for release checks and exit from docks.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingTrailers ? (
              <div className="flex items-center justify-center h-40">
                <Clock className="h-6 w-6 animate-spin text-muted-foreground mr-2" />
                <p>Loading trailers ready for release...</p>
              </div>
            ) : trailersNeedingExit.length === 0 ? (
              <div className="bg-muted p-8 rounded-lg text-center">
                <Truck className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">No Trailers Ready for Release</h3>
                <p className="text-muted-foreground">
                  All trailers are either still loading/unloading or have already been released.
                </p>
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Trailer #</TableHead>
                      <TableHead>Company</TableHead>
                      <TableHead>Driver</TableHead>
                      <TableHead>Dock</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Time at Dock</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {trailersNeedingExit.map((trailer: any) => (
                      <TableRow key={trailer.id}>
                        <TableCell className="font-medium">{trailer.trailerNumber}</TableCell>
                        <TableCell>{trailer.company}</TableCell>
                        <TableCell>{trailer.driverName}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{getAssignedDock(trailer.dockId).name}</Badge>
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={trailer.status} />
                        </TableCell>
                        <TableCell>{formatDate(trailer.assignedTime || trailer.arrivalTime)}</TableCell>
                        <TableCell>
                          <Button 
                            variant="default"
                            size="sm"
                            className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
                            onClick={() => handleStartTrailerRelease(trailer.id)}
                          >
                            <Truck className="h-4 w-4 mr-1" />
                            Mark Exit
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* All Active Docks Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Truck className="h-6 w-6 mr-2" />
              All Active Docks
            </CardTitle>
            <CardDescription>
              Current status of all docks and assigned trailers.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingDocks ? (
              <div className="flex items-center justify-center h-40">
                <Clock className="h-6 w-6 animate-spin text-muted-foreground mr-2" />
                <p>Loading dock status...</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {docks.map((dock: any) => {
                  // Find trailer assigned to this dock
                  const assignedTrailer = trailers.find((t: any) => t.dockId === dock.id);
                  
                  // Determine card style based on dock status
                  let cardStyle = "border rounded-lg p-4 ";
                  let statusIcon = null;
                  
                  switch(dock.status) {
                    case 'available':
                      cardStyle += "bg-green-50 border-green-200";
                      break;
                    case 'pending_verification':
                      cardStyle += "bg-amber-50 border-amber-200";
                      statusIcon = <AlertCircle className="h-5 w-5 text-amber-500" />;
                      break;
                    case 'in_use':
                      cardStyle += "bg-blue-50 border-blue-200";
                      break;
                    case 'maintenance':
                    case 'out_of_service':
                      cardStyle += "bg-red-50 border-red-200";
                      statusIcon = <AlertCircle className="h-5 w-5 text-red-500" />;
                      break;
                    default:
                      cardStyle += "bg-gray-50 border-gray-200";
                  }
                  
                  return (
                    <div key={dock.id} className={cardStyle}>
                      <div className="flex justify-between items-center mb-3">
                        <h3 className="font-medium text-lg">{dock.name}</h3>
                        <div className="flex items-center">
                          {statusIcon}
                          <StatusBadge status={dock.status} />
                        </div>
                      </div>
                      
                      {assignedTrailer ? (
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-500">Trailer:</span>
                            <span className="font-medium">{assignedTrailer.trailerNumber}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-500">Company:</span>
                            <span>{assignedTrailer.company}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-500">Driver:</span>
                            <span>{assignedTrailer.driverName}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-500">Status:</span>
                            <StatusBadge status={assignedTrailer.status} />
                          </div>
                          
                          {assignedTrailer.status === 'pending_safety_check' || 
                           assignedTrailer.status === 'pending_verification' || 
                           (assignedTrailer.dockId && assignedTrailer.status === 'assigned' && !assignedTrailer.safetyCheckComplete) ? (
                            <div className="mt-1 p-1 bg-amber-100 border border-amber-300 rounded text-center text-amber-800 text-xs">
                              Safety verification required
                            </div>
                           ) : null}
                          
                          {assignedTrailer.status === 'pending_safety_check' && (
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="w-full mt-2 border-amber-500 text-amber-700 hover:bg-amber-50"
                              onClick={() => handleStartSafetyCheck(assignedTrailer.id, dock.id)}
                            >
                              <CheckSquare className="h-4 w-4 mr-1" />
                              Complete Safety Check
                            </Button>
                          )}
                        </div>
                      ) : (
                        <div className="h-24 flex items-center justify-center">
                          <p className="text-muted-foreground text-sm">No trailer assigned</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Safety Checklist Dialog - Appears as popup when dock selected */}
      <Dialog open={openChecklistDialog} onOpenChange={setOpenChecklistDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              <div className="flex items-center space-x-2">
                <CheckSquare className="h-5 w-5 text-primary" />
                <span>Step 2: Safety Verification</span>
              </div>
            </DialogTitle>
            <DialogDescription>
              <p>Dock personnel must complete this safety verification to finalize the dock assignment.</p>
              <div className="mt-2 p-2 bg-amber-50 border border-amber-200 rounded-md text-amber-800 text-sm">
                <strong>Important:</strong> Critical safety items marked with red must pass before the trailer can be docked. This completes the two-step verification process.
              </div>
            </DialogDescription>
          </DialogHeader>
          
          <Form {...checklistForm}>
            <form onSubmit={checklistForm.handleSubmit(onSubmitChecklist)}>
              <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto text-black">
                {checklistItems.map((item: any, index: number) => (
                  <div 
                    key={item.id} 
                    className={`border rounded-md p-3 ${item.isCritical ? 'border-red-300 bg-red-50' : 'border-gray-200'}`}
                  >
                    <FormField
                      control={checklistForm.control}
                      name={`results.${index}.passed`}
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel className={`text-sm font-medium ${item.isCritical ? 'text-red-700 flex items-center' : 'text-gray-800'}`}>
                              {item.isCritical && (
                                <span className="bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded-full mr-2">
                                  Critical
                                </span>
                              )}
                              {item.text}
                            </FormLabel>
                            <FormDescription className="text-xs text-gray-700">
                              {item.description || 'Verify this safety item before proceeding.'}
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={checklistForm.control}
                      name={`results.${index}.notes`}
                      render={({ field }) => (
                        <FormItem className="mt-2">
                          <FormControl>
                            <Textarea
                              placeholder="Add notes if needed..."
                              className="resize-none h-20"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={checklistForm.control}
                      name={`results.${index}.itemId`}
                      defaultValue={item.id}
                      render={({ field }) => (
                        <input type="hidden" {...field} value={item.id} />
                      )}
                    />
                  </div>
                ))}
                
                <FormField
                  control={checklistForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Notes</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Add any additional safety notes or observations..."
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpenChecklistDialog(false)}>
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={completeChecklistMutation.isPending}
                  className="bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800"
                >
                  {completeChecklistMutation.isPending 
                    ? <span className="flex items-center gap-2">
                        <CircleDashed className="h-4 w-4 animate-spin" /> 
                        Verifying Safety Checks...
                      </span> 
                    : <span className="flex items-center gap-2">
                        <CheckSquare className="h-4 w-4" />
                        Complete Safety Checks & Finalize Dock
                      </span>
                  }
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Trailer Release Dialog */}
      <Dialog open={openReleaseDialog} onOpenChange={setOpenReleaseDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Truck className="h-5 w-5 mr-2 text-blue-500" />
              Trailer Release Checks
            </DialogTitle>
            <DialogDescription>
              Complete all required checks before releasing the trailer from the dock.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...releaseForm}>
            <form onSubmit={releaseForm.handleSubmit(onSubmitTrailerRelease)}>
              <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
                {Array.isArray(releaseForm.getValues().releaseChecks) && releaseForm.getValues().releaseChecks.map((check: any, index: number) => {
                  // Check if this item is critical
                  const isCritical = [0, 1, 2, 3, 7].includes(index);
                  
                  return (
                    <div 
                      key={index} 
                      className={`border rounded-md p-3 ${isCritical ? 'border-red-300 bg-red-50' : 'border-gray-200'}`}
                    >
                      <FormField
                        control={releaseForm.control}
                        name={`releaseChecks.${index}.passed` as any}
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel className="text-sm font-medium">
                                {isCritical && (
                                  <span className="text-red-600 mr-1 font-bold">
                                    *
                                  </span>
                                )}
                                {/* Get the corresponding text for this check item */}
                                {["All equipment and tools removed", 
                                  "Loading/unloading operations completed", 
                                  "Dock plate/leveler stored", 
                                  "Trailer restraint disengaged",
                                  "Documentation completed",
                                  "Trailer door closed and secured",
                                  "Seal applied (if required)",
                                  "Dock area clear of personnel"][index]}
                              </FormLabel>
                              <FormDescription className="text-xs">
                                {isCritical ? 
                                  'This item is critical for safe trailer release.' : 
                                  'Complete this item before finalizing release.'}
                              </FormDescription>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>
                  );
                })}
                
                <FormField
                  control={releaseForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes (Optional)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Add any notes about the trailer release..."
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setOpenReleaseDialog(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="bg-gradient-to-r from-blue-500 to-blue-600"
                >
                  Complete Release &amp; Mark Exit
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default DockEmployeeDashboard;
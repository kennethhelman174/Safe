import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiRequest } from '@/lib/queryClient';
import { Dock } from '@shared/schema';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, CheckCircle, Truck, Clock, X } from 'lucide-react';

// Group dock numbers based on their series
const dockGroups = {
  '100 Series': (dock: Dock) => {
    const dockNumber = parseInt(dock.name.replace(/\D/g, ''));
    return dockNumber >= 100 && dockNumber < 200;
  },
  '200 Series': (dock: Dock) => {
    const dockNumber = parseInt(dock.name.replace(/\D/g, ''));
    return dockNumber >= 200 && dockNumber < 300;
  },
};

const statusIcons = {
  'available': <CheckCircle className="h-6 w-6 text-green-500" />,
  'in_use': <Truck className="h-6 w-6 text-blue-500" />,
  'maintenance': <AlertCircle className="h-6 w-6 text-amber-500" />,
  'out_of_service': <X className="h-6 w-6 text-red-500" />,
  'reserved': <Clock className="h-6 w-6 text-purple-500" />,
};

const statusColors = {
  'available': 'bg-green-100 border-green-300 text-green-800',
  'in_use': 'bg-blue-100 border-blue-300 text-blue-800',
  'maintenance': 'bg-amber-100 border-amber-300 text-amber-800',
  'out_of_service': 'bg-red-100 border-red-300 text-red-800',
  'reserved': 'bg-purple-100 border-purple-300 text-purple-800',
};

const DockStatusCard: React.FC<{ dock: Dock }> = ({ dock }) => {
  // Replace underscores with spaces and capitalize each word
  const formattedStatus = (dock.status || "unknown")
    .split('_')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');

  const statusIcon = statusIcons[dock.status as keyof typeof statusIcons] || 
    <AlertCircle className="h-6 w-6 text-gray-500" />;
  
  const statusColor = statusColors[dock.status as keyof typeof statusColors] || 
    'bg-gray-100 border-gray-300 text-gray-800';

  return (
    <Card className={`border-2 ${statusColor}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl">{dock.name}</CardTitle>
          <Badge variant={dock.status === 'available' ? 'outline' : 'secondary'}>
            {formattedStatus}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Last Inspection</p>
            <p className="font-medium">{dock.lastInspectionDate ? new Date(dock.lastInspectionDate).toLocaleTimeString() : 'Not Available'}</p>
          </div>
          <div className="bg-background rounded-full p-2">
            {statusIcon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const KioskDisplay: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  
  // Auto-refresh time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    
    return () => clearInterval(timer);
  }, []);
  
  // Fetch dock data with 30 second refresh
  const { data: docks = [], isLoading } = useQuery<Dock[]>({
    queryKey: ['/api/docks'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/docks', null);
      return response.json();
    },
    refetchInterval: 30000,
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white p-8">
      <header className="mb-8">
        <div className="flex justify-between items-center">
          <h1 className="text-4xl font-bold">Loading Dock Status Board</h1>
          <div className="text-xl">
            <div className="font-medium">{currentTime.toLocaleDateString()}</div>
            <div className="text-right">{currentTime.toLocaleTimeString()}</div>
          </div>
        </div>
      </header>
      
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid grid-cols-3 mb-8">
          <TabsTrigger value="all">All Docks</TabsTrigger>
          <TabsTrigger value="100">100 Series</TabsTrigger>
          <TabsTrigger value="200">200 Series</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {isLoading ? (
              Array(8).fill(0).map((_, i) => (
                <Card key={i}>
                  <CardHeader className="pb-2">
                    <Skeleton className="h-6 w-24" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-16 w-full" />
                  </CardContent>
                </Card>
              ))
            ) : (
              docks.map(dock => (
                <DockStatusCard key={dock.id} dock={dock} />
              ))
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="100">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {isLoading ? (
              Array(4).fill(0).map((_, i) => (
                <Card key={i}>
                  <CardHeader className="pb-2">
                    <Skeleton className="h-6 w-24" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-16 w-full" />
                  </CardContent>
                </Card>
              ))
            ) : (
              docks
                .filter(dock => dockGroups['100 Series'](dock))
                .map(dock => (
                  <DockStatusCard key={dock.id} dock={dock} />
                ))
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="200">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {isLoading ? (
              Array(4).fill(0).map((_, i) => (
                <Card key={i}>
                  <CardHeader className="pb-2">
                    <Skeleton className="h-6 w-24" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-16 w-full" />
                  </CardContent>
                </Card>
              ))
            ) : (
              docks
                .filter(dock => dockGroups['200 Series'](dock))
                .map(dock => (
                  <DockStatusCard key={dock.id} dock={dock} />
                ))
            )}
          </div>
        </TabsContent>
      </Tabs>
      
      <footer className="mt-8 text-center text-gray-400">
        <p>Last updated: {new Date().toLocaleTimeString()}</p>
        <p className="text-sm">Safety data provided by DockSafe Management System</p>
      </footer>
    </div>
  );
};

export default KioskDisplay;
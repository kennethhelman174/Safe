import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Dock table for tracking loading docks
export const docks = pgTable("docks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  status: text("status").notNull().default("available"), // available, in_use, caution, danger
  lastInspectionDate: timestamp("last_inspection_date"),
  notes: text("notes"),
});

// Safety checklist items
export const checklistItems = pgTable("checklist_items", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  description: text("description"),
  isCritical: boolean("is_critical").default(false),
  sortOrder: integer("sort_order").default(0),
});

// Completed checklists
export const completedChecklists = pgTable("completed_checklists", {
  id: serial("id").primaryKey(),
  dockId: integer("dock_id").notNull(),
  userId: integer("user_id").notNull(),
  completedAt: timestamp("completed_at").notNull().defaultNow(),
  results: json("results").notNull(), // array of checklist item responses
  allPassed: boolean("all_passed").notNull(),
});

// Vehicle tracking
export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  trailerNumber: text("trailer_number").notNull(),
  driverName: text("driver_name"),
  company: text("company"),
  entryTime: timestamp("entry_time").notNull().defaultNow(),
  exitTime: timestamp("exit_time"),
  dockId: integer("dock_id"), // can be null if not assigned to dock
  status: text("status").notNull().default("pending"), // pending, loading, unloading, complete
});

// Safety incidents
export const incidents = pgTable("incidents", {
  id: serial("id").primaryKey(),
  dockId: integer("dock_id"),
  title: text("title").notNull(),
  description: text("description").notNull(),
  reportedBy: integer("reported_by").notNull(),
  reportedAt: timestamp("reported_at").notNull().defaultNow(),
  severity: text("severity").notNull(), // low, medium, high, critical
  status: text("status").notNull().default("open"), // open, in_progress, resolved
  resolutionNotes: text("resolution_notes"),
  resolvedAt: timestamp("resolved_at"),
});

// Activity log
export const activityLog = pgTable("activity_log", {
  id: serial("id").primaryKey(),
  dockId: integer("dock_id"),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // safety_check, incident_report, vehicle_entry, vehicle_exit, etc.
  message: text("message").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  relatedEntityId: integer("related_entity_id"), // ID of the related entity (vehicle, incident, etc.)
  relatedEntityType: text("related_entity_type"), // Type of related entity
  severity: text("severity").default("info"), // info, warning, error
});

// User table for login and user identification
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  department: text("department"),
  role: text("role").notNull().default("operator"), // admin, manager, operator, technician
  isActive: boolean("is_active").notNull().default(true),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertDockSchema = createInsertSchema(docks).omit({
  id: true
});

export const insertChecklistItemSchema = createInsertSchema(checklistItems).omit({
  id: true
});

export const insertCompletedChecklistSchema = createInsertSchema(completedChecklists).omit({
  id: true, 
  completedAt: true
});

export const insertVehicleSchema = createInsertSchema(vehicles).omit({
  id: true, 
  entryTime: true,
  exitTime: true
});

export const insertIncidentSchema = createInsertSchema(incidents).omit({
  id: true, 
  reportedAt: true,
  resolvedAt: true
});

export const insertActivityLogSchema = createInsertSchema(activityLog).omit({
  id: true, 
  timestamp: true
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true
});

// Relations
export const docksRelations = relations(docks, ({ many }) => ({
  vehicles: many(vehicles),
  incidents: many(incidents),
  completedChecklists: many(completedChecklists),
  activityLogs: many(activityLog)
}));

export const vehiclesRelations = relations(vehicles, ({ one }) => ({
  dock: one(docks, {
    fields: [vehicles.dockId],
    references: [docks.id],
  }),
}));

export const incidentsRelations = relations(incidents, ({ one }) => ({
  dock: one(docks, {
    fields: [incidents.dockId],
    references: [docks.id],
  }),
  reporter: one(users, {
    fields: [incidents.reportedBy],
    references: [users.id],
  }),
}));

export const completedChecklistsRelations = relations(completedChecklists, ({ one }) => ({
  dock: one(docks, {
    fields: [completedChecklists.dockId],
    references: [docks.id],
  }),
  user: one(users, {
    fields: [completedChecklists.userId],
    references: [users.id],
  }),
}));

export const activityLogRelations = relations(activityLog, ({ one }) => ({
  dock: one(docks, {
    fields: [activityLog.dockId],
    references: [docks.id],
  }),
  user: one(users, {
    fields: [activityLog.userId],
    references: [users.id],
  }),
}));

export const usersRelations = relations(users, ({ many }) => ({
  incidents: many(incidents),
  completedChecklists: many(completedChecklists),
  activityLogs: many(activityLog)
}));

// Types
export type Dock = typeof docks.$inferSelect;
export type InsertDock = z.infer<typeof insertDockSchema>;

export type ChecklistItem = typeof checklistItems.$inferSelect;
export type InsertChecklistItem = z.infer<typeof insertChecklistItemSchema>;

export type CompletedChecklist = typeof completedChecklists.$inferSelect;
export type InsertCompletedChecklist = z.infer<typeof insertCompletedChecklistSchema>;

export type Vehicle = typeof vehicles.$inferSelect;
export type InsertVehicle = z.infer<typeof insertVehicleSchema>;

export type Incident = typeof incidents.$inferSelect;
export type InsertIncident = z.infer<typeof insertIncidentSchema>;

export type ActivityLogEntry = typeof activityLog.$inferSelect;
export type InsertActivityLogEntry = z.infer<typeof insertActivityLogSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

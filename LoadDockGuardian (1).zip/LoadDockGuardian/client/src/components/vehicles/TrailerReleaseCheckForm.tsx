import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Loader2, AlertTriangle, CheckCircle, ShieldAlert } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Types
interface Vehicle {
  id: number;
  trailerNumber: string;
  driverName: string | null;
  company: string | null;
  entryTime: string;
  exitTime: string | null;
  dockId: number | null;
  status: string;
}

interface ChecklistItem {
  id: number;
  text: string;
  isCritical: boolean;
}

interface ChecklistItemResult {
  itemId: number;
  text: string;
  isCritical: boolean;
  passed: boolean;
  notes: string;
}

interface TrailerReleaseCheckFormProps {
  vehicle: Vehicle;
  isOpen: boolean;
  onClose: () => void;
}

const TrailerReleaseCheckForm: React.FC<TrailerReleaseCheckFormProps> = ({
  vehicle,
  isOpen,
  onClose
}) => {
  const { toast } = useToast();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [checklistItems, setChecklistItems] = useState<ChecklistItemResult[]>([]);

  // Fetch checklist items
  const { data: checklistItemsData = [], isLoading: isLoadingChecklist } = useQuery<ChecklistItem[]>({
    queryKey: ['/api/checklist-items'],
  });

  // Process checklist items when data is loaded
  useEffect(() => {
    if (checklistItemsData && checklistItemsData.length > 0) {
      // Find checklist items related to releases or exits
      const releaseItems = checklistItemsData.filter((item) => 
        item.text.toLowerCase().includes('release') || 
        item.text.toLowerCase().includes('exit') ||
        item.text.toLowerCase().includes('departure') ||
        item.isCritical
      );
      
      setChecklistItems(
        releaseItems.map((item) => ({
          itemId: item.id,
          text: item.text,
          isCritical: item.isCritical,
          passed: false,
          notes: ''
        }))
      );
    }
  }, [checklistItemsData]);

  // Mark vehicle exit mutation
  const exitMutation = useMutation({
    mutationFn: async () => {
      // Check if all critical items are passed
      const criticalItems = checklistItems.filter(item => item.isCritical);
      const allCriticalPassed = criticalItems.every(item => item.passed);
      
      if (!allCriticalPassed) {
        throw new Error("All critical safety items must pass before trailer release");
      }
      
      return await apiRequest('PUT', `/api/vehicles/${vehicle.id}/exit`, { 
        userId: 1,
        releaseChecklistResults: checklistItems
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles'] });
      toast({
        title: 'Vehicle Exited',
        description: 'Vehicle has been marked as exited after passing safety checks',
      });
      onClose();
    },
    onError: (error: any) => {
      setErrorMessage(error.message || "Failed to complete trailer release. Please ensure all critical safety items pass.");
      toast({
        title: 'Release Check Failed',
        description: 'Could not complete safety release check',
        variant: 'destructive'
      });
    }
  });

  // Handle checkbox changes
  const handleCheckboxChange = (itemId: number, checked: boolean) => {
    setChecklistItems(prev => 
      prev.map(item => 
        item.itemId === itemId 
          ? { ...item, passed: checked } 
          : item
      )
    );
  };

  // Handle notes changes
  const handleNotesChange = (itemId: number, notes: string) => {
    setChecklistItems(prev => 
      prev.map(item => 
        item.itemId === itemId 
          ? { ...item, notes } 
          : item
      )
    );
  };

  // Handle submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    exitMutation.mutate();
  };

  const hasCriticalFailures = checklistItems
    .filter(item => item.isCritical)
    .some(item => !item.passed);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <ShieldAlert className="h-5 w-5 mr-2 text-yellow-500" />
            Trailer Release Safety Check
          </DialogTitle>
          <DialogDescription>
            Complete the safety check before allowing trailer {vehicle?.trailerNumber} to exit
          </DialogDescription>
        </DialogHeader>

        {isLoadingChecklist ? (
          <div className="flex justify-center items-center p-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2">Loading safety checklist...</span>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            {errorMessage && (
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md p-3 mb-4">
                <div className="flex items-start">
                  <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5 mr-2 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-sm text-red-800 dark:text-red-300">Error</h4>
                    <p className="text-sm mt-1 text-red-700 dark:text-red-400">{errorMessage}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="mb-4 py-2 border-y">
              <h3 className="font-medium text-sm mb-2">Trailer Information</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Trailer Number</Label>
                  <div className="font-medium">{vehicle?.trailerNumber}</div>
                </div>
                <div>
                  <Label>Driver</Label>
                  <div className="font-medium">{vehicle?.driverName || 'Unknown'}</div>
                </div>
                <div>
                  <Label>Company</Label>
                  <div className="font-medium">{vehicle?.company || 'Unknown'}</div>
                </div>
                <div>
                  <Label>Status</Label>
                  <div className="font-medium capitalize">{vehicle?.status || 'Unknown'}</div>
                </div>
              </div>
            </div>

            <div className="space-y-4 mb-4">
              <h3 className="font-medium text-sm">Safety Items</h3>
              <p className="text-sm text-muted-foreground">
                All critical safety items must pass before the trailer can be released.
              </p>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[60px]">Status</TableHead>
                    <TableHead>Safety Item</TableHead>
                    <TableHead className="w-[100px] text-center">Critical</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {checklistItems.map((item) => (
                    <TableRow key={item.itemId}>
                      <TableCell>
                        <Checkbox 
                          checked={item.passed} 
                          onCheckedChange={(checked) => handleCheckboxChange(item.itemId, !!checked)}
                          id={`item-${item.itemId}`}
                        />
                      </TableCell>
                      <TableCell>
                        <Label 
                          htmlFor={`item-${item.itemId}`}
                          className={`font-medium ${item.isCritical ? 'text-red-600 dark:text-red-400' : ''}`}
                        >
                          {item.text}
                        </Label>
                        <div className="mt-1">
                          <Input
                            placeholder="Add notes if needed"
                            value={item.notes}
                            onChange={(e) => handleNotesChange(item.itemId, e.target.value)}
                            className="text-sm h-8"
                          />
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        {item.isCritical && (
                          <span className="inline-flex items-center rounded-full bg-red-100 dark:bg-red-900/30 px-2 py-1 text-xs font-medium text-red-700 dark:text-red-300">
                            Required
                          </span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={hasCriticalFailures || exitMutation.isPending}
                className="flex items-center"
              >
                {exitMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Complete & Release
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default TrailerReleaseCheckForm;
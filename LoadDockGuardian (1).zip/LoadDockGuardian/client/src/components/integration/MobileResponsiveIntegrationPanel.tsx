import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { 
  ArrowLeftRight, 
  Check, 
  Clock, 
  Database, 
  Download, 
  FileWarning, 
  Loader2,
  Link as LinkIcon,
  Link2Off,
  RefreshCw, 
  Settings, 
  Shield, 
  Truck, 
  Upload, 
  Warehouse
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  useSystems, 
  useSystemDetails, 
  useSystemEndpoints, 
  useSystemMappings, 
  useSyncHistory 
} from '@/lib/integrationService';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { Checkbox } from "@/components/ui/checkbox";

// No need for separate import as we're importing directly below

const MobileResponsiveIntegrationPanel = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State variables
  const [selectedSystem, setSelectedSystem] = useState<string | null>(null);
  const [connectionDetails, setConnectionDetails] = useState({
    url: '',
    apiKey: '',
    syncInterval: '15',
    authType: 'api_key'
  });
  const [activeTab, setActiveTab] = useState('systems');
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [isSyncing, setIsSyncing] = useState<Record<string, boolean>>({});
  
  // Queries
  const { data: systems = [], isLoading: isLoadingSystems } = useSystems();
  const { data: systemDetails, isLoading: isLoadingDetails } = useSystemDetails(selectedSystem);
  const { data: endpoints = [], isLoading: isLoadingEndpoints } = useSystemEndpoints(selectedSystem);
  const { data: mappings = [], isLoading: isLoadingMappings } = useSystemMappings(selectedSystem);
  const { data: syncHistory = [], isLoading: isLoadingSyncHistory } = useSyncHistory(selectedSystem);
  
  // Update connection details when system changes
  useEffect(() => {
    if (systemDetails?.connectionDetails) {
      setConnectionDetails({
        url: systemDetails.connectionDetails.url || '',
        apiKey: systemDetails.connectionDetails.apiKey || '',
        syncInterval: systemDetails.connectionDetails.syncInterval?.toString() || '15',
        authType: systemDetails.connectionDetails.authType || 'api_key'
      });
    } else {
      // Default values for new connections
      setConnectionDetails({
        url: '',
        apiKey: '',
        syncInterval: '15',
        authType: 'api_key'
      });
    }
  }, [systemDetails]);
  
  // Mutation for connecting to a system
  const connectMutation = useMutation({
    mutationFn: async ({ systemId, connectionData }: { systemId: string, connectionData: any }) => {
      const response = await apiRequest('POST', `/api/integration/systems/${systemId}/connect`, connectionData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/integration/systems'] });
      if (selectedSystem) {
        queryClient.invalidateQueries({ queryKey: ['/api/integration/systems', selectedSystem] });
      }
      
      toast({
        title: "Connection Successful",
        description: `Successfully connected to ${systemDetails?.name}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Connection Failed",
        description: `Failed to connect: ${error.message || 'Unknown error'}`,
        variant: "destructive"
      });
    }
  });
  
  // Mutation for disconnecting from a system
  const disconnectMutation = useMutation({
    mutationFn: async (systemId: string) => {
      const response = await apiRequest('POST', `/api/integration/systems/${systemId}/disconnect`, null);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/integration/systems'] });
      if (selectedSystem) {
        queryClient.invalidateQueries({ queryKey: ['/api/integration/systems', selectedSystem] });
      }
      
      toast({
        title: "Disconnected",
        description: data.message || "Successfully disconnected from the system",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Disconnection Failed",
        description: `Failed to disconnect: ${error.message || 'Unknown error'}`,
        variant: "destructive"
      });
    }
  });
  
  // Mutation for updating endpoint settings
  const updateEndpointMutation = useMutation({
    mutationFn: async ({ systemId, endpointId, endpointData }: { systemId: string, endpointId: string, endpointData: any }) => {
      const response = await apiRequest('PUT', `/api/integration/systems/${systemId}/endpoints/${endpointId}`, endpointData);
      return response.json();
    },
    onSuccess: () => {
      if (selectedSystem) {
        queryClient.invalidateQueries({ queryKey: ['/api/integration/systems', selectedSystem, 'endpoints'] });
      }
      
      toast({
        title: "Endpoint Updated",
        description: "Endpoint settings have been updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: `Failed to update endpoint: ${error.message || 'Unknown error'}`,
        variant: "destructive"
      });
    }
  });
  
  // Mutation for updating data mappings
  const updateMappingMutation = useMutation({
    mutationFn: async ({ systemId, mappingId, mappingData }: { systemId: string, mappingId: string, mappingData: any }) => {
      const response = await apiRequest('PUT', `/api/integration/systems/${systemId}/mappings/${mappingId}`, mappingData);
      return response.json();
    },
    onSuccess: () => {
      if (selectedSystem) {
        queryClient.invalidateQueries({ queryKey: ['/api/integration/systems', selectedSystem, 'mappings'] });
      }
      
      toast({
        title: "Mapping Updated",
        description: "Data mapping has been updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: `Failed to update mapping: ${error.message || 'Unknown error'}`,
        variant: "destructive"
      });
    }
  });
  
  // Mutation for triggering a manual sync
  const triggerSyncMutation = useMutation({
    mutationFn: async ({ systemId, endpointId }: { systemId: string, endpointId: string }) => {
      const response = await apiRequest('POST', `/api/integration/systems/${systemId}/sync/${endpointId}`, null);
      return response.json();
    },
    onSuccess: (data, variables) => {
      // After a few seconds, refresh the sync history
      setTimeout(() => {
        if (selectedSystem) {
          queryClient.invalidateQueries({ queryKey: ['/api/integration/systems', selectedSystem, 'history'] });
        }
        // Clear the syncing state
        setIsSyncing(prev => ({ ...prev, [variables.endpointId]: false }));
      }, 2000);
      
      toast({
        title: "Sync Started",
        description: `Data synchronization has been initiated for ${
          endpoints.find((e: any) => e.id === variables.endpointId)?.name || 'the endpoint'
        }`,
      });
    },
    onError: (error: any, variables) => {
      // Clear the syncing state
      setIsSyncing(prev => ({ ...prev, [variables.endpointId]: false }));
      
      toast({
        title: "Sync Failed",
        description: `Failed to trigger sync: ${error.message || 'Unknown error'}`,
        variant: "destructive"
      });
    }
  });
  
  // Function to test connection
  const testConnection = async () => {
    if (!selectedSystem) return;
    
    setIsTestingConnection(true);
    
    try {
      const response = await apiRequest('POST', `/api/integration/systems/${selectedSystem}/test-connection`, connectionDetails);
      const result = await response.json();
      
      if (result.success) {
        toast({
          title: "Connection Test Successful",
          description: result.message || "Successfully connected to the WMS system",
        });
      } else {
        toast({
          title: "Connection Test Failed",
          description: result.message || "Failed to connect to the WMS system",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Connection Test Failed",
        description: `An error occurred: ${(error as Error).message || 'Unknown error'}`,
        variant: "destructive"
      });
    } finally {
      setIsTestingConnection(false);
    }
  };
  
  // Handle connection to a system
  const handleConnect = () => {
    if (!selectedSystem) return;
    
    connectMutation.mutate({
      systemId: selectedSystem,
      connectionData: connectionDetails
    });
  };
  
  // Handle disconnection from a system
  const handleDisconnect = () => {
    if (!selectedSystem) return;
    
    disconnectMutation.mutate(selectedSystem);
  };
  
  // Handle toggling an endpoint
  const handleEndpointToggle = (endpointId: string, enabled: boolean) => {
    if (!selectedSystem) return;
    
    updateEndpointMutation.mutate({
      systemId: selectedSystem,
      endpointId,
      endpointData: { enabled }
    });
  };
  
  // Handle updating a data mapping
  const handleUpdateMapping = (mappingId: string) => {
    if (!selectedSystem) return;
    
    updateMappingMutation.mutate({
      systemId: selectedSystem,
      mappingId,
      mappingData: { status: 'mapped' }
    });
  };
  
  // Handle triggering a sync for an endpoint
  const handleTriggerSync = (endpointId: string) => {
    if (!selectedSystem) return;
    
    // Set syncing state for this endpoint
    setIsSyncing(prev => ({ ...prev, [endpointId]: true }));
    
    triggerSyncMutation.mutate({
      systemId: selectedSystem,
      endpointId
    });
  };
  
  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };
  
  // Render loading state
  if (isLoadingSystems) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Skeleton className="h-64" />
          <Skeleton className="h-64 md:col-span-2" />
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold flex items-center">
          <Warehouse className="mr-2 h-6 w-6 text-primary" />
          WMS Integration
        </h2>
        
        {systemDetails?.status === 'connected' && (
          <Button 
            variant="default"
            onClick={() => {
              if (selectedSystem) {
                const endpoint = endpoints.find((e: any) => e.id === 'inbound_shipments');
                if (endpoint && endpoint.enabled) {
                  handleTriggerSync('inbound_shipments');
                } else {
                  toast({
                    title: "Sync Not Available",
                    description: "Please enable the inbound shipments endpoint to sync data",
                    variant: "destructive"
                  });
                }
              } else {
                toast({
                  title: "No System Selected",
                  description: "Please select a system to sync data",
                  variant: "destructive"
                });
              }
            }}
            disabled={!selectedSystem || isSyncing['inbound_shipments']}
            className="flex items-center w-full sm:w-auto"
          >
            {isSyncing['inbound_shipments'] ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Syncing...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Sync Shipments
              </>
            )}
          </Button>
        )}
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-3 mb-4">
          <TabsTrigger value="systems">Systems</TabsTrigger>
          <TabsTrigger value="endpoints" disabled={!selectedSystem}>Endpoints</TabsTrigger>
          <TabsTrigger value="mappings" disabled={!selectedSystem}>Mappings</TabsTrigger>
        </TabsList>
        
        {/* Systems Tab */}
        <TabsContent value="systems" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {systems.map((system: any) => (
              <div 
                key={system.id}
                className={`p-4 rounded-lg border ${
                  system.status === 'connected' 
                    ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' 
                    : 'bg-gray-50 dark:bg-gray-800/50'
                } ${selectedSystem === system.id ? 'ring-2 ring-primary' : ''}`}
                onClick={() => setSelectedSystem(system.id)}
                style={{ cursor: 'pointer' }}
              >
                <div className="flex flex-col h-full">
                  <div className="flex items-center mb-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold">
                      {system.icon.substring(0, 2)}
                    </div>
                    <div className="ml-3">
                      <h4 className="font-medium">{system.name}</h4>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {system.status === 'connected' ? 'Connected' : 'Not connected'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="mt-auto pt-3 border-t">
                    {system.status === 'connected' ? (
                      <div className="flex flex-col gap-2">
                        <div className="text-sm text-gray-500">
                          {system.lastSync ? (
                            <p>Last sync: {formatDate(system.lastSync)}</p>
                          ) : (
                            <p>No recent synchronization</p>
                          )}
                        </div>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="w-full"
                              onClick={(e: React.MouseEvent) => e.stopPropagation()}
                            >
                              <Link2Off className="h-4 w-4 mr-1" />
                              Disconnect
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Disconnecting from {system.name} will stop all data synchronization. You can reconnect at any time.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction 
                                onClick={() => {
                                  handleDisconnect();
                                }}
                              >
                                Disconnect
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                        <Button 
                          size="sm"
                          className="w-full"
                          onClick={(e: React.MouseEvent) => {
                            e.stopPropagation();
                            setActiveTab('endpoints');
                          }}
                        >
                          Configure
                        </Button>
                      </div>
                    ) : (
                      <Button 
                        size="sm"
                        className="w-full"
                        onClick={(e: React.MouseEvent) => {
                          e.stopPropagation();
                          setActiveTab('settings');
                        }}
                        disabled={connectMutation.isPending}
                      >
                        {connectMutation.isPending && system.id === selectedSystem ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                            Connecting...
                          </>
                        ) : (
                          <>
                            <LinkIcon className="h-4 w-4 mr-1" />
                            Connect
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {selectedSystem && !systemDetails?.status && (
            <Card>
              <CardHeader>
                <CardTitle>Connection Settings</CardTitle>
                <CardDescription>
                  Configure connection details for {systems.find((s: any) => s.id === selectedSystem)?.name}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="url">API Endpoint URL</Label>
                  <Input 
                    id="url" 
                    placeholder="https://api.example.com/v2" 
                    value={connectionDetails.url}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                      setConnectionDetails({...connectionDetails, url: e.target.value})
                    }
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="api-key">API Key</Label>
                  <Input 
                    id="api-key" 
                    type="password"
                    placeholder="Enter your API key" 
                    value={connectionDetails.apiKey}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                      setConnectionDetails({...connectionDetails, apiKey: e.target.value})
                    }
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="sync-interval">Sync Interval</Label>
                  <Select 
                    value={connectionDetails.syncInterval}
                    onValueChange={(value) => 
                      setConnectionDetails({...connectionDetails, syncInterval: value})
                    }
                  >
                    <SelectTrigger id="sync-interval">
                      <SelectValue placeholder="Select interval" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 minutes</SelectItem>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center space-x-2 pt-2">
                  <Checkbox id="safety-rules" defaultChecked />
                  <Label htmlFor="safety-rules">Apply safety validation rules to all data transfers</Label>
                </div>
                
                <div className="pt-4 flex space-x-2">
                  <Button 
                    variant="outline"
                    onClick={testConnection}
                    disabled={isTestingConnection}
                    className="flex-1"
                  >
                    {isTestingConnection ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Testing...
                      </>
                    ) : (
                      "Test Connection"
                    )}
                  </Button>
                  
                  <Button 
                    onClick={handleConnect}
                    disabled={!connectionDetails.url || !connectionDetails.apiKey || connectMutation.isPending}
                    className="flex-1"
                  >
                    {connectMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Connecting...
                      </>
                    ) : (
                      "Connect"
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        {/* Endpoints Tab */}
        <TabsContent value="endpoints" className="space-y-4">
          {isLoadingEndpoints ? (
            <div className="space-y-4">
              <Skeleton className="h-16" />
              <Skeleton className="h-16" />
              <Skeleton className="h-16" />
            </div>
          ) : (
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <ArrowLeftRight className="mr-2 h-5 w-5" />
                    Data Endpoints
                  </CardTitle>
                  <CardDescription>
                    Enable or disable data synchronization for specific endpoints
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible className="w-full">
                    {endpoints.map((endpoint: any) => (
                      <AccordionItem key={endpoint.id} value={endpoint.id}>
                        <AccordionTrigger className="py-3 px-2">
                          <div className="flex justify-between items-center w-full mr-2">
                            <div className="flex items-center">
                              {endpoint.direction === 'in' && <Download className="h-4 w-4 mr-2 text-blue-500" />}
                              {endpoint.direction === 'out' && <Upload className="h-4 w-4 mr-2 text-green-500" />}
                              {endpoint.direction === 'both' && <ArrowLeftRight className="h-4 w-4 mr-2 text-purple-500" />}
                              <span>{endpoint.name}</span>
                            </div>
                            <Switch
                              checked={endpoint.enabled}
                              onCheckedChange={(checked) => handleEndpointToggle(endpoint.id, checked)}
                              onClick={(e) => e.stopPropagation()}
                            />
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="px-2 pb-4">
                          <div className="space-y-4">
                            <div className="text-sm text-gray-500 dark:text-gray-400">
                              {endpoint.description}
                            </div>
                            
                            <div className="flex flex-wrap items-center gap-2">
                              <Badge variant="outline" className="flex items-center">
                                {endpoint.direction === 'in' ? 'Import' : endpoint.direction === 'out' ? 'Export' : 'Bidirectional'}
                              </Badge>
                              
                              <Badge variant="outline" className="flex items-center">
                                Frequency: {endpoint.frequency || 'As scheduled'}
                              </Badge>
                              
                              {endpoint.lastSync && (
                                <Badge variant="outline" className="flex items-center">
                                  Last sync: {formatDate(endpoint.lastSync)}
                                </Badge>
                              )}
                            </div>
                            
                            {endpoint.enabled && (
                              <Button 
                                size="sm"
                                variant="outline"
                                onClick={() => handleTriggerSync(endpoint.id)}
                                disabled={isSyncing[endpoint.id]}
                                className="mt-2"
                              >
                                {isSyncing[endpoint.id] ? (
                                  <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    Syncing...
                                  </>
                                ) : (
                                  <>
                                    <RefreshCw className="mr-2 h-4 w-4" />
                                    Sync Now
                                  </>
                                )}
                              </Button>
                            )}
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>
        
        {/* Mappings Tab */}
        <TabsContent value="mappings" className="space-y-4">
          {isLoadingMappings ? (
            <div className="space-y-4">
              <Skeleton className="h-16" />
              <Skeleton className="h-16" />
              <Skeleton className="h-16" />
            </div>
          ) : (
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <LinkIcon className="mr-2 h-5 w-5" />
                    Data Mappings
                  </CardTitle>
                  <CardDescription>
                    Configure how data fields map between DockSafe and {systemDetails?.name}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                      <thead className="bg-muted/50">
                        <tr>
                          <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Source Field</th>
                          <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Target Field</th>
                          <th className="px-3 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                        {mappings.map((mapping: any) => (
                          <tr key={mapping.id}>
                            <td className="px-3 py-3 whitespace-nowrap text-sm">
                              <div className="flex items-center">
                                <Badge variant="outline" className="mr-1 font-mono text-xs">
                                  {mapping.source.split('.')[0]}
                                </Badge>
                                <span>{mapping.source.split('.').slice(1).join('.')}</span>
                              </div>
                            </td>
                            <td className="px-3 py-3 whitespace-nowrap text-sm">
                              <div className="flex items-center">
                                <Badge variant="outline" className="mr-1 font-mono text-xs">
                                  {mapping.target.split('.')[0]}
                                </Badge>
                                <span>{mapping.target.split('.').slice(1).join('.')}</span>
                              </div>
                            </td>
                            <td className="px-3 py-3 whitespace-nowrap text-sm text-right">
                              {mapping.status === 'mapped' ? (
                                <Badge variant="success" className="bg-green-500">
                                  <Check className="h-3 w-3 mr-1" />
                                  Mapped
                                </Badge>
                              ) : (
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  className="text-xs h-7"
                                  onClick={() => handleUpdateMapping(mapping.id)}
                                >
                                  Map Field
                                </Button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  
                  {mappings.some((m: any) => m.status !== 'mapped') && (
                    <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 p-3 rounded-md mt-4">
                      <div className="flex items-start">
                        <FileWarning className="h-5 w-5 text-yellow-500 mt-0.5 mr-2 flex-shrink-0" />
                        <div>
                          <h4 className="font-medium text-sm">Mapping Validation</h4>
                          <p className="text-sm mt-1 text-gray-600 dark:text-gray-300">
                            Some fields remain unmapped. Missing mappings may cause partial data synchronization
                            between DockSafe and {systemDetails?.name}.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>
      </Tabs>
      
      {/* Recent Sync Activity */}
      {selectedSystem && systemDetails?.status === 'connected' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <Clock className="mr-2 h-5 w-5" />
              Recent Synchronization Activity
            </CardTitle>
            <CardDescription>
              History of data syncs between DockSafe and {systemDetails.name}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingSyncHistory ? (
              <div className="space-y-2">
                <Skeleton className="h-10" />
                <Skeleton className="h-10" />
                <Skeleton className="h-10" />
              </div>
            ) : syncHistory.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 dark:text-gray-400">No synchronization history available yet</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-4"
                  onClick={() => setActiveTab('endpoints')}
                >
                  Configure Endpoints
                </Button>
              </div>
            ) : (
              <div className="rounded-md border overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-muted/50">
                    <tr>
                      <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Time</th>
                      <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Event</th>
                      <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Status</th>
                      <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">Message</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                    {syncHistory.map((log: any) => (
                      <tr key={log.id}>
                        <td className="px-3 py-3 whitespace-nowrap text-sm">
                          {formatDate(log.timestamp)}
                        </td>
                        <td className="px-3 py-3 whitespace-nowrap text-sm">
                          <div className="flex items-center">
                            {log.event.includes('Push') && <Upload className="h-4 w-4 mr-1 text-blue-500" />}
                            {log.event.includes('Pull') && <Download className="h-4 w-4 mr-1 text-green-500" />}
                            {log.event === 'System Sync' && <RefreshCw className="h-4 w-4 mr-1 text-purple-500" />}
                            {log.event === 'Authentication' && <Shield className="h-4 w-4 mr-1 text-amber-500" />}
                            {log.event}
                          </div>
                        </td>
                        <td className="px-3 py-3 whitespace-nowrap text-sm">
                          {log.status === 'success' && (
                            <Badge variant="success" className="bg-green-500">Success</Badge>
                          )}
                          {log.status === 'error' && (
                            <Badge variant="destructive">Error</Badge>
                          )}
                          {log.status === 'warning' && (
                            <Badge variant="warning" className="bg-yellow-500">Warning</Badge>
                          )}
                        </td>
                        <td className="px-3 py-3 text-sm">
                          {log.message}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default MobileResponsiveIntegrationPanel;
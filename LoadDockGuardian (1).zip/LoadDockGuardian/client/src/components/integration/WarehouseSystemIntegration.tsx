import React from 'react';
import FixedIntegrationPanel from './FixedIntegrationPanel';

const WarehouseSystemIntegration: React.FC = () => {
  return <FixedIntegrationPanel />;
};

export default WarehouseSystemIntegration;
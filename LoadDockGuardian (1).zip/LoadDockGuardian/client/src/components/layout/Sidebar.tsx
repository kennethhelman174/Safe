import React from 'react';
import { Link, useLocation } from 'wouter';
import { cn } from '@/lib/utils';

interface NavLinkProps {
  href: string;
  icon: string;
  label: string;
  active?: boolean;
}

const NavLink: React.FC<NavLinkProps> = ({ href, icon, label, active }) => (
  <li className="mb-2">
    <Link href={href}>
      <a className={cn(
        "flex items-center p-2 rounded-md",
        active 
          ? "bg-primary-foreground/20 text-white" 
          : "hover:bg-primary-foreground/10 text-white"
      )}>
        <span className="material-icons mr-3">{icon}</span>
        <span>{label}</span>
      </a>
    </Link>
  </li>
);

interface SidebarProps {
  onClose?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onClose }) => {
  const [location] = useLocation();

  const isActive = (path: string) => {
    if (path === '/' && location === '/') return true;
    if (path !== '/' && location.startsWith(path)) return true;
    return false;
  };

  return (
    <aside className="bg-primary text-white w-full md:w-64 h-full flex-shrink-0 flex flex-col">
      <div className="p-4 flex items-center justify-between border-b border-primary-foreground/20">
        <Link href="/">
          <a className="flex items-center">
            <div className="safety-stripes h-8 w-8 rounded-md mr-3"></div>
            <h1 className="font-bold text-xl">DockSafe</h1>
          </a>
        </Link>
        {onClose && (
          <button 
            onClick={onClose} 
            className="md:hidden text-white p-1"
            aria-label="Close sidebar"
          >
            <span className="material-icons">close</span>
          </button>
        )}
      </div>
      
      <nav className="px-2 py-4 flex-grow overflow-y-auto">
        <ul>
          <NavLink 
            href="/" 
            icon="dashboard" 
            label="Dashboard" 
            active={isActive('/')}
          />
          <NavLink 
            href="/checklists" 
            icon="fact_check" 
            label="Safety Checklists" 
            active={isActive('/checklists')}
          />
          <NavLink 
            href="/incidents" 
            icon="warning" 
            label="Incident Reports" 
            active={isActive('/incidents')}
          />
          <NavLink 
            href="/vehicles" 
            icon="local_shipping" 
            label="Vehicle Tracking" 
            active={isActive('/vehicles')}
          />
          <NavLink 
            href="/reports" 
            icon="assessment" 
            label="Safety Reports" 
            active={isActive('/reports')}
          />
          <NavLink 
            href="/maintenance" 
            icon="build" 
            label="Maintenance" 
            active={isActive('/maintenance')}
          />
          <NavLink 
            href="/analytics" 
            icon="analytics" 
            label="Safety Analytics" 
            active={isActive('/analytics')}
          />
          <NavLink 
            href="/system-integration" 
            icon="integration_instructions" 
            label="System Integration" 
            active={isActive('/system-integration')}
          />
          
          <NavLink 
            href="/trailer-management" 
            icon="directions_boat" 
            label="Trailer Management" 
            active={isActive('/trailer-management')}
          />
          
          <NavLink 
            href="/dock-employee-dashboard" 
            icon="assignment_turned_in" 
            label="Dock Employee View" 
            active={isActive('/dock-employee-dashboard')}
          />
          
          <NavLink
            href="/admin"
            icon="admin_panel_settings"
            label="Administrator Panel"
            active={isActive('/admin')}
          />
          
          <div className="border-t border-primary-foreground/20 my-4 pt-3">
            <h4 className="text-xs uppercase text-gray-400 px-2 mb-2">Quick Access</h4>
          </div>
          
          <NavLink 
            href="/kiosk" 
            icon="tablet_mac" 
            label="Driver Kiosk" 
            active={isActive('/kiosk')}
          />
          <NavLink 
            href="/kiosk-display" 
            icon="tv" 
            label="Status Display" 
            active={isActive('/kiosk-display')}
          />
          <NavLink 
            href="/incidents/new?quick=true" 
            icon="add_alert" 
            label="Quick Incident Report" 
            active={isActive('/incidents/new') && location.includes('quick=true')}
          />
          <NavLink 
            href="/trailer-release" 
            icon="check_circle" 
            label="Trailer Release Check" 
            active={isActive('/trailer-release')}
          />
        </ul>
      </nav>
      
      <div className="p-4 bg-blue-900">
        <div className="flex items-center text-sm">
          <div className="w-8 h-8 rounded-full bg-blue-700 mr-2 flex items-center justify-center">
            <span className="material-icons text-sm">person</span>
          </div>
          <span>John Operator</span>
          <button className="ml-auto" aria-label="Logout">
            <span className="material-icons">logout</span>
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;

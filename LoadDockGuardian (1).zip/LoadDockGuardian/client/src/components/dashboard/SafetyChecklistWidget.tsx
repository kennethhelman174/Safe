import React, { useState } from 'react';
import { ClipboardCheck } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import SafetyToggle from '@/components/ui/safety-toggle';
import { useToast } from '@/hooks/use-toast';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

export interface ChecklistItem {
  id: number;
  text: string;
  description: string;
  checked: boolean;
  isCritical?: boolean;
}

interface SafetyChecklistWidgetProps {
  items: ChecklistItem[];
  onSubmit?: (items: ChecklistItem[]) => void;
  onReset?: () => void;
}

const SafetyChecklistWidget: React.FC<SafetyChecklistWidgetProps> = ({ 
  items, 
  onSubmit,
  onReset
}) => {
  const [checklistItems, setChecklistItems] = useState<ChecklistItem[]>(items);
  const [trailerType, setTrailerType] = useState<'liveLoad' | 'dropTrailer'>('liveLoad');
  const { toast } = useToast();
  
  // Define specific checklist items for each trailer type
  const liveLoadItems: ChecklistItem[] = [
    { id: 101, text: "Wheel Chocks in Place", description: "Verify wheel chocks are properly positioned", checked: false, isCritical: true },
    { id: 102, text: "Restraint Engaged", description: "Confirm restraint system is properly engaged", checked: false, isCritical: true },
    { id: 103, text: "Signal Lights Active", description: "Check that signal lights are functioning", checked: false, isCritical: true },
    { id: 104, text: "Vehicle Turned Off", description: "Ensure vehicle engine is turned off", checked: false, isCritical: true },
    { id: 105, text: "Glad Hand Lock Placed", description: "Verify glad hand lock is properly secured", checked: false, isCritical: true }
  ];
  
  const dropTrailerItems: ChecklistItem[] = [
    { id: 201, text: "Wheel Chocks in Place", description: "Verify wheel chocks are properly positioned", checked: false, isCritical: true },
    { id: 202, text: "Glad Hand Lock Placed", description: "Verify glad hand lock is properly secured", checked: false, isCritical: true },
    { id: 203, text: "Restraint Engaged", description: "Confirm restraint system is properly engaged", checked: false, isCritical: true },
    { id: 204, text: "Signal Lights Active", description: "Check that signal lights are functioning", checked: false, isCritical: true },
    { id: 205, text: "Trailer Jack Stand Placed", description: "Confirm trailer jack stand is properly positioned", checked: false, isCritical: true }
  ];

  // Handle switching between trailer types
  const handleTrailerTypeChange = (value: 'liveLoad' | 'dropTrailer') => {
    setTrailerType(value);
    setChecklistItems(value === 'liveLoad' ? liveLoadItems : dropTrailerItems);
  };

  // Initialize with the correct checklist when component mounts
  React.useEffect(() => {
    setChecklistItems(trailerType === 'liveLoad' ? liveLoadItems : dropTrailerItems);
  }, [trailerType]);

  const handleToggle = (id: number, checked: boolean) => {
    setChecklistItems(prev => 
      prev.map(item => 
        item.id === id ? { ...item, checked } : item
      )
    );
  };

  const handleReset = () => {
    setChecklistItems(prev => prev.map(item => ({ ...item, checked: false })));
    if (onReset) onReset();
  };

  const handleSubmit = () => {
    const allCriticalItemsChecked = checklistItems
      .filter(item => item.isCritical)
      .every(item => item.checked);

    if (!allCriticalItemsChecked) {
      toast({
        title: "Safety Warning",
        description: "All critical safety items must be checked before approval",
        variant: "destructive"
      });
      return;
    }

    if (onSubmit) onSubmit(checklistItems);

    toast({
      title: "Checklist Submitted",
      description: "Safety checklist has been approved and recorded",
      variant: "default"
    });
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center text-xl font-bold">
          <ClipboardCheck className="mr-2 h-5 w-5 text-primary" />
          Quick Safety Checklist
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        <div className="mb-6">
          <h3 className="font-medium mb-3">Select Trailer Type:</h3>
          <RadioGroup 
            defaultValue="liveLoad" 
            value={trailerType} 
            onValueChange={(value) => handleTrailerTypeChange(value as 'liveLoad' | 'dropTrailer')}
            className="flex flex-col space-y-1"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="liveLoad" id="live-load" />
              <Label htmlFor="live-load" className="font-medium">Live Load</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="dropTrailer" id="drop-trailer" />
              <Label htmlFor="drop-trailer" className="font-medium">Drop Trailer</Label>
            </div>
          </RadioGroup>
        </div>
        
        <div className="border-t pt-4">
          <h3 className="font-medium mb-3">{trailerType === 'liveLoad' ? 'Live Load' : 'Drop Trailer'} Safety Checklist:</h3>
          <div className="space-y-0">
            {checklistItems.map((item) => (
              <SafetyToggle
                key={item.id}
                id={`toggle-${item.id}`}
                label={item.text}
                description={item.description}
                checked={item.checked}
                className="border-b last:border-b-0"
                onToggle={(checked) => handleToggle(item.id, checked)}
              />
            ))}
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          onClick={handleReset}
        >
          Reset Checklist
        </Button>
        <Button
          className="bg-safety-green text-white hover:bg-green-600"
          onClick={handleSubmit}
        >
          Submit & Approve
        </Button>
      </CardFooter>
    </Card>
  );
};

export default SafetyChecklistWidget;

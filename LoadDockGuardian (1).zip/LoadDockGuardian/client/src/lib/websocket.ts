// WebSocket connection manager for real-time notifications

let socket: WebSocket | null = null;
let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
const RECONNECT_DELAY = 3000; // 3 seconds

export type SafetyNotification = {
  type: 'safety_alert';
  alertType: 'incident' | 'checklist' | 'dock_status' | 'system';
  title: string;
  message: string;
  severity: 'success' | 'info' | 'warning' | 'error';
  location?: string;
  timestamp: string;
  incidentId?: number;
  checklistId?: number;
  dockId?: number;
};

export type ConnectionNotification = {
  type: 'connection';
  message: string;
  timestamp: string;
};

export type NotificationMessage = SafetyNotification | ConnectionNotification;

type NotificationCallback = (notification: NotificationMessage) => void;
const subscribers = new Set<NotificationCallback>();

export function subscribeToNotifications(callback: NotificationCallback): () => void {
  subscribers.add(callback);
  return () => {
    subscribers.delete(callback);
  };
}

function notifySubscribers(notification: NotificationMessage) {
  subscribers.forEach(callback => {
    try {
      callback(notification);
    } catch (error) {
      console.error('Error in notification subscriber:', error);
    }
  });
}

export function connectWebSocket() {
  if (socket) {
    // Close existing connection if any
    socket.close();
  }

  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}/ws`;

  socket = new WebSocket(wsUrl);

  socket.addEventListener('open', () => {
    console.log('WebSocket connection established');
    // Clear any reconnect timer if connection is successful
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
  });

  socket.addEventListener('message', (event) => {
    try {
      const notification: NotificationMessage = JSON.parse(event.data);
      notifySubscribers(notification);
    } catch (error) {
      console.error('Error parsing WebSocket message:', error);
    }
  });

  socket.addEventListener('close', () => {
    console.log('WebSocket connection closed, attempting to reconnect...');
    // Schedule reconnection attempt
    if (!reconnectTimer) {
      reconnectTimer = setTimeout(() => {
        reconnectTimer = null;
        connectWebSocket();
      }, RECONNECT_DELAY);
    }
  });

  socket.addEventListener('error', (error) => {
    console.error('WebSocket error:', error);
    // The socket will also trigger 'close' after an error
  });

  return socket;
}

export function disconnectWebSocket() {
  if (socket) {
    socket.close();
    socket = null;
  }
  
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
}
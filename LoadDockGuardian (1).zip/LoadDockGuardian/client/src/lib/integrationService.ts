import { apiRequest } from './queryClient';
import { useQuery } from '@tanstack/react-query';

export interface IntegrationSystem {
  id: string;
  name: string;
  provider: string;
  description: string;
  status: 'connected' | 'disconnected' | 'error';
  connectionDetails?: {
    url: string;
    apiKey?: string;
    username?: string;
    authType: 'api_key' | 'oauth' | 'basic';
    syncInterval: number; // in minutes
  };
}

export interface DataMapping {
  id: string;
  sourceField: string;
  targetField: string;
  dataType: 'string' | 'number' | 'boolean' | 'date' | 'object';
  isRequired: boolean;
  description: string;
  status: 'mapped' | 'unmapped' | 'error';
  transformation?: string; // Optional transformation logic
}

export interface DataEndpoint {
  id: string;
  name: string;
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  direction: 'inbound' | 'outbound' | 'bidirectional';
  enabled: boolean;
  description: string;
  parameters?: Record<string, string>;
  schedule?: string; // Cron expression for scheduled syncs
}

export interface SyncHistory {
  id: string;
  systemId: string;
  endpointId: string;
  timestamp: string;
  status: 'success' | 'error' | 'warning';
  recordsProcessed: number;
  message: string;
  details?: any;
}

// Fetch available integration systems
export async function fetchIntegrationSystems(): Promise<IntegrationSystem[]> {
  try {
    const response = await apiRequest('GET', '/api/integration/systems', null);
    return await response.json();
  } catch (error) {
    console.error('Error fetching integration systems:', error);
    throw error;
  }
}

// Get a specific integration system
export async function getIntegrationSystem(systemId: string): Promise<IntegrationSystem> {
  try {
    const response = await apiRequest('GET', `/api/integration/systems/${systemId}`, null);
    return await response.json();
  } catch (error) {
    console.error(`Error fetching integration system ${systemId}:`, error);
    throw error;
  }
}

// Connect to an integration system
export async function connectToSystem(systemId: string, connectionDetails: any): Promise<IntegrationSystem> {
  try {
    const response = await apiRequest('POST', `/api/integration/systems/${systemId}/connect`, connectionDetails);
    return await response.json();
  } catch (error) {
    console.error(`Error connecting to system ${systemId}:`, error);
    throw error;
  }
}

// Disconnect from an integration system
export async function disconnectFromSystem(systemId: string): Promise<{ success: boolean; message: string }> {
  try {
    const response = await apiRequest('POST', `/api/integration/systems/${systemId}/disconnect`, null);
    return await response.json();
  } catch (error) {
    console.error(`Error disconnecting from system ${systemId}:`, error);
    throw error;
  }
}

// Fetch data mappings for a system
export async function fetchDataMappings(systemId: string): Promise<DataMapping[]> {
  try {
    const response = await apiRequest('GET', `/api/integration/systems/${systemId}/mappings`, null);
    return await response.json();
  } catch (error) {
    console.error(`Error fetching data mappings for system ${systemId}:`, error);
    throw error;
  }
}

// Update a data mapping
export async function updateDataMapping(systemId: string, mappingId: string, mappingData: Partial<DataMapping>): Promise<DataMapping> {
  try {
    const response = await apiRequest('PUT', `/api/integration/systems/${systemId}/mappings/${mappingId}`, mappingData);
    return await response.json();
  } catch (error) {
    console.error(`Error updating data mapping ${mappingId}:`, error);
    throw error;
  }
}

// Fetch data endpoints for a system
export async function fetchDataEndpoints(systemId: string): Promise<DataEndpoint[]> {
  try {
    const response = await apiRequest('GET', `/api/integration/systems/${systemId}/endpoints`, null);
    return await response.json();
  } catch (error) {
    console.error(`Error fetching data endpoints for system ${systemId}:`, error);
    throw error;
  }
}

// Update data endpoint settings
export async function updateDataEndpoint(systemId: string, endpointId: string, endpointData: Partial<DataEndpoint>): Promise<DataEndpoint> {
  try {
    const response = await apiRequest('PUT', `/api/integration/systems/${systemId}/endpoints/${endpointId}`, endpointData);
    return await response.json();
  } catch (error) {
    console.error(`Error updating data endpoint ${endpointId}:`, error);
    throw error;
  }
}

// Trigger a manual sync for a specific endpoint
export async function triggerSync(systemId: string, endpointId: string): Promise<{ jobId: string; status: string }> {
  try {
    const response = await apiRequest('POST', `/api/integration/systems/${systemId}/sync/${endpointId}`, null);
    return await response.json();
  } catch (error) {
    console.error(`Error triggering sync for endpoint ${endpointId}:`, error);
    throw error;
  }
}

// Fetch sync history
export async function fetchSyncHistory(systemId: string, limit: number = 20): Promise<SyncHistory[]> {
  try {
    const response = await apiRequest('GET', `/api/integration/systems/${systemId}/history?limit=${limit}`, null);
    return await response.json();
  } catch (error) {
    console.error(`Error fetching sync history for system ${systemId}:`, error);
    throw error;
  }
}

// Test a data connection
export async function testConnection(systemId: string, connectionDetails: any): Promise<{ success: boolean; message: string }> {
  try {
    const response = await apiRequest('POST', `/api/integration/systems/${systemId}/test-connection`, connectionDetails);
    return await response.json();
  } catch (error) {
    console.error(`Error testing connection for system ${systemId}:`, error);
    throw error;
  }
}

// Get system logs
export async function getSystemLogs(systemId: string, limit: number = 100): Promise<any[]> {
  try {
    const response = await apiRequest('GET', `/api/integration/systems/${systemId}/logs?limit=${limit}`, null);
    return await response.json();
  } catch (error) {
    console.error(`Error fetching logs for system ${systemId}:`, error);
    throw error;
  }
}

// React Query Hooks for Integration Features

// Hook to fetch all available systems
export const useSystems = () => {
  return useQuery({ 
    queryKey: ['/api/integration/systems'],
    queryFn: async () => {
      try {
        const response = await apiRequest('GET', '/api/integration/systems', null);
        return response.json();
      } catch (error) {
        console.error('Error fetching integration systems:', error);
        throw error;
      }
    }
  });
};

// Hook to fetch a specific system details
export const useSystemDetails = (systemId: string | null) => {
  return useQuery({
    queryKey: ['/api/integration/systems', systemId],
    queryFn: async () => {
      if (!systemId) return null;
      try {
        const response = await apiRequest('GET', `/api/integration/systems/${systemId}`, null);
        return response.json();
      } catch (error) {
        console.error(`Error fetching integration system ${systemId}:`, error);
        throw error;
      }
    },
    enabled: !!systemId
  });
};

// Hook to fetch endpoints for a system
export const useSystemEndpoints = (systemId: string | null) => {
  return useQuery({
    queryKey: ['/api/integration/systems', systemId, 'endpoints'],
    queryFn: async () => {
      if (!systemId) return [];
      try {
        const response = await apiRequest('GET', `/api/integration/systems/${systemId}/endpoints`, null);
        return response.json();
      } catch (error) {
        console.error(`Error fetching data endpoints for system ${systemId}:`, error);
        throw error;
      }
    },
    enabled: !!systemId
  });
};

// Hook to fetch mappings for a system
export const useSystemMappings = (systemId: string | null) => {
  return useQuery({
    queryKey: ['/api/integration/systems', systemId, 'mappings'],
    queryFn: async () => {
      if (!systemId) return [];
      try {
        const response = await apiRequest('GET', `/api/integration/systems/${systemId}/mappings`, null);
        return response.json();
      } catch (error) {
        console.error(`Error fetching data mappings for system ${systemId}:`, error);
        throw error;
      }
    },
    enabled: !!systemId
  });
};

// Hook to fetch sync history for a system
export const useSyncHistory = (systemId: string | null) => {
  return useQuery({
    queryKey: ['/api/integration/systems', systemId, 'history'],
    queryFn: async () => {
      if (!systemId) return [];
      try {
        const response = await apiRequest('GET', `/api/integration/systems/${systemId}/history`, null);
        return response.json();
      } catch (error) {
        console.error(`Error fetching sync history for system ${systemId}:`, error);
        throw error;
      }
    },
    enabled: !!systemId,
    refetchInterval: 30000 // Refresh every 30 seconds
  });
};
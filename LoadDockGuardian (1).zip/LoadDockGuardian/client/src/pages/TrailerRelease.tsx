import React, { useState } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { CheckSquare, Truck, FileText } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { t } from '@/lib/i18n';

interface TrailerReleaseItem {
  id: string;
  label: string;
  required: boolean;
  checked: boolean;
}

const TrailerRelease: React.FC = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    dockNumber: '',
    trailerNumber: '',
    driverName: '',
    vehicleNumber: '',
    notes: '',
  });
  
  const [checklistItems, setChecklistItems] = useState<TrailerReleaseItem[]>([
    { 
      id: 'personnel-equipment', 
      label: 'All Personnel and Equipment Removed from Trailer', 
      required: true, 
      checked: false 
    },
    { 
      id: 'dock-leveler', 
      label: 'Dock Leveler Removed', 
      required: true, 
      checked: false 
    },
    { 
      id: 'dock-door', 
      label: 'Dock Door Closed', 
      required: true, 
      checked: false 
    },
    { 
      id: 'glad-hand', 
      label: 'Glad Hand Lock Removed', 
      required: true, 
      checked: false 
    },
    { 
      id: 'wheel-chocks', 
      label: 'Wheel Chocks Removed', 
      required: true, 
      checked: false 
    },
    { 
      id: 'jack-stand', 
      label: 'Jack Stand Removed (If Applicable)', 
      required: false, 
      checked: false 
    },
    { 
      id: 'vehicle-restraint', 
      label: 'Vehicle Restraint Released', 
      required: true, 
      checked: false 
    },
  ]);

  const handleChecklistChange = (id: string) => {
    setChecklistItems(
      checklistItems.map(item => 
        item.id === id ? { ...item, checked: !item.checked } : item
      )
    );
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    // Validate required checklist items
    const hasAllRequiredChecks = checklistItems
      .filter(item => item.required)
      .every(item => item.checked);
    
    if (!hasAllRequiredChecks) {
      toast({
        title: "Safety Warning",
        description: "You must complete all required checklist items before trailer release",
        variant: "destructive"
      });
      return;
    }
    
    // Validate form data
    if (!formData.dockNumber || !formData.trailerNumber) {
      toast({
        title: "Missing Information",
        description: "Please provide dock number and trailer number",
        variant: "destructive"
      });
      return;
    }

    // In a real application, this would be submitted to the server
    console.log('Trailer release completed:', { formData, checklistItems });
    
    toast({
      title: "Trailer Release Confirmed",
      description: `Trailer ${formData.trailerNumber} at dock ${formData.dockNumber} has been safely released`,
    });
    
    // Reset form
    setFormData({
      dockNumber: '',
      trailerNumber: '',
      driverName: '',
      vehicleNumber: '',
      notes: '',
    });
    setChecklistItems(
      checklistItems.map(item => ({ ...item, checked: false }))
    );
  };

  const handleCancel = () => {
    // Reset form
    setFormData({
      dockNumber: '',
      trailerNumber: '',
      driverName: '',
      vehicleNumber: '',
      notes: '',
    });
    setChecklistItems(
      checklistItems.map(item => ({ ...item, checked: false }))
    );
  };

  return (
    <MainLayout title="Trailer Release Safety Checklist" description="Confirm safety procedures before releasing trailers">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold mb-6 flex items-center">
          <Truck className="mr-2 h-6 w-6 text-primary" />
          Trailer Release Safety Checklist
        </h1>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-xl font-semibold">
              <CheckSquare className="mr-2 h-5 w-5 text-primary" />
              Safety Verification
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dockNumber">Dock Number *</Label>
                  <Input 
                    id="dockNumber" 
                    name="dockNumber" 
                    placeholder="Enter dock number" 
                    value={formData.dockNumber}
                    onChange={handleInputChange}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="trailerNumber">Trailer Number *</Label>
                  <Input 
                    id="trailerNumber" 
                    name="trailerNumber" 
                    placeholder="Enter trailer number" 
                    value={formData.trailerNumber}
                    onChange={handleInputChange}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="driverName">Driver Name</Label>
                  <Input 
                    id="driverName" 
                    name="driverName" 
                    placeholder="Enter driver name" 
                    value={formData.driverName}
                    onChange={handleInputChange}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="vehicleNumber">Vehicle Number</Label>
                  <Input 
                    id="vehicleNumber" 
                    name="vehicleNumber" 
                    placeholder="Enter vehicle number" 
                    value={formData.vehicleNumber}
                    onChange={handleInputChange}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Input 
                  id="notes" 
                  name="notes" 
                  placeholder="Add any additional notes" 
                  value={formData.notes}
                  onChange={handleInputChange}
                />
              </div>
              
              <div className="border-t pt-4 mt-4">
                <h3 className="font-medium text-lg mb-4">
                  Release Safety Verification Checklist
                </h3>
                
                <div className="space-y-4">
                  {checklistItems.map((item) => (
                    <div key={item.id} className="flex items-start space-x-2">
                      <Checkbox 
                        id={item.id}
                        checked={item.checked}
                        onCheckedChange={() => handleChecklistChange(item.id)}
                        className="mt-1"
                      />
                      <div className="space-y-1">
                        <Label 
                          htmlFor={item.id}
                          className={item.required ? "font-medium" : ""}
                        >
                          {item.label}
                          {item.required && <span className="text-red-500 ml-1">*</span>}
                        </Label>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="bg-amber-50 dark:bg-amber-950/20 text-amber-800 dark:text-amber-200 p-4 rounded-md border border-amber-200 dark:border-amber-900 text-sm">
                <p className="font-semibold">IMPORTANT SAFETY NOTICE:</p>
                <p className="mt-1">
                  This checklist ensures all safety procedures are followed before releasing a trailer. 
                  All required items must be completed to ensure personnel safety and prevent equipment damage.
                </p>
              </div>
            </div>
          </CardContent>
          
          <CardFooter className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={handleCancel}
            >
              Cancel
            </Button>
            
            <Button 
              onClick={handleSubmit}
              className="bg-green-600 hover:bg-green-700"
            >
              Confirm Release
            </Button>
          </CardFooter>
        </Card>
      </div>
    </MainLayout>
  );
};

export default TrailerRelease;
import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useRoute } from 'wouter';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Clock, AlertCircle, CheckCircle, BookOpen, Activity, FileText, CalendarClock } from 'lucide-react';
import { LoadingState, Spinner } from '@/components/ui/spinner';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { formatDistanceToNow } from 'date-fns';

interface Dock {
  id: number;
  name: string;
  status: string;
  lastActivity: string;
  vehicleId: number | null;
  maintenanceIssue?: string;
}

interface ActivityLog {
  id: number;
  dockId: number;
  userId: number;
  type: string;
  message: string;
  timestamp: string;
}

interface ChecklistRecord {
  id: number;
  dockId: number;
  userId: number;
  completedAt: string;
  allPassed: boolean;
  type: string;
  items: Array<{
    itemId: number;
    text: string;
    passed: boolean;
  }>;
}

interface MaintenanceRecord {
  id: number;
  dockId: number;
  date: string;
  issue: string;
  action: string;
  status: string;
  technicianId: number;
}

const DockDetail: React.FC = () => {
  const [, params] = useRoute('/docks/:id');
  const dockId = params?.id ? parseInt(params.id) : 0;
  const { toast } = useToast();
  
  const [maintenanceNote, setMaintenanceNote] = useState('');
  const [maintenanceIssue, setMaintenanceIssue] = useState('');
  const [maintenanceAction, setMaintenanceAction] = useState('');
  
  // Fetch dock data
  const { data: dock, isLoading: isLoadingDock } = useQuery<Dock>({
    queryKey: ['/api/docks', dockId],
    queryFn: async () => {
      const response = await apiRequest('GET', `/api/docks/${dockId}`, null);
      return response.json();
    },
    enabled: !!dockId,
  });
  
  // Fetch checklist history
  const { data: checklistHistory = [], isLoading: isLoadingChecklists } = useQuery<ChecklistRecord[]>({
    queryKey: ['/api/completed-checklists/dock', dockId],
    queryFn: async () => {
      try {
        const response = await apiRequest('GET', `/api/completed-checklists/dock/${dockId}`, null);
        return await response.json();
      } catch (error) {
        console.error('Error fetching checklist history:', error);
        return [];
      }
    },
    enabled: !!dockId,
  });
  
  // Fetch maintenance records - mocked for now
  const { data: maintenanceRecords = [], isLoading: isLoadingMaintenance } = useQuery<MaintenanceRecord[]>({
    queryKey: ['/api/maintenance', dockId],
    queryFn: async () => {
      try {
        const response = await apiRequest('GET', `/api/maintenance`, null);
        // Parse and filter for this dock
        const data = await response.json();
        return data.filter((record: any) => String(record.dockId) === String(dockId));
      } catch (error) {
        console.error('Error fetching maintenance records:', error);
        return [];
      }
    },
    enabled: !!dockId,
  });
  
  // Fetch activity log - mocked for now
  const { data: activityLog = [], isLoading: isLoadingActivity } = useQuery<ActivityLog[]>({
    queryKey: ['/api/activity-log/dock', dockId],
    queryFn: async () => {
      try {
        const response = await apiRequest('GET', `/api/activity-log/dock`, null);
        // Parse and filter for this dock in the frontend (since API doesn't support filtering yet)
        const data = await response.json();
        return data.filter((log: any) => String(log.dockId) === String(dockId));
      } catch (error) {
        console.error('Error fetching activity log:', error);
        return [];
      }
    },
    enabled: !!dockId,
  });

  // Mutation for marking dock out of service
  const markOutOfService = useMutation({
    mutationFn: async (outOfService: boolean) => {
      return apiRequest('PUT', `/api/docks/${dockId}`, {
        status: outOfService ? 'out_of_service' : 'available',
        maintenanceNote: maintenanceNote,
        maintenanceIssue: maintenanceIssue,
        maintenanceAction: maintenanceAction
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/docks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/docks', dockId] });
      
      toast({
        title: "Dock Status Updated",
        description: `Dock has been marked ${dockData?.status === 'out_of_service' ? 'available' : 'out of service'}`,
      });
      
      // Reset form
      setMaintenanceNote('');
      setMaintenanceIssue('');
      setMaintenanceAction('');
    },
    onError: (error) => {
      toast({
        title: "Error Updating Dock",
        description: "Failed to update dock status. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Handle marking dock out of service
  const handleMarkOutOfService = () => {
    if (!maintenanceIssue || !maintenanceAction) {
      toast({
        title: "Missing Information",
        description: "Please provide the issue and corrective action",
        variant: "destructive"
      });
      return;
    }
    
    markOutOfService.mutate(true);
  };

  // Handle marking dock back in service
  const handleMarkInService = () => {
    markOutOfService.mutate(false);
  };

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    if (name === 'maintenanceIssue') setMaintenanceIssue(value);
    if (name === 'maintenanceAction') setMaintenanceAction(value);
    if (name === 'maintenanceNote') setMaintenanceNote(value);
  };

  // Render status badge with appropriate color
  const renderStatusBadge = (status: any) => {
    let statusStr = typeof status === 'string' ? status : String(status);
    let variant: 'default' | 'destructive' | 'outline' | 'secondary' | 'success' | 'warning' = 'default';
    
    switch (statusStr) {
      case 'safe':
      case 'in_use':
        variant = 'success';
        break;
      case 'caution':
        variant = 'warning';
        break;
      case 'danger':
      case 'out_of_service':
        variant = 'destructive';
        break;
      case 'available':
        variant = 'secondary';
        break;
      default:
        variant = 'default';
    }
    
    return (
      <Badge variant={variant} className="text-sm">
        {statusStr === 'in_use' ? 'In Use' : 
         statusStr === 'out_of_service' ? 'Out of Service' : 
         typeof statusStr === 'string' && statusStr 
          ? statusStr.charAt(0).toUpperCase() + statusStr.slice(1) 
          : 'Unknown'}
      </Badge>
    );
  };

  if (isLoadingDock) {
    return (
      <MainLayout title="Loading Dock Details" description="Loading...">
        <LoadingState message="Loading dock information..." />
      </MainLayout>
    );
  }

  // Set default dock data if dock is undefined
  const dockData = dock || {
    id: dockId,
    name: `${dockId}`,
    status: 'available',
    lastActivity: new Date().toISOString(),
    vehicleId: null,
    maintenanceIssue: ''
  };

  return (
    <MainLayout title={`Dock ${dockData.name} Details`} description={`Management and History for Dock ${dockData.name}`}>
      <div className="mb-6">
        <div className="flex flex-wrap justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Dock {dockData.name}</h1>
            <div className="flex items-center mt-2">
              <span className="mr-2">Current Status:</span>
              {renderStatusBadge(dockData.status)}
            </div>
          </div>
          
          <div className="flex space-x-2 mt-4 sm:mt-0">
            {dockData.status === 'out_of_service' ? (
              <Button onClick={handleMarkInService} className="bg-green-600 hover:bg-green-700">
                Mark as Available
              </Button>
            ) : (
              <Button onClick={() => document.getElementById('maintenance-form')?.scrollIntoView({ behavior: 'smooth' })} variant="destructive">
                Mark Out of Service
              </Button>
            )}
          </div>
        </div>
      </div>
      
      <Tabs defaultValue="details">
        <TabsList className="w-full">
          <TabsTrigger value="details" className="flex-1">
            <FileText className="w-4 h-4 mr-2" />
            Dock Details
          </TabsTrigger>
          <TabsTrigger value="history" className="flex-1">
            <BookOpen className="w-4 h-4 mr-2" />
            History
          </TabsTrigger>
          <TabsTrigger value="checklists" className="flex-1">
            <CheckCircle className="w-4 h-4 mr-2" />
            Safety Checklists
          </TabsTrigger>
          <TabsTrigger value="maintenance" className="flex-1">
            <Activity className="w-4 h-4 mr-2" />
            Maintenance
          </TabsTrigger>
        </TabsList>
        
        {/* Details Tab */}
        <TabsContent value="details" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Dock Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Dock Number:</span>
                  <p>{dockData.name}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Status:</span>
                  <p className="capitalize">{dockData.status.replace(/_/g, ' ')}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Last Activity:</span>
                  <p>{dockData.lastActivity ? new Date(dockData.lastActivity).toLocaleString() : 'No recent activity'}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Assigned Vehicle:</span>
                  <p>{dockData.vehicleId ? `Vehicle #${dockData.vehicleId}` : 'None'}</p>
                </div>
                {dockData.status === 'out_of_service' && dockData.maintenanceIssue && (
                  <div className="col-span-2 space-y-1">
                    <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Maintenance Issue:</span>
                    <p className="p-2 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900 rounded text-red-700 dark:text-red-300">
                      {dockData.maintenanceIssue}
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Current Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className={`w-4 h-4 rounded-full mr-2 ${
                    dockData.status === 'safe' || dockData.status === 'in_use' 
                      ? 'bg-green-500' 
                      : dockData.status === 'caution' 
                        ? 'bg-amber-500' 
                        : dockData.status === 'danger' || dockData.status === 'out_of_service'
                          ? 'bg-red-500'
                          : 'bg-gray-400'
                  }`}></div>
                  <span className="font-medium">
                    {dockData.status === 'in_use' ? 'In Use' : 
                     dockData.status === 'out_of_service' ? 'Out of Service' : 
                     dockData.status.charAt(0).toUpperCase() + dockData.status.slice(1)}
                  </span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4">
                  <div className="space-y-2">
                    <h4 className="font-medium">Safety Checklist Status:</h4>
                    <div className="flex items-center">
                      {isLoadingChecklists ? (
                        <Spinner className="mr-2" />
                      ) : checklistHistory && checklistHistory.length > 0 ? (
                        <>
                          <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
                          <span>Last completed: {formatDistanceToNow(new Date(checklistHistory[0].completedAt), { addSuffix: true })}</span>
                        </>
                      ) : (
                        <>
                          <AlertCircle className="w-5 h-5 text-amber-500 mr-2" />
                          <span>No recent checklists</span>
                        </>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-medium">Last Maintenance:</h4>
                    <div className="flex items-center">
                      {isLoadingMaintenance ? (
                        <Spinner className="mr-2" />
                      ) : maintenanceRecords && maintenanceRecords.length > 0 ? (
                        <>
                          <CalendarClock className="w-5 h-5 text-blue-500 mr-2" />
                          <span>Last service: {formatDistanceToNow(new Date(maintenanceRecords[0].date), { addSuffix: true })}</span>
                        </>
                      ) : (
                        <>
                          <Clock className="w-5 h-5 text-gray-500 mr-2" />
                          <span>No maintenance history</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* History Tab */}
        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Dock Activity History</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingActivity ? (
                <div className="flex justify-center py-4">
                  <Spinner />
                </div>
              ) : activityLog && activityLog.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Activity Type</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>User</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {activityLog.map((activity) => (
                      <TableRow key={activity.id}>
                        <TableCell>{new Date(activity.timestamp).toLocaleString()}</TableCell>
                        <TableCell>
                          <Badge variant={
                            activity.type === 'status_change' ? 'default' :
                            activity.type === 'safety_check' ? 'success' :
                            activity.type === 'maintenance' ? 'secondary' :
                            activity.type === 'incident' ? 'destructive' : 'outline'
                          }>
                            {activity.type.replace('_', ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell>{activity.message}</TableCell>
                        <TableCell>{activity.userId === 1 ? 'Admin' : `User ${activity.userId}`}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-6">
                  <BookOpen className="h-10 w-10 text-gray-400 dark:text-gray-600 mx-auto mb-2" />
                  <p>No activity history available for this dock</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Checklists Tab */}
        <TabsContent value="checklists" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Safety Checklist History</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingChecklists ? (
                <div className="flex justify-center py-4">
                  <Spinner />
                </div>
              ) : checklistHistory && checklistHistory.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Completed By</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Type</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {checklistHistory.map((checklist) => (
                      <TableRow key={checklist.id}>
                        <TableCell>{new Date(checklist.completedAt).toLocaleString()}</TableCell>
                        <TableCell>{checklist.userId === 1 ? 'John Operator' : `User ${checklist.userId}`}</TableCell>
                        <TableCell>
                          <Badge variant={checklist.allPassed ? 'success' : 'destructive'}>
                            {checklist.allPassed ? 'Passed' : 'Failed'}
                          </Badge>
                        </TableCell>
                        <TableCell>{checklist.type || 'Standard'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-6">
                  <CheckCircle className="h-10 w-10 text-gray-400 dark:text-gray-600 mx-auto mb-2" />
                  <p>No safety checklist records available for this dock</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Maintenance Tab */}
        <TabsContent value="maintenance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Maintenance History</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingMaintenance ? (
                <div className="flex justify-center py-4">
                  <Spinner />
                </div>
              ) : maintenanceRecords && maintenanceRecords.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Issue</TableHead>
                      <TableHead>Action Taken</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {maintenanceRecords.map((record) => (
                      <TableRow key={record.id}>
                        <TableCell>{new Date(record.date).toLocaleDateString()}</TableCell>
                        <TableCell>{record.issue}</TableCell>
                        <TableCell>{record.action}</TableCell>
                        <TableCell>
                          <Badge variant={
                            record.status === 'resolved' ? 'success' :
                            record.status === 'in_progress' ? 'secondary' :
                            'warning'
                          }>
                            {record.status.replace('_', ' ')}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-6">
                  <Activity className="h-10 w-10 text-gray-400 dark:text-gray-600 mx-auto mb-2" />
                  <p>No maintenance records available for this dock</p>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Out of Service Form */}
          {dockData.status !== 'out_of_service' && (
            <Card id="maintenance-form">
              <CardHeader>
                <CardTitle>Mark Dock Out of Service</CardTitle>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="maintenanceIssue">Issue Description *</Label>
                    <Textarea
                      id="maintenanceIssue"
                      name="maintenanceIssue"
                      value={maintenanceIssue}
                      onChange={handleInputChange}
                      placeholder="Describe the issue requiring maintenance"
                      rows={3}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="maintenanceAction">Corrective Action Needed *</Label>
                    <Textarea
                      id="maintenanceAction"
                      name="maintenanceAction"
                      value={maintenanceAction}
                      onChange={handleInputChange}
                      placeholder="Describe the maintenance action required"
                      rows={3}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="maintenanceNote">Additional Notes</Label>
                    <Textarea
                      id="maintenanceNote"
                      name="maintenanceNote"
                      value={maintenanceNote}
                      onChange={handleInputChange}
                      placeholder="Any additional notes (optional)"
                      rows={2}
                    />
                  </div>
                </form>
              </CardContent>
              <CardFooter>
                <Button 
                  onClick={handleMarkOutOfService} 
                  variant="destructive"
                  disabled={markOutOfService.isPending}
                  className="ml-auto"
                >
                  {markOutOfService.isPending ? (
                    <>
                      <Spinner size="sm" className="mr-2" />
                      Updating...
                    </>
                  ) : (
                    'Mark Out of Service'
                  )}
                </Button>
              </CardFooter>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </MainLayout>
  );
};

export default DockDetail;
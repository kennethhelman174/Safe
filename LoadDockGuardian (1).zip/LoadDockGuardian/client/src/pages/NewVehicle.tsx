import React from 'react';
import { useLocation } from 'wouter';
import { useMutation, useQuery } from '@tanstack/react-query';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { apiRequest, queryClient } from '@/lib/queryClient';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Truck, Save, XCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Form schema
const vehicleSchema = z.object({
  trailerNumber: z.string().min(3, {
    message: "Trailer number must be at least 3 characters.",
  }),
  driverName: z.string().min(2, {
    message: "Driver name must be at least 2 characters.",
  }).optional().or(z.literal('')),
  company: z.string().min(2, {
    message: "Company name must be at least 2 characters.",
  }).optional().or(z.literal('')),
  dockId: z.string().optional(),
  status: z.enum(['pending', 'loading', 'unloading']),
});

type VehicleFormValues = z.infer<typeof vehicleSchema>;

const NewVehicle: React.FC = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Fetch docks for dropdown
  const { data: docks = [], isLoading: isLoadingDocks } = useQuery({
    queryKey: ['/api/docks'],
  });

  // Filter out docks that are not available
  const availableDocks = docks.filter((dock: any) => 
    dock.status === 'available' || dock.status === 'in_use'
  );

  // Form setup
  const form = useForm<VehicleFormValues>({
    resolver: zodResolver(vehicleSchema),
    defaultValues: {
      trailerNumber: '',
      driverName: '',
      company: '',
      status: 'pending',
      dockId: undefined,
    },
  });

  // Submit mutation
  const submitMutation = useMutation({
    mutationFn: async (values: VehicleFormValues) => {
      // Convert dockId from string to number
      const formattedValues = {
        ...values,
        dockId: values.dockId ? parseInt(values.dockId) : null,
        userId: 1, // Default user ID for demo
      };
      
      await apiRequest('POST', '/api/vehicles', formattedValues);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/vehicles'] });
      queryClient.invalidateQueries({ queryKey: ['/api/docks'] });
      
      toast({
        title: 'Vehicle Added',
        description: 'New vehicle has been added successfully',
      });
      
      navigate('/vehicles');
    },
    onError: (error) => {
      console.error('Error adding vehicle:', error);
      toast({
        title: 'Failed to Add Vehicle',
        description: 'There was an error adding the vehicle. Please try again.',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (values: VehicleFormValues) => {
    submitMutation.mutate(values);
  };

  return (
    <MainLayout 
      title="Add New Vehicle" 
      description="Register a new vehicle entering the loading dock facility"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-heading text-xl font-bold flex items-center">
          <Truck className="mr-2 h-5 w-5 text-safety-blue" />
          Vehicle Registration
        </h3>
      </div>

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Vehicle Information</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Trailer Number */}
              <FormField
                control={form.control}
                name="trailerNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Trailer Number <span className="text-safety-red">*</span></FormLabel>
                    <FormControl>
                      <Input placeholder="TRL-12345" {...field} />
                    </FormControl>
                    <FormDescription>
                      Enter the unique trailer identification number
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Driver Name */}
              <FormField
                control={form.control}
                name="driverName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Driver Name</FormLabel>
                    <FormControl>
                      <Input placeholder="John Smith" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Company */}
              <FormField
                control={form.control}
                name="company"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Company</FormLabel>
                    <FormControl>
                      <Input placeholder="ABC Logistics" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Status */}
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Operation Status <span className="text-safety-red">*</span></FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select operation status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="loading">Loading</SelectItem>
                        <SelectItem value="unloading">Unloading</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Current operation status for this vehicle
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Dock Assignment */}
              <FormField
                control={form.control}
                name="dockId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assign to Dock</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a dock for assignment" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {isLoadingDocks ? (
                          <SelectItem value="loading" disabled>Loading docks...</SelectItem>
                        ) : availableDocks.length === 0 ? (
                          <SelectItem value="none" disabled>No available docks</SelectItem>
                        ) : (
                          availableDocks.map((dock: any) => (
                            <SelectItem 
                              key={dock.id} 
                              value={dock.id.toString()}
                            >
                              {dock.name} {dock.status === 'in_use' ? '(In Use)' : '(Available)'}
                            </SelectItem>
                          ))
                        )}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Assign this vehicle to a specific loading dock
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Form Actions */}
              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate('/vehicles')}
                >
                  <XCircle className="mr-2 h-4 w-4" />
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  className="bg-safety-blue hover:bg-blue-700"
                  disabled={submitMutation.isPending}
                >
                  <Save className="mr-2 h-4 w-4" />
                  {submitMutation.isPending ? 'Saving...' : 'Save Vehicle'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
      
      <div className="mt-6 p-4 bg-gray-100 rounded-lg border border-gray-300">
        <h4 className="font-heading font-medium mb-2 flex items-center">
          <AlertTriangle className="mr-2 h-4 w-4 text-safety-amber" />
          Important Safety Notice
        </h4>
        <p className="text-sm text-gray-700">
          Ensure all vehicles are properly registered before entering the loading dock area. 
          Vehicles must follow all posted safety guidelines and instructions from dock personnel.
          Drivers should remain in designated waiting areas during loading/unloading operations.
        </p>
      </div>
    </MainLayout>
  );
};

// Add this at the end
import { AlertTriangle } from 'lucide-react';

export default NewVehicle;

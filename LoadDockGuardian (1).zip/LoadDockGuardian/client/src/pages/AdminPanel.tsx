import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import MainLayout from '@/components/layout/MainLayout';
import { useToast } from '@/hooks/use-toast';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';

import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { UserPlus, UserCog, Lock, Users, Search, RefreshCw, CheckCircle2, ShieldAlert } from 'lucide-react';

// Define the user schema
const userSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email address").optional().or(z.literal('')),
  phone: z.string().optional().or(z.literal('')),
  department: z.string().optional().or(z.literal('')),
  role: z.enum(["admin", "manager", "operator", "technician"]),
  isActive: z.boolean().default(true),
});

// Schema for updating a user
const updateUserSchema = userSchema.partial().extend({
  id: z.number(),
});

type UserFormValues = z.infer<typeof userSchema>;
type UpdateUserFormValues = z.infer<typeof updateUserSchema>;

const AdminPanel: React.FC = () => {
  const { toast } = useToast();
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch all users
  const { data: users = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/users', null);
      return response.json();
    },
  });

  // Create user form
  const createUserForm = useForm<UserFormValues>({
    resolver: zodResolver(userSchema),
    defaultValues: {
      username: '',
      password: '',
      name: '',
      email: '',
      phone: '',
      department: '',
      role: 'operator',
      isActive: true,
    },
  });

  // Edit user form
  const editUserForm = useForm<UpdateUserFormValues>({
    resolver: zodResolver(updateUserSchema),
    defaultValues: {
      id: 0,
      username: '',
      name: '',
      email: '',
      phone: '',
      department: '',
      role: '',
      isActive: true,
    },
  });

  // Create user mutation
  const createUserMutation = useMutation({
    mutationFn: async (values: UserFormValues) => {
      return await apiRequest('POST', '/api/users', values);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User has been created successfully",
      });
      createUserForm.reset();
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create user: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Update user mutation
  const updateUserMutation = useMutation({
    mutationFn: async (values: UpdateUserFormValues) => {
      return await apiRequest('PUT', `/api/users/${values.id}`, values);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User has been updated successfully",
      });
      setIsEditDialogOpen(false);
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update user: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Delete user mutation
  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      return await apiRequest('DELETE', `/api/users/${userId}`, null);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User has been deleted successfully",
      });
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete user: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Toggle user active status mutation
  const toggleUserStatusMutation = useMutation({
    mutationFn: async ({ userId, isActive }: { userId: number, isActive: boolean }) => {
      return await apiRequest('PUT', `/api/users/${userId}`, { isActive });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User status has been updated",
      });
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update user status: ${error}`,
        variant: "destructive",
      });
    },
  });

  // Handle user creation
  const onCreateUser = (values: UserFormValues) => {
    createUserMutation.mutate(values);
  };

  // Handle user edit
  const onEditUser = (userId: number) => {
    const user = users.find((u: any) => u.id === userId);
    if (user) {
      setSelectedUser(user);
      editUserForm.reset({
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email || '',
        phone: user.phone || '',
        department: user.department || '',
        role: user.role,
        isActive: user.isActive,
      });
      setIsEditDialogOpen(true);
    }
  };

  // Handle user update
  const onUpdateUser = (values: UpdateUserFormValues) => {
    updateUserMutation.mutate(values);
  };

  // Handle user deletion
  const onDeleteUser = (userId: number) => {
    if (window.confirm("Are you sure you want to delete this user? This action cannot be undone.")) {
      deleteUserMutation.mutate(userId);
    }
  };

  // Handle user status toggle
  const onToggleUserStatus = (userId: number, currentStatus: boolean) => {
    toggleUserStatusMutation.mutate({
      userId,
      isActive: !currentStatus,
    });
  };

  // Filter users based on search query
  const filteredUsers = users.filter((user: any) => {
    const searchLower = searchQuery.toLowerCase();
    return (
      user.username.toLowerCase().includes(searchLower) ||
      user.name.toLowerCase().includes(searchLower) ||
      user.role.toLowerCase().includes(searchLower) ||
      (user.email && user.email.toLowerCase().includes(searchLower)) ||
      (user.department && user.department.toLowerCase().includes(searchLower))
    );
  });

  // Get badge color based on role
  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case 'admin': return 'destructive';
      case 'manager': return 'default';
      case 'operator': return 'secondary';
      case 'technician': return 'outline';
      default: return 'secondary';
    }
  };

  return (
    <MainLayout title="Administrator Panel">
      <Tabs defaultValue="users" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="users">
            <Users className="w-4 h-4 mr-2" />User Management
          </TabsTrigger>
          <TabsTrigger value="roles">
            <UserCog className="w-4 h-4 mr-2" />User Roles & Permissions
          </TabsTrigger>
        </TabsList>
        
        {/* Users Tab Content */}
        <TabsContent value="users">
          <div className="flex flex-col gap-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>User Management</CardTitle>
                    <CardDescription>
                      Add, edit, or remove users from the system
                    </CardDescription>
                  </div>
                  <Button onClick={() => refetch()}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Refresh
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center mb-6">
                  <div className="relative w-full max-w-sm">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search users..."
                      className="pl-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button>
                        <UserPlus className="h-4 w-4 mr-2" />
                        Add New User
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[550px]">
                      <DialogHeader>
                        <DialogTitle>Create New User</DialogTitle>
                        <DialogDescription>
                          Fill in the details to create a new user account in the system.
                        </DialogDescription>
                      </DialogHeader>
                      
                      <Form {...createUserForm}>
                        <form onSubmit={createUserForm.handleSubmit(onCreateUser)} className="space-y-4 py-4">
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={createUserForm.control}
                              name="username"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Username</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={createUserForm.control}
                              name="password"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Password</FormLabel>
                                  <FormControl>
                                    <Input type="password" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <FormField
                            control={createUserForm.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Full Name</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={createUserForm.control}
                              name="email"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Email</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={createUserForm.control}
                              name="phone"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Phone</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={createUserForm.control}
                              name="department"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Department</FormLabel>
                                  <FormControl>
                                    <Input {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={createUserForm.control}
                              name="role"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Role</FormLabel>
                                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select a role" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="admin">Administrator</SelectItem>
                                      <SelectItem value="manager">Manager</SelectItem>
                                      <SelectItem value="operator">Operator</SelectItem>
                                      <SelectItem value="technician">Technician</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <FormField
                            control={createUserForm.control}
                            name="isActive"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                                <div className="space-y-0.5">
                                  <FormLabel>Active Status</FormLabel>
                                  <FormDescription>
                                    User will be able to log in if active
                                  </FormDescription>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          
                          <DialogFooter>
                            <Button type="submit" disabled={createUserMutation.isPending}>
                              {createUserMutation.isPending ? "Creating..." : "Create User"}
                            </Button>
                          </DialogFooter>
                        </form>
                      </Form>
                    </DialogContent>
                  </Dialog>
                </div>
                
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {isLoading ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center py-8">
                            Loading users...
                          </TableCell>
                        </TableRow>
                      ) : filteredUsers.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center py-8">
                            No users found
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredUsers.map((user: any) => (
                          <TableRow key={user.id}>
                            <TableCell>
                              <div className="font-medium">{user.name}</div>
                              <div className="text-sm text-muted-foreground">{user.username}</div>
                              {user.email && <div className="text-xs text-muted-foreground">{user.email}</div>}
                            </TableCell>
                            <TableCell>
                              <Badge variant={getRoleBadgeVariant(user.role)}>
                                {user.role}
                              </Badge>
                            </TableCell>
                            <TableCell>{user.department || '-'}</TableCell>
                            <TableCell>
                              {user.isActive ? (
                                <div className="flex items-center">
                                  <CheckCircle2 className="h-4 w-4 text-green-500 mr-1" />
                                  <span>Active</span>
                                </div>
                              ) : (
                                <div className="flex items-center">
                                  <ShieldAlert className="h-4 w-4 text-red-500 mr-1" />
                                  <span>Inactive</span>
                                </div>
                              )}
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  onClick={() => onEditUser(user.id)}
                                >
                                  Edit
                                </Button>
                                
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => onToggleUserStatus(user.id, user.isActive)}
                                >
                                  {user.isActive ? "Deactivate" : "Activate"}
                                </Button>
                                
                                <Button 
                                  size="sm" 
                                  variant="destructive"
                                  onClick={() => onDeleteUser(user.id)}
                                >
                                  Delete
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* Roles & Permissions Tab Content */}
        <TabsContent value="roles">
          <div className="flex flex-col gap-6">
            <Card>
              <CardHeader>
                <CardTitle>User Roles & Permissions</CardTitle>
                <CardDescription>
                  Configure system roles and their associated permissions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Admin Role */}
                  <div className="rounded-lg border p-4">
                    <div className="flex justify-between items-center mb-4">
                      <div className="flex items-center gap-2">
                        <Badge variant="destructive">Administrator</Badge>
                        <h3 className="text-lg font-semibold">Administrator Role</h3>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Administrators have full access to all features and settings in the system. They can manage users, configure system settings, and access all data.
                    </p>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="admin-users" checked disabled />
                        <label htmlFor="admin-users" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          User Management
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="admin-system" checked disabled />
                        <label htmlFor="admin-system" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          System Configuration
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="admin-reports" checked disabled />
                        <label htmlFor="admin-reports" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          All Reports Access
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="admin-docks" checked disabled />
                        <label htmlFor="admin-docks" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Dock Configuration
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="admin-maintenance" checked disabled />
                        <label htmlFor="admin-maintenance" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Maintenance Management
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="admin-incidents" checked disabled />
                        <label htmlFor="admin-incidents" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Incident Management
                        </label>
                      </div>
                    </div>
                  </div>

                  {/* Manager Role */}
                  <div className="rounded-lg border p-4">
                    <div className="flex justify-between items-center mb-4">
                      <div className="flex items-center gap-2">
                        <Badge>Manager</Badge>
                        <h3 className="text-lg font-semibold">Manager Role</h3>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Managers have access to operational features including user assignment, reports, and operational configurations. They cannot access system-level settings.
                    </p>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="manager-operations" checked disabled />
                        <label htmlFor="manager-operations" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Operations Management
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="manager-reports" checked disabled />
                        <label htmlFor="manager-reports" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Reports Access
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="manager-assign" checked disabled />
                        <label htmlFor="manager-assign" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          User Assignment
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="manager-dock" checked disabled />
                        <label htmlFor="manager-dock" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Dock Status Mgmt
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="manager-maintenance" checked disabled />
                        <label htmlFor="manager-maintenance" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Maintenance Requests
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="manager-incidents" checked disabled />
                        <label htmlFor="manager-incidents" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Incident Management
                        </label>
                      </div>
                    </div>
                  </div>

                  {/* Operator Role */}
                  <div className="rounded-lg border p-4">
                    <div className="flex justify-between items-center mb-4">
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">Operator</Badge>
                        <h3 className="text-lg font-semibold">Operator Role</h3>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Operators can perform day-to-day operations such as dock management, vehicle tracking, and checklist completion. They have limited access to reports.
                    </p>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="operator-docks" checked disabled />
                        <label htmlFor="operator-docks" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Dock Operations
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="operator-vehicles" checked disabled />
                        <label htmlFor="operator-vehicles" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Vehicle Tracking
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="operator-checklists" checked disabled />
                        <label htmlFor="operator-checklists" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Safety Checklists
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="operator-basic-reports" checked disabled />
                        <label htmlFor="operator-basic-reports" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Basic Reports
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="operator-incidents" checked disabled />
                        <label htmlFor="operator-incidents" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Report Incidents
                        </label>
                      </div>
                    </div>
                  </div>

                  {/* Technician Role */}
                  <div className="rounded-lg border p-4">
                    <div className="flex justify-between items-center mb-4">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">Technician</Badge>
                        <h3 className="text-lg font-semibold">Technician Role</h3>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Technicians are responsible for maintenance tasks and repairs. They can view and update maintenance tickets and perform safety inspections.
                    </p>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="tech-maintenance" checked disabled />
                        <label htmlFor="tech-maintenance" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Maintenance Tickets
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="tech-inspections" checked disabled />
                        <label htmlFor="tech-inspections" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Safety Inspections
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="tech-reports" checked disabled />
                        <label htmlFor="tech-reports" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Maintenance Reports
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox id="tech-equipment" checked disabled />
                        <label htmlFor="tech-equipment" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Equipment Status
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between border-t pt-5">
                <p className="text-sm text-muted-foreground">Note: Role permissions are pre-configured and cannot be modified at this time.</p>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Edit User Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
            <DialogDescription>
              Update user details and permissions.
            </DialogDescription>
          </DialogHeader>
          
          {selectedUser && (
            <Form {...editUserForm}>
              <form onSubmit={editUserForm.handleSubmit(onUpdateUser)} className="space-y-4 py-4">
                <input type="hidden" {...editUserForm.register("id")} />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editUserForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editUserForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editUserForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editUserForm.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={editUserForm.control}
                    name="department"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Department</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editUserForm.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Role</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a role" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="admin">Administrator</SelectItem>
                            <SelectItem value="manager">Manager</SelectItem>
                            <SelectItem value="operator">Operator</SelectItem>
                            <SelectItem value="technician">Technician</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={editUserForm.control}
                  name="isActive"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                      <div className="space-y-0.5">
                        <FormLabel>Active Status</FormLabel>
                        <FormDescription>
                          User will be able to log in if active
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsEditDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={updateUserMutation.isPending}
                  >
                    {updateUserMutation.isPending ? "Updating..." : "Update User"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          )}
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default AdminPanel;
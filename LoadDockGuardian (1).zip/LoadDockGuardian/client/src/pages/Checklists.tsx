import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Checkbox } from '@/components/ui/checkbox';
import { apiRequest } from '@/lib/queryClient';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { ClipboardCheck, Check, AlertCircle } from 'lucide-react';

// Define form schema
const checklistFormSchema = z.object({
  checklistItems: z.array(
    z.object({
      id: z.number(),
      checked: z.boolean(),
    })
  ),
  dockId: z.number(),
});

type ChecklistFormValues = z.infer<typeof checklistFormSchema>;

const Checklists: React.FC = () => {
  const [location] = useLocation();
  const { toast } = useToast();
  const [selectedDock, setSelectedDock] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Parse dock ID from URL query params if present
  React.useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    const dockId = params.get('dock');
    if (dockId) {
      setSelectedDock(parseInt(dockId));
    }
  }, [location]);

  // Fetch docks data
  const { data: docks = [], isLoading: isLoadingDocks } = useQuery({
    queryKey: ['/api/docks'],
  });

  // Fetch checklist items
  const { data: checklistItems = [], isLoading: isLoadingChecklist } = useQuery({
    queryKey: ['/api/checklist-items'],
  });

  // Fetch completed checklists for selected dock
  const { data: completedChecklists = [], isLoading: isLoadingCompleted } = useQuery({
    queryKey: ['/api/completed-checklists/dock', selectedDock],
    enabled: !!selectedDock,
  });

  // Setup form
  const form = useForm<ChecklistFormValues>({
    resolver: zodResolver(checklistFormSchema),
    defaultValues: {
      checklistItems: [],
      dockId: selectedDock || 0,
    },
  });

  // Update form values when checklist items or selected dock changes
  React.useEffect(() => {
    if (checklistItems.length > 0 && selectedDock) {
      form.reset({
        checklistItems: checklistItems.map((item: any) => ({
          id: item.id,
          checked: false,
        })),
        dockId: selectedDock,
      });
    }
  }, [checklistItems, selectedDock, form]);

  // Submit checklist
  const submitMutation = useMutation({
    mutationFn: async (values: ChecklistFormValues) => {
      setSubmitting(true);
      
      const formattedItems = checklistItems.map((item: any, index: number) => ({
        ...item,
        checked: values.checklistItems[index]?.checked || false,
      }));
      
      const allPassed = formattedItems.every((item: any) => 
        !item.isCritical || (item.isCritical && item.checked)
      );
      
      await apiRequest('POST', '/api/completed-checklists', {
        dockId: values.dockId,
        userId: 1, // Default user ID
        results: formattedItems,
        allPassed,
      });
      
      setSubmitting(false);
      return values;
    },
    onSuccess: () => {
      toast({
        title: 'Checklist Submitted',
        description: 'Safety checklist has been submitted successfully',
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: 'Submission Failed',
        description: 'There was an error submitting the checklist',
        variant: 'destructive',
      });
      setSubmitting(false);
    },
  });

  const onSubmit = (values: ChecklistFormValues) => {
    submitMutation.mutate(values);
  };

  // Loading state
  if (isLoadingDocks || isLoadingChecklist) {
    return (
      <MainLayout title="Safety Checklists" description="Complete and view safety checklists">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-safety-blue"></div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout title="Safety Checklists" description="Complete and view safety checklists">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Dock Selection */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-xl">Select Dock</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {docks.map((dock: any) => (
                <Button
                  key={dock.id}
                  variant={selectedDock === dock.id ? "default" : "outline"}
                  className="w-full justify-start text-left"
                  onClick={() => setSelectedDock(dock.id)}
                >
                  {dock.name}
                  {dock.status === 'danger' && (
                    <span className="ml-auto text-safety-red">
                      <AlertCircle size={16} />
                    </span>
                  )}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Checklist Form */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center">
              <ClipboardCheck className="mr-2 h-5 w-5" />
              Complete Safety Checklist
              {selectedDock && <span className="ml-2 text-gray-500">({docks.find((d: any) => d.id === selectedDock)?.name})</span>}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!selectedDock ? (
              <div className="text-center py-8 text-gray-500">
                Please select a dock to complete a safety checklist
              </div>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="space-y-4">
                    {checklistItems.map((item: any, index: number) => (
                      <FormField
                        key={item.id}
                        control={form.control}
                        name={`checklistItems.${index}.checked`}
                        render={({ field }) => (
                          <FormItem className="flex items-start space-x-3 space-y-0 rounded-md border p-4">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel className="text-base">
                                {item.text}
                                {item.isCritical && (
                                  <span className="ml-2 text-xs text-safety-red font-semibold">(CRITICAL)</span>
                                )}
                              </FormLabel>
                              <p className="text-sm text-gray-500">{item.description}</p>
                            </div>
                          </FormItem>
                        )}
                      />
                    ))}
                  </div>

                  <div className="flex justify-end space-x-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => form.reset()}
                      disabled={submitting}
                    >
                      Reset
                    </Button>
                    <Button
                      type="submit"
                      disabled={submitting || !selectedDock}
                      className="bg-safety-green text-white hover:bg-green-600"
                    >
                      {submitting ? "Submitting..." : "Submit & Approve"}
                    </Button>
                  </div>
                </form>
              </Form>
            )}
          </CardContent>
        </Card>

        {/* Completed Checklists History */}
        {selectedDock && (
          <Card className="lg:col-span-3 mt-6">
            <CardHeader>
              <CardTitle>Checklist History</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingCompleted ? (
                <div className="flex justify-center py-4">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-safety-blue"></div>
                </div>
              ) : completedChecklists.length === 0 ? (
                <div className="text-center py-4 text-gray-500">
                  No completed checklists found for this dock
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Completed By</TableHead>
                      <TableHead>Items Checked</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {completedChecklists.map((checklist: any) => (
                      <TableRow key={checklist.id}>
                        <TableCell>
                          {new Date(checklist.completedAt).toLocaleString()}
                        </TableCell>
                        <TableCell>
                          <span className={`flex items-center ${checklist.allPassed ? 'text-safety-green' : 'text-safety-red'}`}>
                            {checklist.allPassed ? (
                              <>
                                <Check size={16} className="mr-1" />
                                <span>PASSED</span>
                              </>
                            ) : (
                              <>
                                <AlertCircle size={16} className="mr-1" />
                                <span>FAILED</span>
                              </>
                            )}
                          </span>
                        </TableCell>
                        <TableCell>J. Martinez</TableCell>
                        <TableCell>
                          {checklist.results.filter((r: any) => r.checked).length}/{checklist.results.length}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
};

export default Checklists;

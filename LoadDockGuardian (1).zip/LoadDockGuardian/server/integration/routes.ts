import express from 'express';
import {
  getWmsSystems,
  getWmsSystem,
  connectWmsSystem,
  disconnectWmsSystem,
  getWmsEndpoints,
  updateWmsEndpoint,
  getWmsMappings,
  updateWmsMapping,
  getWmsSyncHistory,
  triggerWmsSync,
  testWmsConnection,
  getWmsEndpointSampleData
} from './wmsController';

const router = express.Router();

// Systems routes
router.get('/systems', getWmsSystems);
router.get('/systems/:systemId', getWmsSystem);
router.post('/systems/:systemId/connect', connectWmsSystem);
router.post('/systems/:systemId/disconnect', disconnectWmsSystem);
router.post('/systems/:systemId/test-connection', testWmsConnection);

// Endpoints routes
router.get('/systems/:systemId/endpoints', getWmsEndpoints);
router.put('/systems/:systemId/endpoints/:endpointId', updateWmsEndpoint);
router.get('/systems/:systemId/endpoints/:endpointId/sample', getWmsEndpointSampleData);

// Mappings routes
router.get('/systems/:systemId/mappings', getWmsMappings);
router.put('/systems/:systemId/mappings/:mappingId', updateWmsMapping);

// Sync routes
router.get('/systems/:systemId/history', getWmsSyncHistory);
router.post('/systems/:systemId/sync/:endpointId', triggerWmsSync);

export default router;
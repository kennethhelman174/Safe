import { Request, Response } from 'express';
import { storage } from '../storage';

// Available WMS systems for integration
const availableWmsSystems = [
  {
    id: 'sap',
    name: 'SAP Warehouse Management',
    provider: 'SAP',
    description: 'Enterprise-grade warehouse management module of SAP ERP',
    status: 'disconnected',
    logo: 'sap_logo',
    capabilities: ['inventory', 'shipments', 'receiving', 'analytics']
  },
  {
    id: 'oracle',
    name: 'Oracle WMS Cloud',
    provider: 'Oracle',
    description: 'Cloud-based warehouse management solution from Oracle',
    status: 'connected',
    logo: 'oracle_logo',
    capabilities: ['inventory', 'shipments', 'receiving', 'labor', 'analytics']
  },
  {
    id: 'manhattan',
    name: 'Manhattan WMS',
    provider: 'Manhattan Associates',
    description: 'Comprehensive warehouse management system for complex operations',
    status: 'disconnected',
    logo: 'manhattan_logo',
    capabilities: ['inventory', 'shipments', 'receiving', 'labor', 'analytics', 'yard_management']
  },
  {
    id: 'infor',
    name: 'Infor SCM',
    provider: 'Infor',
    description: 'Supply chain management solution with warehouse capabilities',
    status: 'connected',
    logo: 'infor_logo',
    capabilities: ['inventory', 'shipments', 'receiving', 'analytics']
  },
  {
    id: 'highjump',
    name: 'HighJump WMS',
    provider: 'Korber Supply Chain',
    description: 'Scalable warehouse management solution for diverse industries',
    status: 'disconnected',
    logo: 'highjump_logo',
    capabilities: ['inventory', 'shipments', 'receiving', 'labor']
  }
];

// Available data endpoints for integration
const dataEndpoints = {
  sap: [
    {
      id: 'inbound_shipments',
      name: 'Inbound Shipments',
      path: '/api/logistics/inbound',
      method: 'GET',
      direction: 'inbound',
      enabled: false,
      description: 'Import scheduled inbound shipments from SAP'
    },
    {
      id: 'outbound_shipments',
      name: 'Outbound Shipments',
      path: '/api/logistics/outbound',
      method: 'GET',
      direction: 'inbound',
      enabled: false,
      description: 'Import scheduled outbound shipments from SAP'
    },
    {
      id: 'dock_assignments',
      name: 'Dock Assignments',
      path: '/api/logistics/dock-assignments',
      method: 'GET',
      direction: 'inbound',
      enabled: false,
      description: 'Import dock assignments from SAP'
    },
    {
      id: 'safety_incidents',
      name: 'Safety Incidents',
      path: '/api/logistics/safety-incidents',
      method: 'POST',
      direction: 'outbound',
      enabled: false,
      description: 'Export safety incidents to SAP'
    }
  ],
  oracle: [
    {
      id: 'inbound_shipments',
      name: 'Inbound Shipments',
      path: '/rest/v1/inbound-shipments',
      method: 'GET',
      direction: 'inbound',
      enabled: true,
      description: 'Import scheduled inbound shipments from Oracle WMS'
    },
    {
      id: 'outbound_shipments',
      name: 'Outbound Shipments',
      path: '/rest/v1/outbound-shipments',
      method: 'GET',
      direction: 'inbound',
      enabled: true,
      description: 'Import scheduled outbound shipments from Oracle WMS'
    },
    {
      id: 'dock_assignments',
      name: 'Dock Assignments',
      path: '/rest/v1/dock-assignments',
      method: 'GET',
      direction: 'bidirectional',
      enabled: true,
      description: 'Synchronize dock assignments with Oracle WMS'
    },
    {
      id: 'safety_incidents',
      name: 'Safety Incidents',
      path: '/rest/v1/safety-incidents',
      method: 'POST',
      direction: 'outbound',
      enabled: true,
      description: 'Export safety incidents to Oracle WMS'
    },
    {
      id: 'safety_metrics',
      name: 'Safety Metrics',
      path: '/rest/v1/safety-metrics',
      method: 'POST',
      direction: 'outbound',
      enabled: true,
      description: 'Export safety metrics to Oracle WMS'
    }
  ],
  manhattan: [
    {
      id: 'inbound_shipments',
      name: 'Inbound Shipments',
      path: '/api/v2/inbounds',
      method: 'GET',
      direction: 'inbound',
      enabled: false,
      description: 'Import scheduled inbound shipments from Manhattan WMS'
    },
    {
      id: 'outbound_shipments',
      name: 'Outbound Shipments',
      path: '/api/v2/outbounds',
      method: 'GET',
      direction: 'inbound',
      enabled: false,
      description: 'Import scheduled outbound shipments from Manhattan WMS'
    }
  ],
  infor: [
    {
      id: 'inbound_shipments',
      name: 'Inbound Shipments',
      path: '/api/scm/inbound',
      method: 'GET',
      direction: 'inbound',
      enabled: true,
      description: 'Import scheduled inbound shipments from Infor SCM'
    },
    {
      id: 'outbound_shipments',
      name: 'Outbound Shipments',
      path: '/api/scm/outbound',
      method: 'GET',
      direction: 'inbound',
      enabled: true,
      description: 'Import scheduled outbound shipments from Infor SCM'
    },
    {
      id: 'dock_assignments',
      name: 'Dock Assignments',
      path: '/api/scm/dock-assignments',
      method: 'GET',
      direction: 'inbound',
      enabled: true,
      description: 'Import dock assignments from Infor SCM'
    },
    {
      id: 'safety_incidents',
      name: 'Safety Incidents',
      path: '/api/scm/safety-incidents',
      method: 'POST',
      direction: 'outbound',
      enabled: true,
      description: 'Export safety incidents to Infor SCM'
    }
  ],
  highjump: [
    {
      id: 'inbound_shipments',
      name: 'Inbound Shipments',
      path: '/api/wms/inbound',
      method: 'GET',
      direction: 'inbound',
      enabled: false,
      description: 'Import scheduled inbound shipments from HighJump WMS'
    },
    {
      id: 'outbound_shipments',
      name: 'Outbound Shipments',
      path: '/api/wms/outbound',
      method: 'GET',
      direction: 'inbound',
      enabled: false,
      description: 'Import scheduled outbound shipments from HighJump WMS'
    }
  ]
};

// Data mappings for integration systems
const dataMappings = {
  sap: [
    { 
      id: '1', 
      sourceField: 'DockSafe.vehicle.id', 
      targetField: 'SAP.shipment.external_id', 
      dataType: 'string', 
      isRequired: true, 
      description: 'Unique identifier for the vehicle',
      status: 'unmapped'
    },
    { 
      id: '2', 
      sourceField: 'DockSafe.dock.id', 
      targetField: 'SAP.location.dock_id', 
      dataType: 'string', 
      isRequired: true, 
      description: 'Unique identifier for the dock',
      status: 'unmapped'
    }
  ],
  oracle: [
    { 
      id: '1', 
      sourceField: 'DockSafe.vehicle.id', 
      targetField: 'Oracle.shipment.external_id', 
      dataType: 'string', 
      isRequired: true, 
      description: 'Unique identifier for the vehicle',
      status: 'mapped'
    },
    { 
      id: '2', 
      sourceField: 'DockSafe.dock.id', 
      targetField: 'Oracle.location.dock_id', 
      dataType: 'string', 
      isRequired: true, 
      description: 'Unique identifier for the dock',
      status: 'mapped'
    },
    { 
      id: '3', 
      sourceField: 'DockSafe.incident.id', 
      targetField: 'Oracle.incident.external_id', 
      dataType: 'string', 
      isRequired: true, 
      description: 'Unique identifier for the incident',
      status: 'mapped'
    },
    { 
      id: '4', 
      sourceField: 'DockSafe.incident.description', 
      targetField: 'Oracle.incident.description', 
      dataType: 'string', 
      isRequired: true, 
      description: 'Description of the incident',
      status: 'mapped'
    },
    { 
      id: '5', 
      sourceField: 'DockSafe.checklist.status', 
      targetField: 'Oracle.quality.checkpoint_status', 
      dataType: 'string', 
      isRequired: true, 
      description: 'Status of the safety checklist',
      status: 'mapped'
    },
    { 
      id: '6', 
      sourceField: 'DockSafe.safety_score', 
      targetField: 'Oracle.metrics.compliance_score', 
      dataType: 'number', 
      isRequired: false, 
      description: 'Safety compliance score',
      status: 'mapped'
    },
    { 
      id: '7', 
      sourceField: 'Oracle.shipment.status', 
      targetField: 'DockSafe.vehicle.wms_status', 
      dataType: 'string', 
      isRequired: false, 
      description: 'Status of the shipment in WMS',
      status: 'unmapped'
    },
    { 
      id: '8', 
      sourceField: 'Oracle.schedule.arrival_time', 
      targetField: 'DockSafe.vehicle.scheduled_arrival', 
      dataType: 'date', 
      isRequired: false, 
      description: 'Scheduled arrival time',
      status: 'unmapped'
    }
  ],
  manhattan: [],
  infor: [
    { 
      id: '1', 
      sourceField: 'DockSafe.vehicle.id', 
      targetField: 'Infor.shipment.external_id', 
      dataType: 'string', 
      isRequired: true, 
      description: 'Unique identifier for the vehicle',
      status: 'mapped'
    },
    { 
      id: '2', 
      sourceField: 'DockSafe.dock.id', 
      targetField: 'Infor.location.dock_id', 
      dataType: 'string', 
      isRequired: true, 
      description: 'Unique identifier for the dock',
      status: 'mapped'
    },
    { 
      id: '3', 
      sourceField: 'DockSafe.incident.id', 
      targetField: 'Infor.incident.external_id', 
      dataType: 'string', 
      isRequired: true, 
      description: 'Unique identifier for the incident',
      status: 'mapped'
    },
    { 
      id: '4', 
      sourceField: 'DockSafe.incident.description', 
      targetField: 'Infor.incident.description', 
      dataType: 'string', 
      isRequired: true, 
      description: 'Description of the incident',
      status: 'mapped'
    },
    { 
      id: '5', 
      sourceField: 'DockSafe.safety_score', 
      targetField: 'Infor.metrics.compliance_score', 
      dataType: 'number', 
      isRequired: false, 
      description: 'Safety compliance score',
      status: 'mapped'
    }
  ],
  highjump: []
};

// Sync history records
const syncHistory = {
  oracle: [
    {
      id: '1',
      systemId: 'oracle',
      endpointId: 'safety_metrics',
      timestamp: new Date(new Date().getTime() - 12 * 60 * 60 * 1000).toISOString(),
      status: 'success',
      recordsProcessed: 5,
      message: 'Successfully pushed safety scores to Oracle WMS'
    },
    {
      id: '2',
      systemId: 'oracle',
      endpointId: 'inbound_shipments',
      timestamp: new Date(new Date().getTime() - 12.5 * 60 * 60 * 1000).toISOString(),
      status: 'success',
      recordsProcessed: 23,
      message: 'Successfully imported 23 new shipments from Oracle WMS'
    },
    {
      id: '3',
      systemId: 'oracle',
      endpointId: 'safety_incidents',
      timestamp: new Date(new Date().getTime() - 13 * 60 * 60 * 1000).toISOString(),
      status: 'error',
      recordsProcessed: 0,
      message: 'Error: Field mismatch - incident.severity not recognized by Oracle WMS API'
    }
  ],
  infor: [
    {
      id: '1',
      systemId: 'infor',
      endpointId: 'safety_metrics',
      timestamp: new Date(new Date().getTime() - 16 * 60 * 60 * 1000).toISOString(),
      status: 'success',
      recordsProcessed: 5,
      message: 'Successfully pushed safety scores to Infor SCM'
    },
    {
      id: '2',
      systemId: 'infor',
      endpointId: 'outbound_shipments',
      timestamp: new Date(new Date().getTime() - 16.5 * 60 * 60 * 1000).toISOString(),
      status: 'warning',
      recordsProcessed: 18,
      message: 'Imported 18 shipments, 3 with missing carrier information'
    }
  ],
  sap: [],
  manhattan: [],
  highjump: []
};

// Connection details for integrated systems
const connectionDetails = {
  oracle: {
    url: 'https://api.oraclewms.example.com/v2',
    apiKey: 'oracle-api-key-placeholder',
    authType: 'api_key',
    syncInterval: 15
  },
  infor: {
    url: 'https://api.infor-scm.example.com/api',
    apiKey: 'infor-api-key-placeholder',
    authType: 'api_key',
    syncInterval: 30
  }
};

// Get all available WMS systems
export const getWmsSystems = async (req: Request, res: Response) => {
  try {
    res.json(availableWmsSystems);
  } catch (error) {
    console.error('Error fetching WMS systems:', error);
    res.status(500).json({ message: 'Error fetching WMS systems' });
  }
};

// Get a specific WMS system
export const getWmsSystem = async (req: Request, res: Response) => {
  try {
    const { systemId } = req.params;
    const system = availableWmsSystems.find(sys => sys.id === systemId);
    
    if (!system) {
      return res.status(404).json({ message: `WMS system with ID ${systemId} not found` });
    }

    // Append connection details if system is connected
    const response = {
      ...system,
      connectionDetails: system.status === 'connected' ? connectionDetails[systemId as keyof typeof connectionDetails] : undefined
    };
    
    res.json(response);
  } catch (error) {
    console.error(`Error fetching WMS system ${req.params.systemId}:`, error);
    res.status(500).json({ message: `Error fetching WMS system ${req.params.systemId}` });
  }
};

// Connect to a WMS system
export const connectWmsSystem = async (req: Request, res: Response) => {
  try {
    const { systemId } = req.params;
    const connectionData = req.body;
    
    // Validate connection data
    if (!connectionData.url) {
      return res.status(400).json({ message: 'URL is required for connection' });
    }
    
    // In a real system, we would verify the connection here
    
    // Update system status to connected
    const systemIndex = availableWmsSystems.findIndex(sys => sys.id === systemId);
    if (systemIndex === -1) {
      return res.status(404).json({ message: `WMS system with ID ${systemId} not found` });
    }
    
    availableWmsSystems[systemIndex].status = 'connected';
    
    // Store connection details
    (connectionDetails as any)[systemId] = {
      url: connectionData.url,
      apiKey: connectionData.apiKey || `${systemId}-api-key-placeholder`,
      authType: connectionData.authType || 'api_key',
      syncInterval: connectionData.syncInterval || 15
    };
    
    res.json({ 
      ...availableWmsSystems[systemIndex],
      connectionDetails: (connectionDetails as any)[systemId]
    });
  } catch (error) {
    console.error(`Error connecting to WMS system ${req.params.systemId}:`, error);
    res.status(500).json({ message: `Error connecting to WMS system ${req.params.systemId}` });
  }
};

// Disconnect from a WMS system
export const disconnectWmsSystem = async (req: Request, res: Response) => {
  try {
    const { systemId } = req.params;
    
    // Update system status to disconnected
    const systemIndex = availableWmsSystems.findIndex(sys => sys.id === systemId);
    if (systemIndex === -1) {
      return res.status(404).json({ message: `WMS system with ID ${systemId} not found` });
    }
    
    availableWmsSystems[systemIndex].status = 'disconnected';
    
    // Remove connection details
    delete (connectionDetails as any)[systemId];
    
    res.json({ success: true, message: `Successfully disconnected from ${availableWmsSystems[systemIndex].name}` });
  } catch (error) {
    console.error(`Error disconnecting from WMS system ${req.params.systemId}:`, error);
    res.status(500).json({ message: `Error disconnecting from WMS system ${req.params.systemId}` });
  }
};

// Get endpoints for a specific WMS system
export const getWmsEndpoints = async (req: Request, res: Response) => {
  try {
    const { systemId } = req.params;
    
    if (!dataEndpoints[systemId as keyof typeof dataEndpoints]) {
      return res.status(404).json({ message: `No endpoints found for WMS system ${systemId}` });
    }
    
    res.json(dataEndpoints[systemId as keyof typeof dataEndpoints]);
  } catch (error) {
    console.error(`Error fetching endpoints for WMS system ${req.params.systemId}:`, error);
    res.status(500).json({ message: `Error fetching endpoints for WMS system ${req.params.systemId}` });
  }
};

// Update endpoint settings for a WMS system
export const updateWmsEndpoint = async (req: Request, res: Response) => {
  try {
    const { systemId, endpointId } = req.params;
    const endpointData = req.body;
    
    if (!dataEndpoints[systemId as keyof typeof dataEndpoints]) {
      return res.status(404).json({ message: `No endpoints found for WMS system ${systemId}` });
    }
    
    const endpointIndex = dataEndpoints[systemId as keyof typeof dataEndpoints].findIndex(
      endpoint => endpoint.id === endpointId
    );
    
    if (endpointIndex === -1) {
      return res.status(404).json({ message: `Endpoint ${endpointId} not found for WMS system ${systemId}` });
    }
    
    // Update endpoint with new data
    dataEndpoints[systemId as keyof typeof dataEndpoints][endpointIndex] = {
      ...dataEndpoints[systemId as keyof typeof dataEndpoints][endpointIndex],
      ...endpointData
    };
    
    res.json(dataEndpoints[systemId as keyof typeof dataEndpoints][endpointIndex]);
  } catch (error) {
    console.error(`Error updating endpoint ${req.params.endpointId} for WMS system ${req.params.systemId}:`, error);
    res.status(500).json({ message: `Error updating endpoint ${req.params.endpointId}` });
  }
};

// Get data mappings for a WMS system
export const getWmsMappings = async (req: Request, res: Response) => {
  try {
    const { systemId } = req.params;
    
    if (!dataMappings[systemId as keyof typeof dataMappings]) {
      return res.json([]);
    }
    
    res.json(dataMappings[systemId as keyof typeof dataMappings]);
  } catch (error) {
    console.error(`Error fetching data mappings for WMS system ${req.params.systemId}:`, error);
    res.status(500).json({ message: `Error fetching data mappings for WMS system ${req.params.systemId}` });
  }
};

// Update a data mapping for a WMS system
export const updateWmsMapping = async (req: Request, res: Response) => {
  try {
    const { systemId, mappingId } = req.params;
    const mappingData = req.body;
    
    if (!dataMappings[systemId as keyof typeof dataMappings]) {
      return res.status(404).json({ message: `No data mappings found for WMS system ${systemId}` });
    }
    
    const mappingIndex = dataMappings[systemId as keyof typeof dataMappings].findIndex(
      mapping => mapping.id === mappingId
    );
    
    if (mappingIndex === -1) {
      return res.status(404).json({ message: `Mapping ${mappingId} not found for WMS system ${systemId}` });
    }
    
    // Update mapping with new data
    dataMappings[systemId as keyof typeof dataMappings][mappingIndex] = {
      ...dataMappings[systemId as keyof typeof dataMappings][mappingIndex],
      ...mappingData
    };
    
    res.json(dataMappings[systemId as keyof typeof dataMappings][mappingIndex]);
  } catch (error) {
    console.error(`Error updating mapping ${req.params.mappingId} for WMS system ${req.params.systemId}:`, error);
    res.status(500).json({ message: `Error updating mapping ${req.params.mappingId}` });
  }
};

// Get sync history for a WMS system
export const getWmsSyncHistory = async (req: Request, res: Response) => {
  try {
    const { systemId } = req.params;
    const limit = parseInt(req.query.limit as string) || 20;
    
    if (!syncHistory[systemId as keyof typeof syncHistory]) {
      return res.json([]);
    }
    
    // Sort by timestamp (newest first) and limit results
    const history = syncHistory[systemId as keyof typeof syncHistory]
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
    
    res.json(history);
  } catch (error) {
    console.error(`Error fetching sync history for WMS system ${req.params.systemId}:`, error);
    res.status(500).json({ message: `Error fetching sync history for WMS system ${req.params.systemId}` });
  }
};

// Trigger a manual sync for a specific endpoint
export const triggerWmsSync = async (req: Request, res: Response) => {
  try {
    const { systemId, endpointId } = req.params;
    
    // Validate system and endpoint
    if (!dataEndpoints[systemId as keyof typeof dataEndpoints]) {
      return res.status(404).json({ message: `No endpoints found for WMS system ${systemId}` });
    }
    
    const endpoint = dataEndpoints[systemId as keyof typeof dataEndpoints].find(
      endpoint => endpoint.id === endpointId
    );
    
    if (!endpoint) {
      return res.status(404).json({ message: `Endpoint ${endpointId} not found for WMS system ${systemId}` });
    }
    
    // In a real system, we would initiate an actual sync job here
    
    // Create a new sync history record
    const syncId = Date.now().toString();
    const newSyncRecord = {
      id: syncId,
      systemId,
      endpointId,
      timestamp: new Date().toISOString(),
      status: 'success',
      recordsProcessed: Math.floor(Math.random() * 20) + 1,
      message: `Manually triggered sync for ${endpoint.name} completed successfully`
    };
    
    if (!syncHistory[systemId as keyof typeof syncHistory]) {
      (syncHistory as any)[systemId] = [];
    }
    
    (syncHistory as any)[systemId].unshift(newSyncRecord);
    
    res.json({ jobId: syncId, status: 'completed' });
  } catch (error) {
    console.error(`Error triggering sync for endpoint ${req.params.endpointId} of WMS system ${req.params.systemId}:`, error);
    res.status(500).json({ message: `Error triggering sync for endpoint ${req.params.endpointId}` });
  }
};

// Test connection to a WMS system
export const testWmsConnection = async (req: Request, res: Response) => {
  try {
    const { systemId } = req.params;
    const connectionData = req.body;
    
    // Validate connection data
    if (!connectionData.url) {
      return res.status(400).json({ message: 'URL is required for connection test' });
    }
    
    // In a real system, we would attempt to connect to the WMS API here
    
    // Simulate a successful connection test
    const isSuccess = Math.random() > 0.2; // 80% success rate
    
    if (isSuccess) {
      res.json({ success: true, message: `Successfully connected to ${systemId.toUpperCase()} WMS API` });
    } else {
      res.status(400).json({ 
        success: false, 
        message: `Failed to connect to ${systemId.toUpperCase()} WMS API: Authentication error` 
      });
    }
  } catch (error) {
    console.error(`Error testing connection to WMS system ${req.params.systemId}:`, error);
    res.status(500).json({ 
      success: false, 
      message: `Error testing connection to WMS system ${req.params.systemId}` 
    });
  }
};

// Get sample data for an endpoint
export const getWmsEndpointSampleData = async (req: Request, res: Response) => {
  try {
    const { systemId, endpointId } = req.params;
    
    // Sample data for different endpoints
    const sampleData: Record<string, any> = {
      inbound_shipments: [
        {
          id: 'IN-12345',
          carrier: 'Acme Logistics',
          trailerNumber: 'TR-7890',
          scheduledArrival: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
          items: [
            { sku: 'SKU001', quantity: 100, description: 'Widget A' },
            { sku: 'SKU002', quantity: 50, description: 'Widget B' }
          ],
          status: 'scheduled'
        },
        {
          id: 'IN-12346',
          carrier: 'FastFreight Inc.',
          trailerNumber: 'TR-7891',
          scheduledArrival: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(),
          items: [
            { sku: 'SKU003', quantity: 75, description: 'Widget C' }
          ],
          status: 'in_transit'
        }
      ],
      outbound_shipments: [
        {
          id: 'OUT-54321',
          carrier: 'Acme Logistics',
          trailerNumber: 'TR-9876',
          scheduledDeparture: new Date(Date.now() + 1 * 60 * 60 * 1000).toISOString(),
          items: [
            { sku: 'SKU001', quantity: 50, description: 'Widget A' },
            { sku: 'SKU004', quantity: 25, description: 'Widget D' }
          ],
          status: 'processing'
        }
      ],
      dock_assignments: [
        {
          dockId: 'D101',
          assignmentId: 'DA-001',
          shipmentId: 'IN-12345',
          scheduledTime: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
          duration: 60, // minutes
          status: 'scheduled'
        },
        {
          dockId: 'D102',
          assignmentId: 'DA-002',
          shipmentId: 'OUT-54321',
          scheduledTime: new Date(Date.now() + 1 * 60 * 60 * 1000).toISOString(),
          duration: 45, // minutes
          status: 'scheduled'
        }
      ],
      safety_incidents: [
        {
          id: 'SI-001',
          type: 'near_miss',
          location: 'Dock 103',
          timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
          description: 'Forklift nearly collided with pedestrian',
          severity: 'medium',
          status: 'resolved'
        }
      ],
      safety_metrics: {
        timePeriod: 'monthly',
        metrics: [
          { name: 'safetyScore', value: 92, unit: 'percent' },
          { name: 'incidentRate', value: 1.5, unit: 'per_100_employees' },
          { name: 'nearMissCount', value: 3, unit: 'count' },
          { name: 'averageTrainingCompletion', value: 95, unit: 'percent' }
        ]
      }
    };
    
    // Return sample data for the requested endpoint, or a 404 if not found
    const data = sampleData[endpointId];
    if (!data) {
      return res.status(404).json({ message: `No sample data available for endpoint ${endpointId}` });
    }
    
    res.json(data);
  } catch (error) {
    console.error(`Error fetching sample data for endpoint ${req.params.endpointId} of WMS system ${req.params.systemId}:`, error);
    res.status(500).json({ message: `Error fetching sample data` });
  }
};